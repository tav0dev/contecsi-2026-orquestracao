# Suplemento técnico — rodada integrada de 08/11/2026

Este pacote acompanha PSE e REX alternativo. Contém uma única rodada de resultados:
60 cenários, 3 domínios, 24 clientes e 6 serviços por catálogo; 2 condições de
contexto e 3 repetições, totalizando 360 chamadas HTTP, sem repetição automática.
A seleção integra o servidor. A inferência é real; catálogo e revisão são
controlados, sem execução de operações. A verificação remota é um ensaio separado
de integração dentro desta rodada, com duas identidades sintéticas e uma inferência;
não compõe a taxa de concordância dos 360 registros.

## Refazer análise e testes sem chave ou custo

Com Python 3.12 ou posterior, na pasta extraída:

```text
python3 experimentos/analisar_rodada_integrada_20261108.py --run experimentos/resultados_locais/rodada_integrada_20261108
python3 -m unittest experimentos.test_comparacao_contexto_20261108 -v
python3 -m unittest prototipo.plataforma.test_application -v
```

Para reproduzir as respostas selecionadas pelo fluxo integrado, em Linux/WSL:

```text
BICO_STUDY_DIR=experimentos/resultados_locais/rodada_integrada_20261108/ia python3 -m unittest prototipo.plataforma.test_context_integration -v
```

A reprodução utiliza respostas registradas e transporte simulado; não solicita
novas inferências. A análise preserva o oráculo e todos os desvios. Repetições do
mesmo cenário não representam participantes independentes. O modelo solicitado e
registrado é gpt-6-luna, sem snapshot datado fixado.

## Contratos, SQL e Flutter

```text
python3 -m unittest discover -s prototipo/planejador -v
python3 -m unittest discover -s prototipo/integracoes -v
python3 -m unittest discover -s experimentos -p 'test_*.py' -v
python3 experimentos/ensaiar_sql.py --pg-bin CAMINHO_POSTGRES --output RESULTADO_SQL_NOVO
```

O ensaio SQL exige PostgreSQL 17.6 e um diretório novo; usa um cluster descartável
com representação mínima de autenticação, não uma instalação completa do Supabase.
Para Dart/Flutter, com SDK compatível com pubspec.yaml:

```text
dart prototipo/bico_flutter/tool/experiment.dart RESULTADO_DART_NOVO
dart prototipo/bico_flutter/tool/workflow_contracts.dart
cd prototipo/laboratorio
flutter pub get
flutter test --no-pub
```

A obtenção inicial das dependências Flutter pode exigir rede; os testes usam
transportes simulados. Os registros locais e SQL preservam a execução desta rodada.
O registro local documenta as tentativas do instrumento Flutter e a correção do
diretório temporário após falta de espaço. Sucessos parciais não foram somados.

## Integridade, medidas e nova coleta

MANIFESTO_SHA256.json permite verificar cada arquivo do pacote. freeze.json contém
os hashes das fontes da rodada. plan.json registra a preparação anterior à coleta;
o estado final está em status.json e finish.json. run_start.json e finish.json registram coleta;
synthesis.json contém a análise descritiva. Os tempos HTTP incluem comunicação
local e aplicação; tempos internos existem nas respostas bem-sucedidas e são
contados separadamente. Tokens ausentes não recebem valores inventados.

Custos calculados usam tarifas configuradas de US$ 0,10 e US$ 0,50 por milhão de
tokens de entrada e saída, sem verificação de fatura ou descontos de cache. A
reserva conservadora local não é a cobrança real.

Nova coleta paga exige configuração privada própria, autorização de orçamento,
acesso ao provedor e preflight GitHub. Os coletores recusam sobrescrever resultados.
Nenhuma chave, conta de teste, senha ou configuração local é distribuída. O ensaio
remoto exige contas sintéticas próprias no projeto autorizado; não é reproduzido
pelos comandos offline. Os resultados antigos não estão incluídos nesta rodada.

figuras_adicionais reúne telas implementadas e uma visão conceitual identificada;
as imagens não demonstram conectores externos ou etapas futuras implementadas.
