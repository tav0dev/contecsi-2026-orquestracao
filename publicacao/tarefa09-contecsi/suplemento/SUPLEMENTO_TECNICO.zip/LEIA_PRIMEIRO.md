# Suplemento técnico — revisão de 08/11/2026

Este pacote acompanha o PSE e o REX alternativo. Contém corpus sintéticos,
resultados esperados, plano de chamadas, respostas, análises e fontes necessárias
para examinar a comparação de contexto completo e selecionado.

## Reproduzir a análise sem rede, chave ou custo

Na pasta extraída, com Python 3.12 ou posterior:

```text
python3 -m unittest experimentos.test_comparacao_contexto_20261108 -v
python3 experimentos/executar_comparacao_contexto_20261108.py --analyze experimentos/resultados_locais/comparacao_contexto_20261108
python3 experimentos/sintetizar_comparacao_contexto_20261108.py
```

Esses comandos não fazem inferência nem acessam o banco. A análise é descritiva:
as repetições de um cenário não são observações independentes do público.

## Desenho e evidência

São 60 cenários, 3 domínios, 24 clientes e 6 serviços por catálogo, com 2 condições
e 3 repetições, totalizando 360 chamadas sem repetição automática. Os dados são
sintéticos; as estruturas textuais são adaptadas entre catálogos. O seletor recebe
somente pedido e contexto, sem acesso ao resultado esperado. Nenhuma operação de
negócio foi executada na comparação. O identificador solicitado e devolvido foi
gpt-6-luna, sem snapshot datado fixado.

manifest.json preserva a preparação anterior à coleta. finish.json registra o
término; synthesis.json resume o conjunto completo. A caracterização das
divergências é exploratória e não altera o critério estrito original.

A reserva conservadora de orçamento não equivale ao custo de consumo informado
nas respostas. Custos calculados usam as tarifas configuradas de US$ 0,10 e
US$ 0,50 por milhão de tokens de entrada e saída, sem reconciliação de fatura
ou descontos de cache.

dados/integrada_108.jsonl preserva os campos científicos da rodada integrada
anterior, omitindo identificadores de tenant e objetos de autorização. Ela inclui
consulta de contexto e revisão de regras quando aplicável; sua latência não é
equivalente à da comparação de inferência. As contagens não devem ser somadas
em uma taxa geral. Os ensaios de execução no banco estão descritos no artigo;
este suplemento não reproduz automaticamente o piloto remoto ou todos os testes
de banco, interface, web e Android.

## Nova execução paga

Exige configuração privada própria, acesso ao provedor, orçamento autorizado,
ledger de reserva e autenticação GitHub para o preflight do executor. Nenhuma
chave, conta de teste, configuração local ou credencial é distribuída. Preserve
os registros existentes e prepare um diretório novo; o executor recusa sobrescrita.
O código não garante que o alias do modelo mantenha os mesmos pesos no futuro.

figuras_adicionais contém telas implementadas complementares e um estudo
conceitual explicitamente identificado. A presença das imagens não demonstra
integrações ou funcionalidades futuras implementadas.
