"""Cliente de um endpoint de planejamento. Nunca chama IA sem --endpoint explícito.

Contrato POST: {context, request}. Resposta JSON igual aos campos de expected,
permitido campo adicional draft. Credencial opcional BICO_PLANNER_TOKEN no ambiente.
Servidor é responsável por chamar o modelo e proteger sua chave. Só dados sintéticos.
"""
import argparse, datetime, hashlib, json, os, random, time, urllib.request
from pathlib import Path

def semantic_equal(actual, expected):
    if not isinstance(actual,dict): return False
    if set(actual)-set(expected)-{'draft'}: return False
    for key,value in expected.items():
        candidate=actual.get(key)
        if key=='start':
            try:
                if datetime.datetime.fromisoformat(candidate.replace('Z','+00:00')) != datetime.datetime.fromisoformat(value): return False
            except (ValueError,TypeError,AttributeError): return False
        elif type(candidate) is not type(value) or candidate!=value: return False
    return True

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--endpoint',required=True)
    p.add_argument('--model-id',required=True,help='Identificador exato do modelo configurado no servidor')
    p.add_argument('--prompt-version',required=True)
    p.add_argument('--output',required=True)
    p.add_argument('--repetitions',type=int,default=3)
    args=p.parse_args()
    if args.repetitions<1: p.error('repetitions deve ser positivo')
    path=Path(args.output);path.parent.mkdir(parents=True,exist_ok=True)
    corpus=Path(__file__).with_name('cenarios_ia.jsonl').read_bytes()
    cases=[json.loads(x) for x in corpus.decode().splitlines()]
    trials=[(case,r) for case in cases for r in range(args.repetitions)]
    random.Random(20261103).shuffle(trials)
    # x evita sobrescrever uma coleta anterior.
    with path.open('x') as sink:
        for case,rep in trials:
            row={'case_id':case['case_id'],'stratum':case['stratum'],'repetition':rep,
              'model_id':args.model_id,'prompt_version':args.prompt_version,
              'corpus_sha256':hashlib.sha256(corpus).hexdigest(),
              'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'expected':case['expected'],'mode':'remote_endpoint'}
            started=time.perf_counter()
            try:
                headers={'Content-Type':'application/json'}
                if os.environ.get('BICO_PLANNER_TOKEN'): headers['Authorization']='Bearer '+os.environ['BICO_PLANNER_TOKEN']
                req=urllib.request.Request(args.endpoint,json.dumps({'context':case['context'],
                    'request':case['request']}).encode(),headers)
                with urllib.request.urlopen(req,timeout=60) as res:
                    row['http_status']=res.status
                    row['observed_model']=res.headers.get('X-Bico-Model')
                    row['observed_prompt_version']=res.headers.get('X-Bico-Prompt-Version')
                    usage=res.headers.get('X-Bico-Usage')
                    row['usage']=json.loads(usage) if usage else None
                    row['reserved_usd']=res.headers.get('X-Bico-Reserved-USD')
                    actual=json.loads(res.read())
                row['actual']=actual;row['passed']=semantic_equal(actual,case['expected'])
            except Exception as exc:
                row['passed']=False;row['error_type']=type(exc).__name__
            row['elapsed_ms']=(time.perf_counter()-started)*1000
            sink.write(json.dumps(row,ensure_ascii=False)+'\n');sink.flush()
    print('Coleta salva. Avaliar por cenário e estrato; repetições não são participantes independentes.')

if __name__=='__main__': main()
