"""Nova rodada: 360 POST /plan pelo servidor integrado, inferência real e catálogo local.

O catálogo e a RPC de revisão são transportes controlados, sem banco remoto.
Modelo, instrução, pedidos e condições são congelados. Não confirma propostas.
"""
import argparse
from collections import Counter
from copy import deepcopy
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
from http.server import HTTPServer
import json
from pathlib import Path
import secrets
import socket
import subprocess
import sys
from threading import Thread
import time
import urllib.error

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from experimentos.avaliar_planejador import semantic_equal
from prototipo.integracoes.providers import http_json
from prototipo.planejador.server import Budget, request_body
from prototipo.plataforma.server import Application, OpenAIPlanner, RequestError, handler_for


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


class ControlledRPC:
    def __init__(self):
        self.context = None
        self.token = secrets.token_urlsafe(32)
        self.calls = []

    def call(self, token, function, params):
        if token != self.token:
            raise RequestError(401, 'denied')
        self.calls.append((function, deepcopy(params)))
        if function == 'state':
            return {'tenant_id': 'synthetic-controlled-tenant',
                    'clients': [{'id': c['id'], 'label': c['name']} for c in self.context['clients']],
                    'services': [{'id': s['id'], 'label': s['name'], 'duration_minutes': s['duration_minutes']}
                                 for s in self.context['services']]}
        if function == 'submit' and params.get('p_approved') is False:
            return {'status': 'awaiting_confirmation'}
        raise AssertionError('Only state and non-executing review are allowed')


def run(folder):
    ia = folder/'ia'
    if (ia/'trials.jsonl').exists():
        raise SystemExit('Coleta iniciada: preservar resultados; não repetir automaticamente.')
    plan = json.loads((folder/'plan.json').read_text())
    if hashlib.sha256((ia/'trials_prepared.jsonl').read_bytes()).hexdigest() != plan['trials_prepared_sha256']:
        raise SystemExit('Plano de chamadas divergente.')
    authorization = json.loads((folder/'authorization.json').read_text())
    cfg = json.loads((ROOT/'prototipo/plataforma/.config.local.json').read_text())
    cap = Decimal(cfg['BICO_BUDGET_USD'])
    if cap != Decimal(authorization['authorized_cap_usd']):
        raise SystemExit('Configuração difere do teto explicitamente autorizado.')
    ledger = ROOT/'prototipo/plataforma/.budget-reserved'
    before = Decimal(ledger.read_text())
    trials = [json.loads(line) for line in (ia/'trials_prepared.jsonl').read_text().splitlines()]
    cases = {c['case_id']: c for c in map(json.loads, (ia/'corpus.jsonl').read_text().splitlines())}
    full = {(t['case_id'], t['repetition']): t['payload'] for t in trials if t['condition'] == 'full'}
    estimate = sum((Decimal(len(json.dumps(request_body(cfg['BICO_OPENAI_MODEL'], t['payload'])).encode())+1024)
                    * Decimal(cfg['BICO_INPUT_USD_PER_MILLION']) + Decimal(512)*Decimal(cfg['BICO_OUTPUT_USD_PER_MILLION']))
                   / Decimal(1000000) for t in trials)
    if before+estimate > cap:
        raise SystemExit('Reserva não cabe no teto vigente; nenhuma inferência executada.')
    for port in [8765, 8766, 8768]:
        with socket.socket() as s:
            if s.connect_ex(('127.0.0.1', port)) == 0:
                raise SystemExit(f'Outro backend pode escrever o ledger na porta {port}.')
    check = subprocess.run(['gh','api','repos/tav0dev/contecsi-2026-orquestracao','--jq','.full_name'],
                           capture_output=True, text=True, timeout=25)
    if check.returncode:
        raise SystemExit('Preflight GitHub falhou.')
    http_json('GET','https://api.openai.com/v1/models/'+cfg['BICO_OPENAI_MODEL'],
              {'Authorization':'Bearer '+cfg['OPENAI_API_KEY']},None)
    rpc, captured = ControlledRPC(), {}
    expected_payload = None

    def transport(method, url, headers, body):
        if json.loads(body['input']) != expected_payload:
            raise AssertionError('Contexto do fluxo integrado difere da condição congelada.')
        answer = http_json(method,url,headers,body,timeout=35)
        captured.clear(); captured.update({k: answer.get(k) for k in ['id','model','status','created_at']})
        return answer

    planner = OpenAIPlanner(cfg['OPENAI_API_KEY'],cfg['BICO_OPENAI_MODEL'],
                            cfg['BICO_INPUT_USD_PER_MILLION'],cfg['BICO_OUTPUT_USD_PER_MILLION'],
                            Budget(ledger,cap),transport)
    app = Application(rpc,planner,now=lambda:datetime.fromisoformat(rpc.context['now']))
    server = HTTPServer(('127.0.0.1',0),handler_for(app,'http://localhost:7357'))
    thread = Thread(target=server.serve_forever,daemon=True);thread.start()
    base = f'http://127.0.0.1:{server.server_port}'
    headers = {'Authorization':'Bearer '+rpc.token,'Content-Type':'application/json'}
    start = {'round_id':plan['round_id'],'started_at':datetime.now(timezone.utc).isoformat(),
             'planned':len(trials),'reserved_before_usd':str(before),'cap_usd':str(cap),
             'transport':'HTTP integrated Application; real OpenAI; controlled local catalog and review RPC',
             'database_remote_access':False,'business_execution':False,'retry_policy':'none',
             'source_sha256':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in
                              ['prototipo/plataforma/server.py','prototipo/planejador/contexto.py',
                               'prototipo/planejador/server.py',str(Path(__file__).resolve().relative_to(ROOT))]}}
    (ia/'run_start.json').write_text(json.dumps(start,ensure_ascii=False,indent=2)+'\n')
    rows=[]
    try:
        with (ia/'trials.jsonl').open('x') as stream:
            for i,t in enumerate(trials,1):
                case=cases[t['case_id']]
                rpc.context=deepcopy(full[t['case_id'],t['repetition']]['context']);rpc.calls=[]
                expected_payload=t['payload'];app.context_strategy=t['condition']
                before_state=digest(rpc.context)
                row={k:t[k] for k in ['case_id','condition','repetition']}
                row.update({'domain':case['domain'],'stratum':case['stratum'],'expected':case['expected'],
                            'started_at':datetime.now(timezone.utc).isoformat(),'passed':False})
                started=time.perf_counter()
                try:
                    answer=http_json('POST',base+'/plan',headers,{'request':t['payload']['request']},timeout=90)
                    row.update({'actual':answer['plan'],'metadata':answer['metadata'],'provider':dict(captured),
                                'review_status':answer.get('review',{}).get('status')})
                    row['semantic_passed']=semantic_equal(answer['plan'],case['expected']) and isinstance(answer['plan'].get('draft'),str)
                    row['review_passed']=(row['review_status']=='awaiting_confirmation' if case['expected']['status']=='proposed'
                                          else 'proposal' not in answer and 'review' not in answer)
                    row['passed']=row['semantic_passed'] and row['review_passed']
                except Exception as exc:
                    row['error_type']=type(exc).__name__
                    if isinstance(exc,urllib.error.HTTPError):
                        row['http_status']=exc.code
                        try:row['backend_error']=json.loads(exc.read()).get('error')
                        except (ValueError,AttributeError):pass
                row['elapsed_ms']=(time.perf_counter()-started)*1000
                row['state_unchanged']=digest(rpc.context)==before_state
                row['explicit_execution_requested']=any(params.get('p_approved') is True for _,params in rpc.calls)
                row['passed']=row['passed'] and row['state_unchanged'] and not row['explicit_execution_requested']
                stream.write(json.dumps(row,ensure_ascii=False)+'\n');stream.flush();rows.append(row)
                if i%12==0:
                    print(json.dumps({'completed':i,'planned':len(trials),'passed':sum(r['passed'] for r in rows)}),flush=True)
                if not row['state_unchanged'] or row['explicit_execution_requested']:
                    break
    finally:
        server.shutdown();thread.join();server.server_close()
    finish={'round_id':plan['round_id'],'finished_at':datetime.now(timezone.utc).isoformat(),
            'planned':len(trials),'completed':len(rows),'passed':sum(r['passed'] for r in rows),
            'reserved_after_usd':ledger.read_text().strip(),'remote_database_changes':False,
            'all_states_unchanged':all(r['state_unchanged'] for r in rows),
            'trials_sha256':hashlib.sha256((ia/'trials.jsonl').read_bytes()).hexdigest()}
    (ia/'finish.json').write_text(json.dumps(finish,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(finish),flush=True)


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--run',type=Path,required=True)
    run(parser.parse_args().run.resolve())
