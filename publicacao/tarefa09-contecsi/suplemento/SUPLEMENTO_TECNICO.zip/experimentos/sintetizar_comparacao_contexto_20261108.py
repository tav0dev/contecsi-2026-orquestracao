"""Síntese descritiva por cenário e condição; não modifica o oráculo nem chama IA."""
from collections import Counter, defaultdict
from decimal import Decimal
import json
import math
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parents[1]
FOLDER = ROOT / 'experimentos/resultados_locais/comparacao_contexto_20261108'


def summarize(rows):
    result = {'n': len(rows), 'conditions': {}, 'deviations': [],
              'diagnostic_status': 'Exploratory classification of deviations; original strict oracle unchanged.'}
    for condition in ['full', 'selected']:
        group = [r for r in rows if r['condition'] == condition]
        by_case = defaultdict(list)
        for r in group:
            by_case[r['case_id']].append(r)
        times = sorted(r['elapsed_ms'] for r in group)
        input_tokens = sum(r.get('metadata', {}).get('usage', {}).get('input_tokens', 0) for r in group)
        output_tokens = sum(r.get('metadata', {}).get('usage', {}).get('output_tokens', 0) for r in group)
        result['conditions'][condition] = {
            'trials': len(group), 'conforming': sum(r['passed'] for r in group),
            'case_count': len(by_case),
            'cases_all_three_conforming': sum(len(g) == 3 and all(r['passed'] for r in g)
                                              for g in by_case.values()),
            'median_inference_ms': statistics.median(times) if times else None,
            'p95_inference_ms': times[max(0, math.ceil(.95 * len(times))-1)] if times else None,
            'input_tokens': input_tokens, 'output_tokens': output_tokens,
            'cost_at_configured_rates_usd': str((Decimal(input_tokens) * Decimal('.10') +
                                                Decimal(output_tokens) * Decimal('.50')) / 1000000),
            'returned_models': dict(Counter(r.get('provider', {}).get('model') for r in group)),
            'by_domain': {d: {'trials': sum(r['domain'] == d for r in group),
                              'conforming': sum(r['domain'] == d and r['passed'] for r in group)}
                          for d in ['limpeza', 'manutencao', 'educacao']},
            'by_stratum': {s: {'trials': sum(r['stratum'] == s for r in group),
                               'conforming': sum(r['stratum'] == s and r['passed'] for r in group)}
                           for s in ['complete', 'ambiguous', 'adversarial']},
        }
    for row in rows:
        if not row['passed']:
            result['deviations'].append({k: row.get(k) for k in
                                        ['case_id', 'condition', 'repetition', 'expected', 'actual', 'error_type']})
    full, selected = result['conditions']['full'], result['conditions']['selected']
    result['input_token_reduction_pct'] = ((1-selected['input_tokens']/full['input_tokens'])*100
                                          if full['input_tokens'] else None)
    result['unexpected_executable_proposals'] = sum(
        r.get('actual', {}).get('status') == 'proposed' and r['expected']['status'] != 'proposed'
        for r in rows)
    result['note'] = ('Costs use configured gross input/output rates, without invoice or cache-discount reconciliation. '
                      'Repeated scenarios are not independent human observations. No business execution occurred.')
    return result


if __name__ == '__main__':
    rows = [json.loads(line) for line in (FOLDER/'trials.jsonl').read_text().splitlines()]
    result = summarize(rows)
    (FOLDER/'synthesis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))
