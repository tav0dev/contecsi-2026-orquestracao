import copy
import unittest
from experimentos.comparacao_contexto_20261108 import corpus, paired_trials
from prototipo.planejador.contexto import select_context


class ContextSelectionTests(unittest.TestCase):
    def setUp(self):
        self.cases = corpus()
        self.context = self.cases[0]['context']

    def test_shared_first_name_preserves_all_candidates(self):
        found = select_context(self.context, 'Agende para Ana em 20/12/2030 às 14h')
        self.assertEqual({c['name'] for c in found['clients']}, {'Ana Silva', 'Ana Souza'})

    def test_unknown_name_falls_back_without_inventing_identity(self):
        found = select_context(self.context, 'Agende para Patrícia Nunes')
        self.assertEqual(found['clients'], self.context['clients'])

    def test_service_ties_are_not_arbitrarily_resolved(self):
        found = select_context(self.context, 'Preciso de limpeza')
        self.assertEqual(found['services'], self.context['services'])

    def test_no_mutation_and_pairwise_catalog_order(self):
        original = copy.deepcopy(self.context)
        select_context(self.context, 'Ana Silva limpeza residencial')
        self.assertEqual(self.context, original)
        trials = paired_trials(self.cases)
        full = next(t for t in trials if t['condition'] == 'full')
        selected = next(t for t in trials if t['condition'] == 'selected'
                        and (t['case_id'], t['repetition']) == (full['case_id'], full['repetition']))
        self.assertEqual(select_context(full['payload']['context'], full['payload']['request']),
                         selected['payload']['context'])

    def test_complete_requests_retain_oracle_entities_without_oracle_input(self):
        for case in self.cases:
            if case['stratum'] != 'complete':
                continue
            ctx = select_context(case['context'], case['request'])
            self.assertIn(case['expected']['client_id'], [c['id'] for c in ctx['clients']])
            self.assertIn(case['expected']['service_id'], [s['id'] for s in ctx['services']])

    def test_trial_design_is_balanced_and_not_execution(self):
        self.assertEqual(len(self.cases), 60)
        self.assertEqual(len(paired_trials(self.cases)), 360)
        self.assertEqual({len(c['context']['clients']) for c in self.cases}, {24})
        self.assertEqual({len(c['context']['services']) for c in self.cases}, {6})


if __name__ == '__main__':
    unittest.main()
