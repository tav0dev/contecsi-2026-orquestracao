"""Verifica HTTP, autenticação, catálogo e revisão reais; não confirma operações.

Uma inferência paga, após autorização da rodada. Reutiliza duas contas sintéticas.
Não provisiona contas, não executa setup e não publica credenciais ou estados.
"""
from datetime import datetime, timedelta, timezone
from decimal import Decimal
import hashlib
from http.server import HTTPServer
import json
from pathlib import Path
import subprocess
import sys
from threading import Thread
import urllib.error

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from prototipo.integracoes.providers import http_json
from prototipo.planejador.server import Budget
from prototipo.plataforma.server import Application, OpenAIPlanner, SupabaseRPC, SUPABASE_URL, handler_for


def main():
    folder = ROOT/'experimentos/resultados_locais/rodada_integrada_20261108'
    output = folder/'remoto'
    output.mkdir(exist_ok=False)
    cfg = json.loads((ROOT/'prototipo/plataforma/.config.local.json').read_text())
    authorization = json.loads((folder/'authorization.json').read_text())
    assert Decimal(cfg['BICO_BUDGET_USD']) == Decimal(authorization['authorized_cap_usd'])
    key = json.loads((ROOT/'prototipo/plataforma/public_config.json').read_text())['BICO_SUPABASE_ANON_KEY']
    credentials = json.loads((ROOT/'prototipo/plataforma/.pilot-rodada-20261106.local.json').read_text())['accounts']
    assert len(credentials) == 2
    ledger = ROOT/'prototipo/plataforma/.budget-reserved'
    report = {'round_id': 'rodada_integrada_20261108', 'started_at': datetime.now(timezone.utc).isoformat(),
              'project_ref': 'wzychmshebmznjfducug', 'checks': [], 'paid_attempts': 0,
              'business_execution_requested': False, 'synthetic_accounts_reused': 2,
              'reserved_before_usd': ledger.read_text().strip(),
              'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    server = None

    def check(name, condition):
        if not condition:
            raise AssertionError(name)
        report['checks'].append(name)

    try:
        github = subprocess.run(['gh', 'api', 'repos/tav0dev/contecsi-2026-orquestracao',
                                 '--jq', '.full_name'], capture_output=True, text=True, timeout=25)
        check('github_preflight', github.returncode == 0)
        tokens = [http_json('POST', SUPABASE_URL+'/auth/v1/token?grant_type=password',
                           {'apikey': key, 'Content-Type': 'application/json'},
                           {k: a[k] for k in ['email', 'password']})['access_token'] for a in credentials]
        check('two_authenticated_synthetic_sessions', len(tokens) == 2)
        rpc = SupabaseRPC(key)
        calls = []
        original = rpc.call

        def tracked_rpc(token, function, params):
            calls.append({'function': function, 'approved': params.get('p_approved')})
            return original(token, function, params)

        rpc.call = tracked_rpc

        def provider(method, url, headers, body):
            report['paid_attempts'] += 1
            return http_json(method, url, headers, body, timeout=35)

        planner = OpenAIPlanner(cfg['OPENAI_API_KEY'], cfg['BICO_OPENAI_MODEL'],
                                cfg['BICO_INPUT_USD_PER_MILLION'], cfg['BICO_OUTPUT_USD_PER_MILLION'],
                                Budget(ledger, Decimal(cfg['BICO_BUDGET_USD'])), provider)
        app = Application(rpc, planner)
        server = HTTPServer(('127.0.0.1', 0), handler_for(app, 'http://localhost:7357'))
        thread = Thread(target=server.serve_forever, daemon=True); thread.start()
        base = f'http://127.0.0.1:{server.server_port}'

        def call(path, body=None, token=None):
            return http_json('GET' if body is None else 'POST', base+path,
                             {'Authorization': 'Bearer '+(token or tokens[0]),
                              'Content-Type': 'application/json'}, body, timeout=90)

        states = [call('/state', token=t) for t in tokens]
        check('existing_catalogs_ready', all(not s.get('needs_setup') and s['clients'] and s['services'] for s in states))
        check('distinct_authenticated_tenants', states[0]['tenant_id'] != states[1]['tenant_id'])
        client, service = states[0]['clients'][0], states[0]['services'][0]
        day = (datetime.now(timezone.utc)+timedelta(days=14)).date().isoformat()
        request = f"Agende {client['label']} para {service['label']} em {day} às 14:00, horário de São Paulo (UTC-03:00), por {service['duration_minutes']} minutos. Apenas prepare a proposta para revisão."
        answer = call('/plan', {'request': request})
        plan = answer['plan']
        check('real_model_proposal', plan['status'] == 'proposed')
        check('proposal_uses_authenticated_catalog', plan['client_id'] == client['id'] and plan['service_id'] == service['id'])
        check('correct_start_and_duration', datetime.fromisoformat(plan['start']) == datetime.fromisoformat(day+'T14:00:00-03:00') and plan['duration_minutes'] == service['duration_minutes'])
        check('default_selector_integrated', answer['metadata']['context_selection']['strategy'] == 'selected')
        check('real_database_review_without_execution', answer['review']['status'] == 'awaiting_confirmation')
        check('primary_business_unchanged_after_planning', call('/state') == states[0])
        try:
            call('/confirm', {'proposal': answer['proposal']})
            raise AssertionError('missing approval accepted')
        except urllib.error.HTTPError as error:
            check('missing_explicit_approval_denied', error.code == 400)
        try:
            call('/review', {'proposal': answer['proposal']}, tokens[1])
            raise AssertionError('foreign proposal accepted')
        except urllib.error.HTTPError as error:
            check('foreign_tenant_review_denied', error.code == 409)
        try:
            http_json('POST', SUPABASE_URL+'/rest/v1/rpc/bico_exp_state',
                      {'apikey': key, 'Authorization': 'Bearer '+tokens[1], 'Content-Type': 'application/json'},
                      {'p_tenant': states[0]['tenant_id']})
            raise AssertionError('foreign state disclosed')
        except urllib.error.HTTPError as error:
            check('foreign_tenant_read_denied', error.code in (400, 403))
        try:
            http_json('POST', SUPABASE_URL+'/rest/v1/rpc/bico_exp_state', {'apikey': key, 'Content-Type': 'application/json'}, {})
            raise AssertionError('anonymous RPC allowed')
        except urllib.error.HTTPError as error:
            check('anonymous_rpc_denied', error.code in (401, 403))
        check('both_business_states_unchanged', all(call('/state', token=t) == s for t, s in zip(tokens, states)))
        check('no_execution_rpc_requested', not any(c['approved'] is True for c in calls))
        report['metadata'] = answer['metadata']
        report['status'] = 'passed'
    except Exception as error:
        report['status'] = 'failed'
        report['error_type'] = type(error).__name__
        if isinstance(error, AssertionError):
            report['failed_check'] = str(error)
    finally:
        if server:
            server.shutdown(); server.server_close(); thread.join()
        report['reserved_after_usd'] = ledger.read_text().strip()
        report['finished_at'] = datetime.now(timezone.utc).isoformat()
        (output/'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
