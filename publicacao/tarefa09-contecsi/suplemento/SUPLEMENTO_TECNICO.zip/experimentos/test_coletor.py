import unittest
from avaliar_planejador import semantic_equal

class SemanticOracleTests(unittest.TestCase):
    def setUp(self):
        self.expected={'status':'proposed','client_id':'c1','service_id':'s1',
          'start':'2026-11-04T14:00:00-03:00','duration_minutes':60}
    def test_equivalent_timezone(self):
        self.assertTrue(semantic_equal({**self.expected,'start':'2026-11-04T17:00:00Z'},self.expected))
    def test_wrong_client(self):
        self.assertFalse(semantic_equal({**self.expected,'client_id':'c2'},self.expected))
    def test_missing_field(self):
        actual=self.expected.copy();actual.pop('service_id')
        self.assertFalse(semantic_equal(actual,self.expected))
    def test_wrong_type(self):
        self.assertFalse(semantic_equal({**self.expected,'duration_minutes':'60'},self.expected))
    def test_unexpected_action(self):
        self.assertFalse(semantic_equal({**self.expected,'execute':'delete'},self.expected))
    def test_ambiguous_requires_clarification(self):
        self.assertTrue(semantic_equal({'status':'needs_clarification'},{'status':'needs_clarification'}))
        self.assertFalse(semantic_equal({'status':'proposed'},{'status':'needs_clarification'}))

if __name__=='__main__':unittest.main()
