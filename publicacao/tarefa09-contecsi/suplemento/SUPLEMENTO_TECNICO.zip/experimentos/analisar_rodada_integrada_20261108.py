"""Analisa somente os registros da rodada integrada, incluindo todos os desvios."""
import argparse
from collections import Counter, defaultdict
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import statistics


def distribution(values):
    ordered = sorted(values)
    return {'n': len(ordered), 'median': statistics.median(ordered) if ordered else None,
            'p95': ordered[math.ceil(.95*len(ordered))-1] if ordered else None}


def summarize(rows):
    result = {'attempts': len(rows), 'conditions': {}, 'deviations': [],
              'prior_round_observations_included': 0}
    for condition in ['full', 'selected']:
        group = [r for r in rows if r['condition'] == condition]
        by_case = defaultdict(list)
        for row in group:
            by_case[row['case_id']].append(row)
        input_tokens = sum(r.get('metadata', {}).get('usage', {}).get('input_tokens', 0) for r in group)
        output_tokens = sum(r.get('metadata', {}).get('usage', {}).get('output_tokens', 0) for r in group)
        result['conditions'][condition] = {
            'attempts': len(group), 'conforming': sum(r['passed'] for r in group),
            'cases': len(by_case),
            'cases_all_three_conforming': sum(len(g) == 3 and all(r['passed'] for r in g)
                                              for g in by_case.values()),
            'http_errors': dict(Counter(str(r.get('http_status')) for r in group if 'error_type' in r)),
            'elapsed_http_ms_all_attempts': distribution([r['elapsed_ms'] for r in group]),
            'server_timings_ms_successful_responses': {
                stage: distribution([r['metadata']['timings_ms'][stage] for r in group
                                     if stage in r.get('metadata', {}).get('timings_ms', {})])
                for stage in ['context', 'inference', 'review', 'server_total']},
            'input_tokens': input_tokens, 'output_tokens': output_tokens,
            'usage_present': sum('usage' in r.get('metadata', {}) for r in group),
            'estimated_cost_at_configured_rates_usd': str((Decimal(input_tokens)*Decimal('.10') +
                                                          Decimal(output_tokens)*Decimal('.50'))/1000000),
            'returned_models': dict(Counter(r.get('provider', {}).get('model') for r in group)),
            'by_domain': {d: {'attempts': sum(r['domain'] == d for r in group),
                              'conforming': sum(r['domain'] == d and r['passed'] for r in group)}
                          for d in ['limpeza', 'manutencao', 'educacao']},
            'by_stratum': {s: {'attempts': sum(r['stratum'] == s for r in group),
                               'conforming': sum(r['stratum'] == s and r['passed'] for r in group)}
                           for s in ['complete', 'ambiguous', 'adversarial']},
        }
    for row in rows:
        if not row['passed']:
            result['deviations'].append({k: row.get(k) for k in [
                'case_id', 'condition', 'repetition', 'expected', 'actual',
                'error_type', 'http_status', 'backend_error']})
    full, selected = result['conditions']['full'], result['conditions']['selected']
    result['input_token_reduction_pct'] = (100*(1-selected['input_tokens']/full['input_tokens'])
                                          if full['input_tokens'] else None)
    result['unexpected_executable_proposals'] = sum(
        r.get('actual', {}).get('status') == 'proposed' and r['expected']['status'] != 'proposed'
        for r in rows)
    result['all_states_unchanged'] = all(r['state_unchanged'] for r in rows)
    result['explicit_executions_requested'] = sum(r['explicit_execution_requested'] for r in rows)
    result['measurement_notes'] = [
        'HTTP elapsed time includes local request and application processing; all attempts are retained.',
        'Server stages are available only for successful HTTP responses; their n is reported separately.',
        'Missing provider usage is not estimated or treated as a zero-token request.',
        'Costs use configured gross rates, not invoice verification or cache discounts.',
        'Three repetitions per synthetic scenario are not independent human observations.',
        'Controlled catalog and review RPC; no remote database or business execution in these model trials.',
    ]
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', required=True, type=Path)
    args = parser.parse_args()
    folder = args.run/'ia'
    finish = json.loads((folder/'finish.json').read_text())
    raw = (folder/'trials.jsonl').read_bytes()
    assert hashlib.sha256(raw).hexdigest() == finish['trials_sha256']
    rows = list(map(json.loads, raw.decode().splitlines()))
    assert len(rows) == finish['completed']
    assert len({(r['case_id'], r['condition'], r['repetition']) for r in rows}) == len(rows)
    result = summarize(rows)
    result['status'] = 'complete' if len(rows) == 360 else 'incomplete_preserved'
    result['trials_sha256'] = finish['trials_sha256']
    (folder/'synthesis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
