"""Executa o corpus congelado, sem banco e sem repetir chamadas automaticamente.

Requer --run, diretório preparado e orçamento já autorizado/configurado. Preserva
reserva compartilhada; exige portas dos antigos escritores de orçamento livres.
"""
import argparse
from collections import defaultdict
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import socket
import statistics
import subprocess
import sys
import time
import urllib.error

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from experimentos.avaliar_planejador import semantic_equal
from prototipo.integracoes.providers import http_json
from prototipo.planejador.server import Budget, request_body
from prototipo.plataforma.server import OpenAIPlanner


def quantile(values, proportion):
    return sorted(values)[max(0, math.ceil(len(values) * proportion) - 1)] if values else None


def analyze(folder):
    rows = [json.loads(line) for line in (folder / 'trials.jsonl').read_text().splitlines()]
    summary = {'completed': len(rows), 'conditions': {}, 'failures': []}
    pairs = defaultdict(dict)
    for row in rows:
        pairs[(row['case_id'], row['repetition'])][row['condition']] = row
        if not row['passed']:
            summary['failures'].append({k: row.get(k) for k in
                                       ['case_id', 'condition', 'repetition', 'error_type', 'actual']})
    for condition in ('full', 'selected'):
        group = [r for r in rows if r['condition'] == condition]
        elapsed = [r['elapsed_ms'] for r in group]
        summary['conditions'][condition] = {
            'n': len(group), 'passed': sum(r['passed'] for r in group),
            'median_ms': statistics.median(elapsed) if elapsed else None,
            'p95_ms': quantile(elapsed, .95),
            'input_tokens': sum(r.get('metadata', {}).get('usage', {}).get('input_tokens', 0) for r in group),
            'output_tokens': sum(r.get('metadata', {}).get('usage', {}).get('output_tokens', 0) for r in group),
            'by_stratum': {s: {'n': sum(r['stratum'] == s for r in group),
                              'passed': sum(r['passed'] and r['stratum'] == s for r in group)}
                           for s in ['complete', 'ambiguous', 'adversarial']},
        }
    summary['paired_complete'] = sum(set(pair) == {'full', 'selected'} for pair in pairs.values())
    summary['paired_disagreement'] = sum(pair['full']['passed'] != pair['selected']['passed']
                                         for pair in pairs.values() if len(pair) == 2)
    summary['interpretation'] = 'Descriptive paired comparison on synthetic requests, not independent population sampling.'
    (folder / 'analysis.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    return summary


def execute(folder):
    if (folder / 'trials.jsonl').exists():
        raise SystemExit('Coleta já iniciada: não sobrescrever nem retomar automaticamente.')
    manifest = json.loads((folder / 'manifest.json').read_text())
    if hashlib.sha256((folder / 'corpus.jsonl').read_bytes()).hexdigest() != manifest['corpus_sha256']:
        raise SystemExit('Corpus divergente do congelamento.')
    prep = ROOT / 'experimentos/comparacao_contexto_20261108.py'
    if hashlib.sha256(prep.read_bytes()).hexdigest() != manifest['source_sha256']:
        raise SystemExit('Seletor/gerador divergente do congelamento.')
    cases = {c['case_id']: c for c in map(json.loads, (folder / 'corpus.jsonl').read_text().splitlines())}
    trials = list(map(json.loads, (folder / 'trials_prepared.jsonl').read_text().splitlines()))
    from experimentos.comparacao_contexto_20261108 import paired_trials
    if trials != paired_trials(list(cases.values())):
        raise SystemExit('Plano de chamadas difere da regeneração do corpus congelado.')
    # Os antigos backends não usam flock; evitar um segundo escritor do ledger.
    for port in (8765, 8768):
        with socket.socket() as sock:
            if sock.connect_ex(('127.0.0.1', port)) == 0:
                raise SystemExit(f'Escritor anterior pode estar ativo na porta {port}; não iniciar outra reserva.')
    cfg = json.loads((ROOT / 'prototipo/plataforma/.config.local.json').read_text())
    cap = Decimal(cfg['BICO_BUDGET_USD'])
    ledger = ROOT / 'prototipo/plataforma/.budget-reserved'
    before = Decimal(ledger.read_text())
    reserve = Decimal(manifest['estimated_additional_reservation_usd'])
    if before + reserve > cap:
        raise SystemExit('Estimativa excede o teto já autorizado/configurado; nenhuma chamada executada.')
    model = cfg['BICO_OPENAI_MODEL']
    if model != manifest['model_requested']:
        raise SystemExit('Modelo solicitado difere do plano congelado.')
    check = subprocess.run(['gh', 'api', 'repos/tav0dev/contecsi-2026-orquestracao', '--jq', '.full_name'],
                           capture_output=True, text=True, timeout=25)
    if check.returncode:
        raise SystemExit('Preflight GitHub falhou; nenhuma inferência executada.')
    http_json('GET', 'https://api.openai.com/v1/models/' + model,
              {'Authorization': 'Bearer ' + cfg['OPENAI_API_KEY']}, None)
    captured = {}

    def transport(method, url, headers, body):
        answer = http_json(method, url, headers, body, timeout=35)
        captured.clear()
        captured.update({k: answer.get(k) for k in ['id', 'model', 'created_at', 'status', 'service_tier']})
        return answer

    planner = OpenAIPlanner(cfg['OPENAI_API_KEY'], model,
                            cfg['BICO_INPUT_USD_PER_MILLION'], cfg['BICO_OUTPUT_USD_PER_MILLION'],
                            Budget(ledger, cap), transport=transport)
    startinfo = {'started_at': datetime.now(timezone.utc).isoformat(),
                 'planned': len(trials), 'cap_usd': str(cap), 'reserved_before_usd': str(before),
                 'executor_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                 'trials_prepared_sha256': hashlib.sha256((folder / 'trials_prepared.jsonl').read_bytes()).hexdigest(),
                 'retry_policy': 'none', 'database_accessed': False,
                 'body_factory_sha256': hashlib.sha256((ROOT / 'prototipo/planejador/server.py').read_bytes()).hexdigest()}
    (folder / 'run_start.json').write_text(json.dumps(startinfo, indent=2) + '\n')
    with (folder / 'trials.jsonl').open('x') as stream:
        for i, trial in enumerate(trials, 1):
            case = cases[trial['case_id']]
            row = {k: trial[k] for k in ['case_id', 'condition', 'repetition']}
            row.update({'stratum': case['stratum'], 'domain': case['domain'],
                        'started_at': datetime.now(timezone.utc).isoformat(), 'expected': case['expected'],
                        'passed': False, 'request_sha256': hashlib.sha256(json.dumps(
                            request_body(model, trial['payload']), sort_keys=True).encode()).hexdigest(),
                        'context_clients': len(trial['payload']['context']['clients']),
                        'context_services': len(trial['payload']['context']['services'])})
            started = time.perf_counter()
            try:
                actual, metadata = planner.plan(trial['payload'])
                row.update({'actual': actual, 'metadata': metadata, 'provider': dict(captured)})
                row['passed'] = (semantic_equal(actual, case['expected'])
                                 and isinstance(actual.get('draft'), str))
            except Exception as exc:
                row['error_type'] = type(exc).__name__
                if hasattr(exc, 'code') and isinstance(exc.code, (str, int)):
                    row['error_code'] = exc.code
            row['elapsed_ms'] = (time.perf_counter() - started) * 1000
            stream.write(json.dumps(row, ensure_ascii=False) + '\n'); stream.flush()
            if i % 12 == 0:
                print(json.dumps({'completed': i, 'planned': len(trials),
                                  'reserved_usd': ledger.read_text().strip()}), flush=True)
    summary = analyze(folder)
    finish = {'finished_at': datetime.now(timezone.utc).isoformat(),
              'completed': summary['completed'], 'planned': len(trials),
              'reserved_after_usd': ledger.read_text().strip(), 'database_changes': False,
              'trials_sha256': hashlib.sha256((folder / 'trials.jsonl').read_bytes()).hexdigest()}
    (folder / 'finish.json').write_text(json.dumps(finish, indent=2) + '\n')
    print(json.dumps(finish), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', type=Path)
    parser.add_argument('--analyze', type=Path)
    args = parser.parse_args()
    if bool(args.run) == bool(args.analyze):
        parser.error('Escolha --run ou --analyze.')
    execute(args.run) if args.run else print(json.dumps(analyze(args.analyze), ensure_ascii=False, indent=2))
