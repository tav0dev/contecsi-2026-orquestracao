"""Ensaia migrations e concorrência em PostgreSQL descartável, sem destino remoto.

Exige binários PostgreSQL já instalados ou extraídos. Reproduz apenas auth.users,
auth.uid() e os papéis usados pelas migrations; não sobe a plataforma Supabase.
O cluster usa somente socket Unix em diretório privado e é encerrado ao terminar.
"""
import argparse
from datetime import datetime, timedelta, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import time
import uuid

ROOT = Path(__file__).resolve().parents[1]
SQL_ROOT = ROOT / 'prototipo/bico_flutter/supabase'
BOOTSTRAP = """
CREATE ROLE anon NOLOGIN;
CREATE ROLE authenticated NOLOGIN;
CREATE ROLE service_role NOLOGIN BYPASSRLS;
CREATE SCHEMA auth;
CREATE TABLE auth.users(id uuid PRIMARY KEY);
CREATE FUNCTION auth.uid() RETURNS uuid LANGUAGE sql STABLE AS $$
 SELECT coalesce(nullif(current_setting('request.jwt.claim.sub',true),''),
   (nullif(current_setting('request.jwt.claims',true),'')::jsonb->>'sub'))::uuid
$$;
GRANT USAGE ON SCHEMA auth TO anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION auth.uid() TO anon,authenticated,service_role;
"""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pg-bin', type=Path, required=True)
    parser.add_argument('--pg-lib', type=Path)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.pg_bin = args.pg_bin.resolve()
    if args.output.exists():
        parser.error('A saída já existe; preserve o ensaio anterior')
    args.output.mkdir(parents=True)
    env = {**os.environ}
    if args.pg_lib:
        env['LD_LIBRARY_PATH'] = str(args.pg_lib.resolve())
    report = {'started_at': datetime.now(timezone.utc).isoformat(),
              'remote_access': False, 'auth_fixture': 'minimal SQL, not Supabase Auth',
              'steps': [], 'concurrency': [], 'status': 'failed'}
    sources = [*sorted((SQL_ROOT / 'migrations').glob('*.sql')),
               *sorted((SQL_ROOT / 'tests').glob('*.sql'))]
    report['source_sha256'] = {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}

    def command(argv, name, check=True):
        result = subprocess.run(argv, env=env, capture_output=True, text=True, timeout=45)
        (args.output / (name + '.log')).write_text(result.stdout + result.stderr)
        report['steps'].append({'name': name, 'exit_code': result.returncode})
        if check and result.returncode:
            raise RuntimeError(name + ' failed; see log')
        return result.stdout

    try:
        report['postgres_version'] = command([str(args.pg_bin / 'postgres'), '--version'], 'version').strip()
        with tempfile.TemporaryDirectory(prefix='contecsi-sql-', dir='/tmp') as folder:
            local = Path(folder)
            data, sock = local / 'data', local / 'socket'
            sock.mkdir(mode=0o700)
            command([str(args.pg_bin / 'initdb'), '-D', str(data), '-U', 'contecsi',
                     '--auth=trust', '--encoding=UTF8', '--no-locale'], 'initdb')
            started = False
            children = []
            base = [str(args.pg_bin / 'psql'), '-X', '-q', '-A', '-t', '-v', 'ON_ERROR_STOP=1',
                    '-h', str(sock), '-p', '55439', '-U', 'contecsi', '-d', 'postgres']

            def sql(query):
                result = subprocess.run(base + ['-c', query], env=env, capture_output=True,
                                        text=True, timeout=15)
                if result.returncode:
                    raise RuntimeError(result.stderr)
                return result.stdout.strip()

            def claims(user):
                return (f"SET LOCAL ROLE authenticated; SET LOCAL \"request.jwt.claim.sub\"='{user}'; "
                        f"SET LOCAL \"request.jwt.claims\"='{{\"sub\":\"{user}\",\"role\":\"authenticated\"}}'; ")

            def wait_for(app, event, process):
                deadline = time.monotonic() + 4
                while time.monotonic() < deadline:
                    if sql(f"SELECT 1 FROM pg_stat_activity WHERE application_name='{app}' AND {event}") == '1':
                        return
                    if process.poll() is not None:
                        raise RuntimeError('Race session exited before synchronization: ' + str(process.communicate()))
                    time.sleep(0.04)
                raise RuntimeError('No synchronized database wait for ' + app)

            try:
                command([str(args.pg_bin / 'pg_ctl'), '-D', str(data), '-l', str(args.output.resolve() / 'postgres.log'),
                         '-o', f"-h '' -k {sock} -p 55439", '-w', 'start'], 'start')
                started = True
                command(base + ['-c', BOOTSTRAP], 'auth_bootstrap')
                for source in sources:
                    command(base + ['-f', str(source)], source.stem)
                for index, (kind, expected) in enumerate([
                        ('same_request', 'duplicate'), ('same_schedule', 'conflict'),
                        ('last_stock', 'insufficient_stock')], 1):
                    user = str(uuid.uuid4())
                    sql(f"INSERT INTO auth.users(id) VALUES ('{user}')")
                    state = json.loads(sql('BEGIN; ' + claims(user) + 'SELECT public.bico_exp_setup(); COMMIT;'))
                    tenant = state['tenant_id']
                    if kind == 'last_stock':
                        sql(f"UPDATE bico_exp.stock SET on_hand=1 WHERE tenant_id='{tenant}'")
                    begins = datetime.now(timezone.utc) + timedelta(days=3)
                    first = {'request_id': 'race-a', 'tenant_id': tenant, 'client_id': 'cliente-demo',
                             'service_id': 'servico-demo', 'start': begins.isoformat(), 'duration_minutes': 60}
                    second = {**first}
                    if kind != 'same_request':
                        second['request_id'] = 'race-b'
                    if kind == 'last_stock':
                        second['start'] = (begins + timedelta(hours=2)).isoformat()
                    def submission(proposal, delay=False):
                        payload = json.dumps(proposal).replace("'", "''")
                        return ('BEGIN; ' + claims(user) +
                                f"SELECT public.bico_exp_submit('{payload}'::jsonb,true); " +
                                ('SELECT pg_sleep(5); ' if delay else '') + 'COMMIT;')
                    a_name, b_name = f'contecsi_race_a_{index}', f'contecsi_race_b_{index}'
                    a = subprocess.Popen(base + ['-c', submission(first, True)], env={**env, 'PGAPPNAME': a_name},
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    children.append(a)
                    wait_for(a_name, "wait_event='PgSleep'", a)
                    b = subprocess.Popen(base + ['-c', submission(second)], env={**env, 'PGAPPNAME': b_name},
                                         stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                    children.append(b)
                    wait_for(b_name, "wait_event_type='Lock'", b)
                    a_out, a_err = a.communicate(timeout=15)
                    b_out, b_err = b.communicate(timeout=15)
                    (args.output / (kind + '.log')).write_text(a_out + a_err + b_out + b_err)
                    if a.returncode or b.returncode:
                        raise RuntimeError('Race SQL failed: ' + kind)
                    a_result = json.loads(next(line for line in a_out.splitlines() if line.startswith('{')))
                    b_result = json.loads(next(line for line in b_out.splitlines() if line.startswith('{')))
                    assert a_result['status'] == 'committed', a_result
                    assert b_result['status'] == expected, b_result
                    final = json.loads(sql('BEGIN; ' + claims(user) +
                                           f"SELECT public.bico_exp_state('{tenant}'); COMMIT;"))
                    assert len(final['orders']) == len(final['receivables']) == 1, final
                    assert final['stock'][0]['reserved'] == 1, final
                    report['concurrency'].append({'case': kind, 'second_status': b_result['status'],
                                                  'lock_wait_observed': True, 'single_order_and_receivable': True})
                report['status'] = 'passed'
            finally:
                for child in children:
                    if child.poll() is None:
                        child.kill()
                        child.communicate()
                if started:
                    command([str(args.pg_bin / 'pg_ctl'), '-D', str(data), '-m', 'fast', '-w', 'stop'],
                            'stop', check=False)
    except Exception as error:
        report['error'] = type(error).__name__ + ': ' + str(error)
    finally:
        report['finished_at'] = datetime.now(timezone.utc).isoformat()
        (args.output / 'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
