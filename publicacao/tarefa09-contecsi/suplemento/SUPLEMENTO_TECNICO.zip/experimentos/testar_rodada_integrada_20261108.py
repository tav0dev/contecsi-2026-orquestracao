"""Regressão local da rodada atual, sem inferência paga ou banco remoto.

Não inclui a reprodução de respostas de coletas anteriores na contagem atual.
Falhas e saídas são preservadas; recusa sobrescrever uma execução existente.
"""
import argparse
from datetime import datetime, timezone
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    report = {'round_id': 'rodada_integrada_20261108',
              'started_at': datetime.now(timezone.utc).isoformat(),
              'paid_calls': 0, 'remote_business_operations': 0, 'steps': {}}
    tests = []
    for directory in ['prototipo/planejador', 'prototipo/plataforma',
                      'prototipo/integracoes', 'experimentos']:
        pattern = 'test*.py' if directory != 'experimentos' else 'test_*.py'
        # Separate loaders prevent discovery's package-root inference from
        # carrying over between standalone test directories.
        suite = unittest.TestLoader().discover(str(ROOT/directory), pattern=pattern)
        tests.extend(t for t in flatten(suite)
                     if not t.id().endswith('test_recorded_selected_responses_replay_through_integrated_flow'))
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.TestSuite(tests))
    (args.output/'python.log').write_text(stream.getvalue())
    report['steps']['python'] = {'tests': result.testsRun, 'failures': len(result.failures),
                                 'errors': len(result.errors), 'skipped': len(result.skipped),
                                 'passed': result.wasSuccessful(),
                                 'excluded': 'Historical recorded-response replay; no old observations counted.'}
    runtime_tmp = ROOT/'.cache/flutter-runtime-tmp'
    runtime_tmp.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ, DASH__SUPPRESS_ANALYTICS='true', FLUTTER_SUPPRESS_ANALYTICS='true',
               PUB_CACHE='/tmp/contecsi-pub-cache',
               FLUTTER_ROOT='/tmp/contecsi-flutter', TMPDIR=str(runtime_tmp),
               XDG_CONFIG_HOME=str(ROOT/'.cache/flutter-config-rodada-integrada-20261108'))
    commands = {
        'contratos_dart': ['/tmp/contecsi-flutter/bin/cache/dart-sdk/bin/dart',
                           'prototipo/bico_flutter/tool/experiment.dart', str(args.output.resolve()/'agenda')],
        'fluxo_dart': ['/tmp/contecsi-flutter/bin/cache/dart-sdk/bin/dart',
                       'prototipo/bico_flutter/tool/workflow_contracts.dart'],
        'flutter': ['/tmp/contecsi-flutter/bin/cache/dart-sdk/bin/dart',
                    '/tmp/contecsi-flutter/bin/cache/flutter_tools.snapshot',
                    '--no-version-check', 'test', '--no-pub', '--reporter', 'json'],
    }
    for name, command in commands.items():
        print('LOCAL_STAGE', name, flush=True)
        cwd = ROOT/'prototipo/laboratorio' if name == 'flutter' else ROOT
        try:
            proc = subprocess.run(command, cwd=cwd, env=env, capture_output=True, text=True, timeout=240)
            (args.output/(name+'.stdout')).write_text(proc.stdout)
            (args.output/(name+'.stderr')).write_text(proc.stderr)
            report['steps'][name] = {'exit_code': proc.returncode, 'passed': proc.returncode == 0}
        except subprocess.TimeoutExpired as error:
            (args.output/(name+'.stdout')).write_bytes(error.stdout or b'')
            (args.output/(name+'.stderr')).write_bytes(error.stderr or b'')
            report['steps'][name] = {'passed': False, 'status': 'instrument_timeout'}
        (args.output/'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    report['finished_at'] = datetime.now(timezone.utc).isoformat()
    report['status'] = 'passed' if all(s['passed'] for s in report['steps'].values()) else 'failed'
    (args.output/'summary.json').write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
