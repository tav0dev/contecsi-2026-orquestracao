"""Backup lógico do projeto autorizado, sem alterar tabelas ou redefinir senhas.

Cria pelo Management API um login temporário para o pg_dump, com transações
somente leitura. O login precisa ler também os schemas gerenciados auth/storage.
A senha temporária permanece apenas na memória e expira conforme o TTL do serviço.
O diretório de saída é privado; não versionar dumps de Auth ou dados existentes.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess

try:
    from .inspect_supabase import PROJECT_REF, request
except ImportError:
    from inspect_supabase import PROJECT_REF, request


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--token-file', type=Path, required=True)
    parser.add_argument('--pg-bin', type=Path, required=True)
    parser.add_argument('--pg-lib', type=Path)
    parser.add_argument('--ssl-root-cert', type=Path,
                        help='CA oficial Supabase; sem esta opção usa as CAs do sistema')
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    if args.output_dir.exists():
        parser.error('Diretório de saída já existe; não sobrescrever backup')
    args.output_dir.mkdir(mode=0o700, parents=True)
    args.output_dir.chmod(0o700)
    report = {'checked_at': datetime.now(timezone.utc).isoformat(), 'target_ref': PROJECT_REF,
              'schema_mutations': False, 'temporary_backup_login_created': False,
              'default_transaction_read_only': True,
              'status': 'failed', 'files': []}
    try:
        token = args.token_file.read_text().strip()
        project = request(f'projects/{PROJECT_REF}', token)
        if project['id'] != PROJECT_REF or project['status'] != 'ACTIVE_HEALTHY':
            raise RuntimeError('Projeto autorizado não está ativo e saudável')
        poolers = request(f'projects/{PROJECT_REF}/config/database/pooler', token)
        pooler = next(p for p in poolers if p['database_type'] == 'PRIMARY')
        login = request(f'projects/{PROJECT_REF}/cli/login-role', token, {'read_only': False})
        report['temporary_backup_login_created'] = True
        report['temporary_login_ttl_seconds'] = login['ttl_seconds']
        env = {**os.environ, 'PGPASSWORD': login['password'], 'PGSSLMODE': 'verify-full',
               'PGSSLROOTCERT': str(args.ssl_root_cert.resolve()) if args.ssl_root_cert else 'system',
               'PGCONNECT_TIMEOUT': '15',
               'PGOPTIONS': '-c default_transaction_read_only=on'}
        if args.pg_lib:
            env['LD_LIBRARY_PATH'] = str(args.pg_lib.resolve())
        base = [str(args.pg_bin.resolve() / 'pg_dump'), '--format=custom', '--role=postgres',
                '--host=' + pooler['db_host'], '--port=' + str(pooler['db_port']),
                '--username=' + login['role'] + '.' + PROJECT_REF, '--dbname=' + pooler['db_name']]
        for filename, extra in [('database.dump', []), ('application_public.dump', ['--schema=public'])]:
            target = args.output_dir / filename
            descriptor = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            os.close(descriptor)
            result = subprocess.run(base + extra + ['--file=' + str(target)], env=env,
                                    capture_output=True, text=True, timeout=180)
            (args.output_dir / (filename + '.log')).write_text(result.stderr)
            if result.returncode:
                raise RuntimeError('pg_dump falhou; ver log privado de ' + filename)
            listing = subprocess.run([str(args.pg_bin.resolve() / 'pg_restore'), '--list', str(target)],
                                     env=env, capture_output=True, text=True, timeout=20)
            if listing.returncode:
                raise RuntimeError('pg_restore não conseguiu ler o catálogo do backup')
            (args.output_dir / (filename + '.toc')).write_text(listing.stdout)
            report['files'].append({'name': filename, 'bytes': target.stat().st_size,
                                    'sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                                    'archive_catalog_readable': True})
        report['status'] = 'backed_up'
    except Exception as error:
        report['reason'] = type(error).__name__ + ': ' + str(error)
    for file in args.output_dir.iterdir():
        if file.is_file():
            file.chmod(0o600)
    manifest = args.output_dir / 'manifest.json'
    descriptor = os.open(manifest, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(descriptor, 'w') as stream:
        json.dump(report, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report['status'] == 'backed_up' else 1


if __name__ == '__main__':
    raise SystemExit(main())
