"""Adaptadores de servidor. Sem execução na importação, sem retries de escrita.

Referências e limites em documentacao/05_INTEGRACOES_E_ESCOPO.md.
O transporte injetável permite testes sem rede; não representa homologação.
"""
import base64
import hashlib
import hmac
import json
import urllib.request


def http_json(method, url, headers, payload, *, timeout=20):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None  # Não reenviar credenciais para outro host.
    data = None if payload is None else json.dumps(payload).encode()
    request = urllib.request.Request(url, data=data, headers=headers, method=method)
    with urllib.request.build_opener(NoRedirect()).open(request, timeout=timeout) as response:
        return json.load(response)


class AbacatePaySandbox:
    """Somente PIX v2 em Dev mode. Recusa chaves de produção antes do HTTP."""
    def __init__(self, key, transport=http_json):
        if not isinstance(key, str) or not key.startswith('dev_'):
            raise ValueError('Chave Dev mode obrigatória; produção desabilitada')
        self._key, self._transport = key, transport

    def create_pix(self, *, external_id, amount_cents, approved):
        if approved is not True:
            raise ValueError('Aprovação explícita obrigatória')
        if type(amount_cents) is not int or amount_cents < 100:
            raise ValueError('Valor em centavos, mínimo 100')
        if not isinstance(external_id, str) or not external_id.strip():
            raise ValueError('Identificador obrigatório')
        response = self._transport('POST', 'https://api.abacatepay.com/v2/transparents/create',
            {'Authorization': 'Bearer '+self._key, 'Content-Type': 'application/json'},
            {'method': 'PIX', 'data': {'amount': amount_cents, 'expiresIn': 3600,
                'description': 'Atendimento sintético Bico', 'externalId': external_id}})
        data = response.get('data') or {}
        if response.get('error') or not response.get('success'):
            raise ValueError('Provedor não confirmou a criação')
        if data.get('devMode') is not True or not data.get('id'):
            raise ValueError('Resposta sem confirmação de sandbox/id; reconciliar manualmente')
        if type(data.get('amount')) is not int or data['amount'] != amount_cents:
            raise ValueError('Valor divergente; reconciliar manualmente')
        return {k: data.get(k) for k in ('id', 'amount', 'status', 'devMode', 'brCode', 'expiresAt')}


class ZernioDrafts:
    """Cria rascunhos. A conta deve constar no vínculo do tenant autenticado.

    approved_tenant não pode vir de texto da IA: é contexto do servidor.
    Não implementa publicação nem envio de mensagens privadas.
    """
    def __init__(self, key, account_bindings, transport=http_json):
        if not key:
            raise ValueError('Credencial ausente')
        self._key, self._bindings, self._transport = key, dict(account_bindings), transport

    def create_draft(self, *, approved_tenant, account_id, platform, content, request_id, approved):
        if approved is not True or not approved_tenant:
            raise ValueError('Aprovação e tenant autenticado obrigatórios')
        if self._bindings.get(account_id) != (approved_tenant, platform):
            raise ValueError('Conta/canal não pertence ao negócio autenticado')
        if not isinstance(content, str) or not content.strip() or not request_id:
            raise ValueError('Conteúdo e identificador obrigatórios')
        response = self._transport('POST', 'https://zernio.com/api/v1/posts',
            {'Authorization': 'Bearer '+self._key, 'Content-Type': 'application/json',
             'Idempotency-Key': request_id},
            {'content': content, 'isDraft': True, 'publishNow': False,
             'platforms': [{'platform': platform, 'accountId': account_id}]})
        post = response.get('post') or {}
        if not post.get('_id') and not post.get('id'):
            raise ValueError('Resposta sem id; reconciliar manualmente')
        return {'id': post.get('_id') or post.get('id'), 'requested_mode': 'draft'}


def verify_abacate(raw, signature, supplied_secret, *, shared_secret, public_hmac_key):
    """A chave HMAC é pública: autenticação exige também o secret privado."""
    if not shared_secret or not supplied_secret or not public_hmac_key or not signature:
        return False
    expected = base64.b64encode(hmac.digest(public_hmac_key.encode(), raw, 'sha256')).decode()
    return hmac.compare_digest(shared_secret, supplied_secret) and hmac.compare_digest(expected, signature)


def verify_zernio(raw, signature, *, shared_secret):
    if not shared_secret or not signature:
        return False
    return hmac.compare_digest(hmac.new(shared_secret.encode(), raw, hashlib.sha256).hexdigest(), signature)
