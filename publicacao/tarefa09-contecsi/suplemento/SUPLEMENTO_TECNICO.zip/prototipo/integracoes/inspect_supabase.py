"""Inspeção somente leitura do projeto experimental Bico.

SUPABASE_ACCESS_TOKEN é lido do ambiente, nunca impresso ou persistido.
--token-file permite usar explicitamente uma credencial local já existente.
Não usa vínculo global do npx/MCP e não contém opção para aplicar SQL.
"""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sys
import urllib.request

PROJECT_REF = 'wzychmshebmznjfducug'
SQL = """BEGIN READ ONLY;
SELECT jsonb_build_object(
 'columns',(SELECT jsonb_agg(to_jsonb(c)) FROM
   (SELECT table_schema,table_name,column_name,data_type,is_nullable,column_default
    FROM information_schema.columns WHERE table_schema IN ('public','bico_exp')
    ORDER BY table_schema,table_name,ordinal_position) c),
 'policies',(SELECT jsonb_agg(to_jsonb(p)) FROM
   (SELECT schemaname,tablename,policyname,roles,cmd,qual,with_check FROM pg_policies
    WHERE schemaname IN ('public','bico_exp')) p),
 'constraints',(SELECT jsonb_agg(to_jsonb(k)) FROM
   (SELECT n.nspname AS schema,t.relname AS table_name,c.conname,
    pg_get_constraintdef(c.oid) AS definition FROM pg_constraint c
    JOIN pg_class t ON t.oid=c.conrelid JOIN pg_namespace n ON n.oid=t.relnamespace
    WHERE n.nspname IN ('public','bico_exp')) k),
 'row_estimates',(SELECT jsonb_agg(to_jsonb(s)) FROM
   (SELECT schemaname,relname,n_live_tup FROM pg_stat_user_tables
    WHERE schemaname IN ('public','bico_exp')) s)
) AS inspection;
COMMIT;"""


def request(path, token, payload=None):
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs): return None
    headers={'Authorization':'Bearer '+token,'Content-Type':'application/json'}
    req=urllib.request.Request('https://api.supabase.com/v1/'+path,headers=headers,
        data=None if payload is None else json.dumps(payload).encode(),
        method='GET' if payload is None else 'POST')
    with urllib.request.build_opener(NoRedirect()).open(req,timeout=20) as response:
        return json.load(response)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--token-file',type=Path,
        help='Arquivo de token existente; quando informado, tem precedência sobre o ambiente')
    args=parser.parse_args()
    if args.output.exists():parser.error('A saída já existe; preserve a inspeção anterior')
    report={'checked_at':datetime.now(timezone.utc).isoformat(),
        'target_ref':PROJECT_REF,'remote_mutations':False}
    try:
        token=(args.token_file.read_text().strip() if args.token_file
               else os.environ.get('SUPABASE_ACCESS_TOKEN'))
        if not token:raise RuntimeError('SUPABASE_ACCESS_TOKEN ausente')
        projects=request('projects',token)
        match=next((p for p in projects if p.get('id')==PROJECT_REF),None)
        if not match:raise RuntimeError('Projeto Bico não acessível com este token; conta não confirmada')
        report['project']={k:match.get(k) for k in ('id','name','region','status')}
        report['inspection']=request(f'projects/{PROJECT_REF}/database/query',token,{'query':SQL,'read_only':True})
        report['status']='verified'
    except Exception as error:
        # Não inclui corpo de erro HTTP nem headers de autenticação.
        report.update(status='unverified',reason=type(error).__name__+': '+str(error))
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='inspection'},ensure_ascii=False))
    return 0 if report['status']=='verified' else 1


if __name__=='__main__':sys.exit(main())
