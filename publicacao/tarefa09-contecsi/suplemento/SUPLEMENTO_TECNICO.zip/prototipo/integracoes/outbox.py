"""Fila persistente local, destinada ao laboratório sintético de processo único.

Não é um repositório Supabase nem um servidor multiusuário. Uma escrita externa
com resultado incerto fica bloqueada para reconciliação, inclusive após crash.
"""
import hashlib
import json
import sqlite3


class Outbox:
    def __init__(self, path):
        self.db = sqlite3.connect(path)
        self.db.execute('''CREATE TABLE IF NOT EXISTS operations (
            tenant TEXT NOT NULL, request_id TEXT NOT NULL, digest TEXT NOT NULL,
            state TEXT NOT NULL, result TEXT, PRIMARY KEY (tenant, request_id))''')
        self.db.execute('''CREATE TABLE IF NOT EXISTS events (
            provider TEXT NOT NULL, event_id TEXT NOT NULL, digest TEXT NOT NULL,
            PRIMARY KEY(provider,event_id))''')
        self.db.commit()

    def close(self):
        self.db.close()

    def execute(self, *, operation, tenant, request_id, payload, approved, dispatch):
        if operation not in ('abacatepay.pix', 'zernio.draft'):
            raise ValueError('Operação não permitida')
        if approved is not True or not tenant or not request_id:
            raise ValueError('Aprovação, tenant e id obrigatórios')
        digest = hashlib.sha256(json.dumps({'operation':operation,'payload':payload}, sort_keys=True,
            separators=(',', ':'), allow_nan=False).encode()).hexdigest()
        # BEGIN IMMEDIATE serializa a reivindicação entre conexões locais.
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            row = self.db.execute('SELECT digest,state,result FROM operations WHERE tenant=? AND request_id=?',
                                  (tenant, request_id)).fetchone()
            if row:
                if row[0] != digest:
                    raise ValueError('idempotency_mismatch')
                if row[1] == 'succeeded':
                    return json.loads(row[2])
                raise RuntimeError('reconciliation_required')
            self.db.execute('INSERT INTO operations VALUES (?,?,?,?,NULL)',
                            (tenant, request_id, digest, 'reconciliation_required'))
        # Commit anterior ao HTTP: sem retry automático após timeout ou crash.
        result = dispatch(payload)
        encoded = json.dumps(result, allow_nan=False)
        with self.db:
            self.db.execute('UPDATE operations SET state=?,result=? WHERE tenant=? AND request_id=?',
                            ('succeeded', encoded, tenant, request_id))
        return result

    def record_verified_event(self, provider, event_id, raw):
        """Registro de deduplicação: chamar APÓS autenticação. Não liquida títulos.

        tenant/charge devem ser resolvidos pelo vínculo persistido no servidor.
        A retenção e o processamento transacional do payload no Supabase
        continuam pendentes. Este registro guarda somente seu hash.
        """
        if provider not in ('abacatepay', 'zernio') or not event_id:
            raise ValueError('Evento inválido')
        digest = hashlib.sha256(raw).hexdigest()
        with self.db:
            self.db.execute('BEGIN IMMEDIATE')
            prior = self.db.execute('SELECT digest FROM events WHERE provider=? AND event_id=?',
                                    (provider, event_id)).fetchone()
            if prior:
                if prior[0] != digest:
                    raise ValueError('event_payload_mismatch')
                return 'duplicate'
            self.db.execute('INSERT INTO events VALUES (?,?,?)', (provider, event_id, digest))
        return 'recorded'
