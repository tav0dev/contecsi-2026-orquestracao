import base64
import hmac
import tempfile
import unittest
from pathlib import Path
from providers import AbacatePaySandbox, ZernioDrafts, verify_abacate, verify_zernio
from outbox import Outbox


class ProviderTests(unittest.TestCase):
    def test_pix_v2_amount_and_sandbox(self):
        calls=[]
        def transport(*args):
            calls.append(args)
            return {'success':True,'data':{'id':'pix_test','amount':5000,'devMode':True,'status':'PENDING'}}
        p=AbacatePaySandbox('dev_synthetic',transport)
        self.assertEqual(p.create_pix(external_id='t1:r1',amount_cents=5000,approved=True)['id'],'pix_test')
        self.assertEqual(calls[0][1],'https://api.abacatepay.com/v2/transparents/create')
        self.assertEqual(calls[0][3]['data']['amount'],5000)
        self.assertEqual(calls[0][3]['method'],'PIX')

    def test_production_key_rejected(self):
        with self.assertRaises(ValueError):AbacatePaySandbox('prod_synthetic')

    def test_no_approval_no_network(self):
        p=AbacatePaySandbox('dev_synthetic',lambda *args:self.fail('Não deveria chamar HTTP'))
        with self.assertRaises(ValueError):p.create_pix(external_id='r1',amount_cents=5000,approved=False)

    def test_float_bool_and_small_amounts_rejected(self):
        p=AbacatePaySandbox('dev_synthetic',lambda *args:self.fail('Não deveria chamar HTTP'))
        for amount in (50.0,True,99,-1):
            with self.subTest(amount=amount), self.assertRaises(ValueError):
                p.create_pix(external_id='r1',amount_cents=amount,approved=True)

    def test_missing_or_wrong_dev_mode_not_success(self):
        for mode in (False,None):
            p=AbacatePaySandbox('dev_synthetic',lambda *args:{'success':True,
                'data':{'id':'pix_test','amount':5000,'devMode':mode}})
            with self.subTest(mode=mode),self.assertRaises(ValueError):
                p.create_pix(external_id='r1',amount_cents=5000,approved=True)

    def test_amount_mismatch_rejected(self):
        p=AbacatePaySandbox('dev_synthetic',lambda *args:{'success':True,
            'data':{'id':'pix_test','amount':5001,'devMode':True}})
        with self.assertRaises(ValueError):p.create_pix(external_id='r1',amount_cents=5000,approved=True)

    def test_zernio_draft_never_publish(self):
        calls=[]
        def transport(*args):calls.append(args);return {'post':{'_id':'post_test'}}
        z=ZernioDrafts('synthetic',{'acc':('t1','instagram')},transport)
        result=z.create_draft(approved_tenant='t1',account_id='acc',platform='instagram',
            content='Demonstração sintética.',request_id='t1:r1',approved=True)
        self.assertEqual(result['id'],'post_test')
        self.assertTrue(calls[0][3]['isDraft']);self.assertFalse(calls[0][3]['publishNow'])
        self.assertNotIn('scheduledFor',calls[0][3])

    def test_zernio_account_cannot_cross_tenants(self):
        z=ZernioDrafts('synthetic',{'acc':('t1','instagram')},lambda *args:self.fail('HTTP indevido'))
        with self.assertRaises(ValueError):z.create_draft(approved_tenant='t2',account_id='acc',
            platform='instagram',content='Texto',request_id='r1',approved=True)

    def test_abacate_signature_alone_does_not_authenticate(self):
        raw=b'{"id":"evt1"}'
        sig=base64.b64encode(hmac.digest(b'public-key',raw,'sha256')).decode()
        kw={'shared_secret':'private-secret','public_hmac_key':'public-key'}
        self.assertFalse(verify_abacate(raw,sig,'wrong',**kw))
        self.assertTrue(verify_abacate(raw,sig,'private-secret',**kw))
        self.assertFalse(verify_abacate(raw+b' ',sig,'private-secret',**kw))

    def test_zernio_raw_body_signature(self):
        raw=b'{"id":"evt1"}';sig=hmac.digest(b'secret',raw,'sha256').hex()
        self.assertTrue(verify_zernio(raw,sig,shared_secret='secret'))
        self.assertFalse(verify_zernio(raw+b' ',sig,shared_secret='secret'))


class PersistenceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=Path(self.tmp.name)/'outbox.db';self.box=Outbox(self.path)
    def tearDown(self):self.box.close();self.tmp.cleanup()
    def execute(self,**changes):
        args={'operation':'abacatepay.pix','tenant':'t1','request_id':'r1','payload':{'amount':5000},'approved':True,
              'dispatch':lambda p:{'id':'pix_test'}}
        args.update(changes);return self.box.execute(**args)

    def test_success_replay_survives_reopen(self):
        self.execute();self.box.close();self.box=Outbox(self.path)
        self.assertEqual(self.execute(dispatch=lambda p:self.fail('Duplicou cobrança')),{'id':'pix_test'})
    def test_mutated_replay_blocked(self):
        self.execute()
        with self.assertRaisesRegex(ValueError,'idempotency_mismatch'):self.execute(payload={'amount':5001})
    def test_operation_is_part_of_idempotency(self):
        self.execute()
        with self.assertRaisesRegex(ValueError,'idempotency_mismatch'):self.execute(operation='zernio.draft')
    def test_timeout_cannot_retry_and_survives_reopen(self):
        def timeout(p):raise TimeoutError('Resultado remoto incerto')
        with self.assertRaises(TimeoutError):self.execute(dispatch=timeout)
        self.box.close();self.box=Outbox(self.path)
        with self.assertRaisesRegex(RuntimeError,'reconciliation_required'):
            self.execute(dispatch=lambda p:self.fail('Retry inseguro'))
    def test_request_id_is_scoped_to_tenant(self):
        self.execute();self.assertEqual(self.execute(tenant='t2'),{'id':'pix_test'})
    def test_no_approval_does_not_enqueue(self):
        with self.assertRaises(ValueError):self.execute(approved=False)
        self.assertEqual(self.box.db.execute('SELECT count(*) FROM operations').fetchone()[0],0)
    def test_events_duplicate_and_changed_payload(self):
        self.assertEqual(self.box.record_verified_event('zernio','evt1',b'{}'),'recorded')
        self.assertEqual(self.box.record_verified_event('zernio','evt1',b'{}'),'duplicate')
        with self.assertRaisesRegex(ValueError,'event_payload_mismatch'):
            self.box.record_verified_event('zernio','evt1',b'{"changed":true}')


if __name__=='__main__':unittest.main(verbosity=2)
