import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:bico_laboratorio/main.dart';

void main() {
  testWidgets('Revisar não grava; confirmação explícita grava uma vez', (tester) async {
    await tester.pumpWidget(const ExperimentApp());
    expect(find.text('Agendamentos registrados: 0'),findsOneWidget);
    await tester.tap(find.text('Revisar proposta'));
    await tester.pump();
    // A revisão acrescenta conteúdo; a contagem pode ficar abaixo da viewport.
    await tester.scrollUntilVisible(find.text('Agendamentos registrados: 0'), 150,
      scrollable: find.byType(Scrollable).first);
    expect(find.text('Agendamentos registrados: 0'),findsOneWidget);
    await tester.ensureVisible(find.text('Confirmar agendamento'));
    await tester.tap(find.text('Confirmar agendamento'));
    await tester.pump();
    expect(find.text('Agendamentos registrados: 1'),findsOneWidget);
    expect(find.text('Confirmar agendamento'),findsNothing);
    await tester.scrollUntilVisible(find.text('Rascunhos locais: 1'), 100,
      scrollable: find.byType(Scrollable).first);
    expect(find.text('Kits disponíveis: 2'),findsOneWidget);
    expect(find.text('A receber (local): R\$ 50.00'),findsOneWidget);
    expect(find.text('Rascunhos locais: 1'),findsOneWidget);
  });
  testWidgets('JSON inválido não permite confirmação', (tester) async {
    await tester.pumpWidget(const ExperimentApp());
    await tester.enterText(find.byType(TextField),'{"action":"delete_all"}');
    await tester.tap(find.text('Revisar proposta'));
    await tester.pump();
    expect(find.text('Confirmar agendamento'),findsNothing);
    expect(find.text('Agendamentos registrados: 0'),findsOneWidget);
    expect(find.textContaining('Proposta inválida.'),findsOneWidget);
  });
}
