// Capturas do widget real com transporte HTTP substituído por dados sintéticos.
// Não são evidências de autenticação, inferência ou integração externa.
import 'dart:io';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:bico_laboratorio/screens/remote_workflow_screen.dart';

import 'remote_workflow_test.dart' as fixture;

Future<void> fonts() async {
  for (final entry in {
    'Roboto': ['Roboto-Regular.ttf', 'Roboto-Medium.ttf', 'Roboto-Bold.ttf'],
    'MaterialIcons': ['MaterialIcons-Regular.otf'],
  }.entries) {
    final loader = FontLoader(entry.key);
    for (final filename in entry.value) {
      loader.addFont(
        Future.value(
          ByteData.sublistView(
            File(
              '/tmp/contecsi-flutter/bin/cache/artifacts/material_fonts/$filename',
            ).readAsBytesSync(),
          ),
        ),
      );
    }
    await loader.load();
  }
}

Finder panel(String title) => find
    .ancestor(
      of: find.text(title),
      matching: find.byWidgetPredicate(
        (widget) => widget.runtimeType.toString() == '_Panel',
      ),
    )
    .first;

Future<void> capture(
  WidgetTester tester,
  GlobalKey key,
  Rect bounds,
  String filename,
) async {
  await tester.runAsync(() async {
    final boundary =
        key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
    final layer = boundary.debugLayer! as OffsetLayer;
    final image = await layer.toImage(bounds, pixelRatio: 2);
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    final target = File('../../documentacao/figuras/$filename');
    await target.parent.create(recursive: true);
    await target.writeAsBytes(bytes!.buffer.asUint8List());
    image.dispose();
  });
}

void main() {
  testWidgets('Figura revisão: renderização da proposta antes da autorização', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(540, 2400);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.runAsync(fonts);
    final key = GlobalKey();
    final calls = <String>[];
    await tester.pumpWidget(
      RepaintBoundary(
        key: key,
        child: MaterialApp(
          home: RemoteWorkflowScreen(api: fixture.apiFor(calls)),
        ),
      ),
    );
    await tester.pumpAndSettle();
    await fixture.prepare(tester);
    expect(calls, ['/state', '/plan']);
    await capture(
      tester,
      key,
      tester.getRect(panel('Confira antes de agendar')),
      'revisao.png',
    );
  });

  testWidgets(
    'Figura acompanhamento: agenda, materiais e valor após confirmação sintética',
    (tester) async {
      tester.view.physicalSize = const Size(540, 2400);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.runAsync(fonts);
      final key = GlobalKey();
      final calls = <String>[];
      await tester.pumpWidget(
        RepaintBoundary(
          key: key,
          child: MaterialApp(
            home: RemoteWorkflowScreen(api: fixture.apiFor(calls)),
          ),
        ),
      );
      await tester.pumpAndSettle();
      await fixture.prepare(tester);
      await tester.tap(find.byKey(const Key('confirm-booking')));
      await tester.pumpAndSettle();
      expect(calls, ['/state', '/plan', '/confirm', '/state']);
      final agenda = tester.getRect(panel('Sua agenda'));
      final lastPanel = find
          .byWidgetPredicate(
            (widget) => widget.runtimeType.toString() == '_Panel',
          )
          .last;
      final bounds = agenda.expandToInclude(tester.getRect(lastPanel));
      await capture(tester, key, bounds, 'acompanhamento.png');
    },
  );
}
