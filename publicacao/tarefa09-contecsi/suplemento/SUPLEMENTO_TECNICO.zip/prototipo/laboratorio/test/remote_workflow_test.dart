import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:http/http.dart' as http;
import 'package:http/testing.dart';
import 'package:bico_laboratorio/services/workflow_api.dart';
import 'package:bico_laboratorio/screens/remote_workflow_screen.dart';

const proposal = {
  'request_id': 'r1',
  'tenant_id': 'tenant-test',
  'client_id': 'c1',
  'service_id': 's1',
  'start': '2030-11-09T17:00:00Z',
  'duration_minutes': 60,
};
Map<String, dynamic> snapshot({bool reserved = false}) => {
  'tenant_id': 'tenant-test',
  'name': 'Meu negócio',
  'clients': [
    {'id': 'c1', 'label': 'Ana Silva'},
  ],
  'services': [
    {
      'id': 's1',
      'label': 'Atendimento demonstrativo',
      'duration_minutes': 60,
      'price_cents': 5000,
    },
  ],
  'orders': reserved
      ? [
          {...proposal, 'starts_at': proposal['start'], 'state': 'reserved'},
        ]
      : [],
  'receivables': reserved
      ? [
          {'request_id': 'r1', 'amount_cents': 5000, 'state': 'pending'},
        ]
      : [],
  'stock': [
    {
      'sku': 'kit',
      'on_hand': 3,
      'reserved': reserved ? 1 : 0,
      'available': reserved ? 2 : 3,
    },
  ],
  'capabilities': {'ai': true, 'payments': false, 'social': false},
};

WorkflowApi apiFor(
  List<String> calls, {
  String reviewStatus = 'awaiting_confirmation',
  String confirmStatus = 'committed',
  bool existing = false,
  bool refreshFailsAfterConfirm = false,
}) {
  var reserved = existing;
  return WorkflowApi(
    tokenProvider: () => 'synthetic-session',
    client: MockClient((r) async {
      calls.add(r.url.path);
      if (r.url.path == '/state' && reserved && refreshFailsAfterConfirm) {
        return http.Response('{"error":"upstream_unavailable"}', 502);
      }
      if (r.url.path == '/state')
        return http.Response(jsonEncode(snapshot(reserved: reserved)), 200);
      if (r.url.path == '/plan')
        return http.Response(
          jsonEncode({
            'plan': {'status': 'proposed', 'draft': 'Confira o atendimento.'},
            'metadata': {'model': 'test-double'},
            'review': {'status': reviewStatus, 'amount_cents': 5000},
            'proposal': proposal,
          }),
          200,
        );
      if (r.url.path == '/confirm') {
        final body = jsonDecode(r.body);
        expect(body['approved'], isTrue);
        expect(body['proposal'], proposal);
        if (confirmStatus == 'committed') reserved = true;
        return http.Response(jsonEncode({'status': confirmStatus}), 200);
      }
      throw StateError('Chamada inesperada: ' + r.url.path);
    }),
  );
}

Future<void> prepare(WidgetTester tester) async {
  if (find.byKey(const Key('request-field')).evaluate().isEmpty) {
    await tester.tap(find.byKey(const Key('ask-ai')));
    await tester.pumpAndSettle();
  }
  await tester.ensureVisible(find.byKey(const Key('request-field')));
  await tester.enterText(
    find.byKey(const Key('request-field')),
    'Agende Ana em 09/11/2030 às 14h.',
  );
  await tester.pumpAndSettle();
  await tester.ensureVisible(find.byKey(const Key('prepare-button')));
  await tester.tap(find.byKey(const Key('prepare-button')));
  await tester.pumpAndSettle();
}

void main() {
  test('API usa JWT na chamada ao backend e recusa redirecionamento', () async {
    final client = MockClient((request) async {
      expect(request.url.path, '/state');
      expect(request.headers['Authorization'], 'Bearer synthetic-session');
      expect(request.followRedirects, isFalse);
      return http.Response(jsonEncode(snapshot()), 200);
    });
    final api = WorkflowApi(
      client: client,
      tokenProvider: () => 'synthetic-session',
    );
    expect((await api.call('/state'))['tenant_id'], 'tenant-test');
    api.close();
  });
  test('API sem sessão não chama rede', () async {
    final api = WorkflowApi(
      client: MockClient((_) async {
        fail('HTTP indevido');
      }),
    );
    expect(() => api.call('/state'), throwsStateError);
    api.close();
  });
  test('Erro do servidor não é convertido em sucesso local', () async {
    final api = WorkflowApi(
      client: MockClient(
        (_) async => http.Response('{"error":"session_expired"}', 401),
      ),
      tokenProvider: () => 'synthetic-session',
    );
    await expectLater(api.call('/state'), throwsStateError);
    api.close();
  });
  test('Backend remoto sem HTTPS é recusado', () {
    expect(
      () => WorkflowApi(baseUrl: 'http://example.test'),
      throwsArgumentError,
    );
  });

  testWidgets(
    'Revisão legível; somente o clique explícito agenda e exibe o resultado',
    (tester) async {
      final calls = <String>[];
      await tester.pumpWidget(
        MaterialApp(home: RemoteWorkflowScreen(api: apiFor(calls))),
      );
      await tester.pumpAndSettle();
      expect(calls, ['/state']); // Dados carregados automaticamente ao entrar.
      await prepare(tester);
      expect(calls, ['/state', '/plan']);
      expect(find.text('Confira antes de agendar'), findsOneWidget);
      expect(find.text('09/11/2030 às 14:00'), findsOneWidget);
      expect(find.text(r'R$ 50,00'), findsOneWidget);
      expect(find.textContaining('request_id'), findsNothing);
      expect(find.textContaining('awaiting_confirmation'), findsNothing);
      expect(find.textContaining('test-double'), findsNothing);
      expect(find.byType(AlertDialog), findsNothing);
      await tester.ensureVisible(find.byKey(const Key('confirm-booking')));
      await tester.tap(find.byKey(const Key('confirm-booking')));
      await tester.pumpAndSettle();
      expect(calls, ['/state', '/plan', '/confirm', '/state']);
      expect(find.text('Atendimento agendado'), findsOneWidget);
      expect(find.text('Agendado'), findsOneWidget);
      expect(find.byKey(const Key('confirm-booking')), findsNothing);
      expect(find.byType(AlertDialog), findsNothing);
    },
  );

  testWidgets('Editar o pedido invalida a aprovação anterior', (tester) async {
    final calls = <String>[];
    await tester.pumpWidget(
      MaterialApp(home: RemoteWorkflowScreen(api: apiFor(calls))),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('ask-ai')));
    await tester.pumpAndSettle();
    final emptyButton = tester.widget<IconButton>(
      find.byKey(const Key('prepare-button')),
    );
    expect(emptyButton.onPressed, isNull);
    await prepare(tester);
    expect(find.byKey(const Key('confirm-booking')), findsOneWidget);
    await tester.ensureVisible(find.byKey(const Key('request-field')));
    await tester.enterText(
      find.byKey(const Key('request-field')),
      'Mude para outro horário.',
    );
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('confirm-booking')), findsNothing);
    expect(calls, ['/state', '/plan']);
  });

  testWidgets('Conflito após a revisão mostra orientação e não sucesso', (
    tester,
  ) async {
    final calls = <String>[];
    await tester.pumpWidget(
      MaterialApp(
        home: RemoteWorkflowScreen(
          api: apiFor(calls, confirmStatus: 'conflict'),
        ),
      ),
    );
    await tester.pumpAndSettle();
    await prepare(tester);
    await tester.ensureVisible(find.byKey(const Key('confirm-booking')));
    await tester.tap(find.byKey(const Key('confirm-booking')));
    await tester.pumpAndSettle();
    expect(find.text('Atendimento agendado'), findsNothing);
    expect(find.text('Não foi possível agendar'), findsOneWidget);
    expect(
      find.text('Esse horário já está ocupado. Escolha outro horário.'),
      findsOneWidget,
    );
    expect(find.text('conflict'), findsNothing);
    expect(find.byKey(const Key('confirm-booking')), findsNothing);
  });

  testWidgets(
    'Agenda e valores existentes aparecem em português numa tela pequena',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final calls = <String>[];
      await tester.pumpWidget(
        MaterialApp(
          home: RemoteWorkflowScreen(api: apiFor(calls, existing: true)),
        ),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('nav-agenda')));
      await tester.pumpAndSettle();
      expect(find.text('Agendado'), findsOneWidget);
      expect(find.text('09/11/2030 às 14:00'), findsOneWidget);
      expect(find.textContaining('reserved'), findsNothing);
      expect(find.textContaining('tenant-test'), findsNothing);
      expect(tester.takeException(), isNull);
      expect(calls, ['/state']);
    },
  );

  testWidgets(
    'Confirmação recebida continua clara se a atualização da agenda falhar',
    (tester) async {
      final calls = <String>[];
      await tester.pumpWidget(
        MaterialApp(
          home: RemoteWorkflowScreen(
            api: apiFor(calls, refreshFailsAfterConfirm: true),
          ),
        ),
      );
      await tester.pumpAndSettle();
      await prepare(tester);
      await tester.ensureVisible(find.byKey(const Key('confirm-booking')));
      await tester.tap(find.byKey(const Key('confirm-booking')));
      await tester.pumpAndSettle();
      expect(find.text('Atendimento agendado'), findsOneWidget);
      expect(
        find.textContaining('não é preciso confirmar de novo'),
        findsOneWidget,
      );
      expect(find.byKey(const Key('confirm-booking')), findsNothing);
      expect(calls.where((path) => path == '/confirm').length, 1);
    },
  );

  testWidgets('Voltar no cancelamento mantém o atendimento intacto', (
    tester,
  ) async {
    final calls = <String>[];
    await tester.pumpWidget(
      MaterialApp(
        home: RemoteWorkflowScreen(api: apiFor(calls, existing: true)),
      ),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('nav-agenda')));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.widgetWithText(TextButton, 'Cancelar'));
    await tester.tap(find.widgetWithText(TextButton, 'Cancelar'));
    await tester.pumpAndSettle();
    expect(find.text('Cancelar atendimento?'), findsOneWidget);
    await tester.tap(find.widgetWithText(TextButton, 'Voltar'));
    await tester.pumpAndSettle();
    expect(calls, ['/state']);
    expect(find.text('Agendado'), findsOneWidget);
  });

  testWidgets(
    'Cinco áreas preservam a proposta e consultam os dados sem gravar',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final calls = <String>[];
      await tester.pumpWidget(
        MaterialApp(
          home: RemoteWorkflowScreen(
            api: apiFor(calls, existing: true),
            brightness: Brightness.dark,
          ),
        ),
      );
      await tester.pumpAndSettle();
      await prepare(tester);
      for (final label in [
        'Início',
        'Agenda',
        'Contatos',
        'Carteira',
        'Mais',
      ]) {
        expect(find.text(label), findsOneWidget);
      }
      await tester.tap(find.byKey(const Key('nav-clients')));
      await tester.pumpAndSettle();
      expect(find.text('Contatos cadastrados'), findsOneWidget);
      expect(find.byKey(const Key('confirm-booking')), findsNothing);
      await tester.tap(find.byKey(const ValueKey('client-c1')));
      await tester.pumpAndSettle();
      expect(find.text('Ana Silva'), findsOneWidget);
      expect(find.text('Atendimento demonstrativo'), findsOneWidget);
      expect(find.text('Agendado'), findsOneWidget);
      await tester.tap(find.byKey(const Key('nav-business')));
      await tester.pumpAndSettle();
      expect(find.text('Catálogo de serviços'), findsOneWidget);
      expect(find.text('Materiais'), findsOneWidget);
      await tester.tap(find.byKey(const Key('more-catalog')));
      await tester.pumpAndSettle();
      expect(find.text('Atendimento demonstrativo'), findsOneWidget);
      expect(find.text(r'R$ 50,00'), findsOneWidget);
      await tester.tap(find.byKey(const Key('nav-receivables')));
      await tester.pumpAndSettle();
      expect(find.text('Valores a receber'), findsOneWidget);
      expect(find.text('Total a receber'), findsOneWidget);
      expect(find.text('1 valor pendente'), findsOneWidget);
      expect(find.text(r'R$ 50,00'), findsNWidgets(2));
      expect(find.textContaining('Saldo'), findsNothing);
      await tester.tap(find.byKey(const Key('nav-agenda')));
      await tester.pumpAndSettle();
      expect(find.text('Sua agenda'), findsOneWidget);
      expect(find.text('Agendado'), findsOneWidget);
      await tester.tap(find.byKey(const Key('nav-home')));
      await tester.pumpAndSettle();
      await tester.ensureVisible(find.byKey(const Key('open-wallet-summary')));
      await tester.tap(find.byKey(const Key('open-wallet-summary')));
      await tester.pumpAndSettle();
      expect(find.text('Total a receber'), findsOneWidget);
      await tester.tap(find.byKey(const Key('nav-home')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('resume-review')), findsOneWidget);
      expect(find.byKey(const Key('confirm-booking')), findsNothing);
      await tester.ensureVisible(find.byKey(const Key('resume-review')));
      await tester.tap(find.byKey(const Key('resume-review')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('confirm-booking')), findsOneWidget);
      expect(find.text('Confira antes de agendar'), findsOneWidget);
      expect(find.text('Agende Ana em 09/11/2030 às 14h.'), findsOneWidget);
      expect(calls, ['/state', '/plan']);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'Início mostra operação e o assistente flutuante funciona nas cinco áreas',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final calls = <String>[];
      await tester.pumpWidget(
        MaterialApp(home: RemoteWorkflowScreen(api: apiFor(calls))),
      );
      await tester.pumpAndSettle();
      expect(find.text('Visão geral'), findsOneWidget);
      expect(find.text('Para revisar'), findsOneWidget);
      expect(find.byKey(const Key('request-field')), findsNothing);
      for (final area in [
        'home',
        'agenda',
        'clients',
        'receivables',
        'business',
      ]) {
        await tester.tap(find.byKey(Key('nav-$area')));
        await tester.pumpAndSettle();
        await tester.tap(find.byKey(const Key('ask-ai')));
        await tester.pumpAndSettle();
        expect(find.byKey(const Key('request-field')), findsOneWidget);
        expect(find.text('Seu assistente'), findsOneWidget);
        expect(tester.takeException(), isNull);
      }
      expect(calls, ['/state']);
    },
  );

  testWidgets('Calendário, filtros e ordenação consultam sem gravar', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final calls = <String>[];
    final state = snapshot(reserved: true);
    (state['services'] as List).add({
      'id': 's2',
      'label': 'Visita técnica',
      'duration_minutes': 30,
      'price_cents': 8000,
    });
    (state['clients'] as List).add({'id': 'c2', 'label': 'Bruno Lima'});
    (state['orders'] as List).add({
      ...proposal,
      'request_id': 'r2',
      'client_id': 'c2',
      'service_id': 's2',
      'starts_at': '2030-11-10T17:00:00Z',
      'state': 'completed',
    });
    final api = WorkflowApi(
      tokenProvider: () => 'synthetic-session',
      client: MockClient((r) async {
        calls.add(r.url.path);
        expect(r.url.path, '/state');
        return http.Response(jsonEncode(state), 200);
      }),
    );
    await tester.pumpWidget(MaterialApp(home: RemoteWorkflowScreen(api: api)));
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('nav-agenda')));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('agenda-calendar')), findsOneWidget);
    expect(find.text('Novembro 2030'), findsOneWidget);
    expect(
      tester.getTopLeft(find.byKey(const Key('order-r1'))).dy,
      lessThan(tester.getTopLeft(find.byKey(const Key('order-r2'))).dy),
    );
    await tester.ensureVisible(find.byKey(const Key('agenda-sort')));
    await tester.tap(find.byKey(const Key('agenda-sort')));
    await tester.pumpAndSettle();
    expect(
      tester.getTopLeft(find.byKey(const Key('order-r2'))).dy,
      lessThan(tester.getTopLeft(find.byKey(const Key('order-r1'))).dy),
    );
    await tester.ensureVisible(
      find.byKey(const ValueKey('calendar-day-2030-11-9')),
    );
    await tester.tap(find.byKey(const ValueKey('calendar-day-2030-11-9')));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('order-r1')), findsOneWidget);
    expect(find.byKey(const Key('order-r2')), findsNothing);
    await tester.ensureVisible(find.byKey(const Key('clear-agenda-filters')));
    await tester.tap(find.byKey(const Key('clear-agenda-filters')));
    await tester.pumpAndSettle();
    final statuses = find
        .byWidgetPredicate((w) => w is DropdownButtonFormField<String>)
        .first;
    await tester.ensureVisible(statuses);
    await tester.tap(statuses);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Concluídos').last);
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('order-r1')), findsNothing);
    expect(find.byKey(const Key('order-r2')), findsOneWidget);
    await tester.ensureVisible(find.byKey(const Key('clear-agenda-filters')));
    await tester.tap(find.byKey(const Key('clear-agenda-filters')));
    await tester.pumpAndSettle();
    expect(find.text('Todas'), findsOneWidget);
    final services = find
        .byWidgetPredicate((w) => w is DropdownButtonFormField<String>)
        .last;
    await tester.ensureVisible(services);
    await tester.tap(services);
    await tester.pumpAndSettle();
    await tester.tap(find.text('Visita técnica').last);
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('order-r1')), findsNothing);
    expect(find.byKey(const Key('order-r2')), findsOneWidget);
    await tester.ensureVisible(find.byKey(const Key('calendar-next')));
    await tester.tap(find.byKey(const Key('calendar-next')));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('order-r2')), findsNothing);
    expect(find.text('Dezembro 2030'), findsOneWidget);
    expect(calls, ['/state']);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Fechar e reabrir conversa preserva o pedido sem executar', (
    tester,
  ) async {
    final calls = <String>[];
    await tester.pumpWidget(
      MaterialApp(home: RemoteWorkflowScreen(api: apiFor(calls))),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('nav-clients')));
    await tester.pumpAndSettle();
    await prepare(tester);
    await tester.tap(find.byKey(const Key('close-assistant')));
    await tester.pumpAndSettle();
    expect(find.text('Contatos cadastrados'), findsOneWidget);
    expect(find.byKey(const Key('confirm-booking')), findsNothing);
    await tester.tap(find.byKey(const Key('ask-ai')));
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('confirm-booking')), findsOneWidget);
    expect(
      tester
          .widget<TextField>(find.byKey(const Key('request-field')))
          .controller!
          .text,
      isEmpty,
    );
    expect(find.text('Agende Ana em 09/11/2030 às 14h.'), findsOneWidget);
    expect(calls, ['/state', '/plan']);
  });

  testWidgets('Conversa cabe no celular com teclado e texto ampliado', (
    tester,
  ) async {
    tester.view.physicalSize = const Size(390, 844);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    final calls = <String>[];
    await tester.pumpWidget(
      MaterialApp(
        builder: (context, child) => MediaQuery(
          data: MediaQuery.of(
            context,
          ).copyWith(textScaler: const TextScaler.linear(1.3)),
          child: child!,
        ),
        home: RemoteWorkflowScreen(api: apiFor(calls)),
      ),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('ask-ai')));
    await tester.pumpAndSettle();
    tester.view.viewInsets = const FakeViewPadding(bottom: 300);
    addTearDown(tester.view.resetViewInsets);
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.byKey(const Key('request-field')));
    await tester.enterText(
      find.byKey(const Key('request-field')),
      'Agende Ana amanhã às 14h',
    );
    await tester.pumpAndSettle();
    expect(find.byKey(const Key('assistant-popup')), findsOneWidget);
    expect(tester.takeException(), isNull);
    expect(calls, ['/state']);
  });

  testWidgets(
    'Convite abre DM compacta no canto direito e o personagem retorna ao fechar',
    (tester) async {
      tester.view.physicalSize = const Size(1200, 900);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final calls = <String>[];
      await tester.pumpWidget(
        MaterialApp(home: RemoteWorkflowScreen(api: apiFor(calls))),
      );
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('assistant-invitation')), findsOneWidget);
      await tester.tap(find.byKey(const Key('ask-ai')));
      await tester.pumpAndSettle();
      final popup = tester.getRect(find.byKey(const Key('assistant-popup')));
      expect(popup.width, 360);
      expect(popup.height, 440);
      expect(popup.right, 1188);
      expect(
        popup.bottom,
        tester.getRect(find.byKey(const Key('workflow-navigation'))).top - 12,
      );
      expect(popup.top, greaterThan(100));
      expect(find.byKey(const Key('ask-ai')), findsNothing);
      expect(find.byKey(const Key('assistant-invitation')), findsNothing);
      expect(
        tester.getRect(find.byKey(const Key('chat-composer'))).bottom,
        popup.bottom,
      );
      await tester.tap(find.byKey(const Key('close-assistant')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('assistant-popup')), findsNothing);
      expect(find.byKey(const Key('ask-ai')), findsOneWidget);
      expect(find.byKey(const Key('assistant-invitation')), findsNothing);
      expect(calls, ['/state']);
      expect(tester.takeException(), isNull);
    },
  );

  testWidgets(
    'Dispensar convite e alternar áreas preserva rascunho sem enviar',
    (tester) async {
      final calls = <String>[];
      await tester.pumpWidget(
        MaterialApp(home: RemoteWorkflowScreen(api: apiFor(calls))),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('dismiss-assistant-hint')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('assistant-invitation')), findsNothing);
      expect(find.byKey(const Key('ask-ai')), findsOneWidget);
      await tester.tap(find.byKey(const Key('ask-ai')));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byKey(const Key('request-field')),
        'Pedido ainda não enviado',
      );
      await tester.tap(find.byKey(const Key('nav-clients')));
      await tester.pumpAndSettle();
      expect(find.text('Contatos cadastrados'), findsOneWidget);
      expect(find.byKey(const Key('assistant-popup')), findsNothing);
      await tester.tap(find.byKey(const Key('ask-ai')));
      await tester.pumpAndSettle();
      expect(
        tester
            .widget<TextField>(find.byKey(const Key('request-field')))
            .controller!
            .text,
        'Pedido ainda não enviado',
      );
      expect(calls, ['/state']);
    },
  );

  testWidgets(
    'Mais organiza acessos e volta dos detalhes sem perder o contexto',
    (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      final calls = <String>[];
      await tester.pumpWidget(
        MaterialApp(
          home: RemoteWorkflowScreen(api: apiFor(calls, existing: true)),
        ),
      );
      await tester.pumpAndSettle();
      await tester.tap(find.byKey(const Key('nav-business')));
      await tester.pumpAndSettle();
      expect(find.text('Seu negócio'), findsOneWidget);
      expect(find.byKey(const Key('more-catalog')), findsOneWidget);
      expect(find.byKey(const Key('more-materials')), findsOneWidget);
      expect(find.byKey(const Key('more-preferences')), findsOneWidget);
      expect(find.text('Atendimento demonstrativo'), findsNothing);
      await tester.tap(find.byKey(const Key('more-catalog')));
      await tester.pumpAndSettle();
      expect(find.text('Atendimento demonstrativo'), findsOneWidget);
      expect(find.text(r'R$ 50,00'), findsOneWidget);
      await tester.binding.handlePopRoute();
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('more-catalog')), findsOneWidget);
      await tester.tap(find.byKey(const Key('more-materials')));
      await tester.pumpAndSettle();
      expect(find.text('Kits de atendimento'), findsOneWidget);
      await tester.tap(find.byKey(const Key('more-back')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('more-preferences')), findsOneWidget);
      await tester.tap(find.byKey(const Key('more-preferences')));
      await tester.pumpAndSettle();
      expect(find.text('Horário de Brasília'), findsOneWidget);
      expect(find.text('UTC−3'), findsOneWidget);
      await tester.tap(find.byKey(const Key('ask-ai')));
      await tester.pumpAndSettle();
      await tester.enterText(
        find.byKey(const Key('request-field')),
        'Rascunho preservado',
      );
      await tester.binding.handlePopRoute();
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('assistant-popup')), findsNothing);
      expect(find.text('Horário de Brasília'), findsOneWidget);
      await tester.tap(find.byKey(const Key('nav-business')));
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('more-catalog')), findsOneWidget);
      await tester.tap(find.byKey(const Key('ask-ai')));
      await tester.pumpAndSettle();
      expect(
        tester
            .widget<TextField>(find.byKey(const Key('request-field')))
            .controller!
            .text,
        'Rascunho preservado',
      );
      expect(calls, ['/state']);
      expect(tester.takeException(), isNull);
    },
  );
}
