// Capturas de estudos conceituais. Nenhum transporte HTTP, modelo ou banco.
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:bico_laboratorio/concepts/service_journey_concept.dart';
import 'paper_figures.dart' as fonts;

void main() {
  for (final page in JourneyConcept.values) {
    testWidgets('Conceito editorial: ${page.name}', (tester) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.runAsync(fonts.fonts);
      final key = GlobalKey();
      await tester.pumpWidget(
        RepaintBoundary(
          key: key,
          child: MaterialApp(
            debugShowCheckedModeBanner: false,
            home: ServiceJourneyConcept(page: page),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.byKey(const Key('concept-status')), findsOneWidget);
      expect(find.text('ESTUDO CONCEITUAL · FUNÇÃO PROPOSTA'), findsOneWidget);
      expect(tester.takeException(), isNull);
      await tester.runAsync(() async {
        final boundary =
            key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
        final capture = await boundary.toImage(pixelRatio: 2);
        final bytes = await capture.toByteData(format: ui.ImageByteFormat.png);
        final output = File(
          '../../.cache/visao_conceitual_20261106/${page.name}.png',
        );
        await output.parent.create(recursive: true);
        await output.writeAsBytes(bytes!.buffer.asUint8List());
        capture.dispose();
      });
    });
  }
}
