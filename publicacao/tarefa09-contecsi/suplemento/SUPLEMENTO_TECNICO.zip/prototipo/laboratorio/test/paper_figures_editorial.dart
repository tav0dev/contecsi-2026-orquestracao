// Captura a interface real completa; o HTTP é substituído pelo fixture sintético.
import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:bico_laboratorio/screens/remote_workflow_screen.dart';
import 'remote_workflow_test.dart' as fixture;
import 'paper_figures.dart' as prior;

Finder panel(String title) => find
    .ancestor(
      of: find.text(title),
      matching: find.byWidgetPredicate(
        (w) => w.runtimeType.toString() == '_Panel',
      ),
    )
    .first;

Future<void> shot(WidgetTester tester, GlobalKey key, String filename) async {
  await tester.runAsync(() async {
    final boundary =
        key.currentContext!.findRenderObject()! as RenderRepaintBoundary;
    final image = await boundary.toImage(pixelRatio: 2);
    final bytes = await image.toByteData(format: ui.ImageByteFormat.png);
    final target = File('../../.cache/revisao_visual_ui_20261105/$filename');
    await target.parent.create(recursive: true);
    await target.writeAsBytes(bytes!.buffer.asUint8List());
    image.dispose();
  });
}

void main() {
  testWidgets('Figura editorial: dark desktop DM compacta', (tester) async {
    tester.view.physicalSize = const Size(1200, 900);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    await tester.runAsync(prior.fonts);
    final key = GlobalKey();
    final calls = <String>[];
    await tester.pumpWidget(
      RepaintBoundary(
        key: key,
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          home: RemoteWorkflowScreen(
            api: fixture.apiFor(calls, existing: true),
            brightness: Brightness.dark,
          ),
        ),
      ),
    );
    await tester.pumpAndSettle();
    await tester.tap(find.byKey(const Key('ask-ai')));
    await tester.pumpAndSettle();
    expect(calls, ['/state']);
    expect(tester.takeException(), isNull);
    await shot(tester, key, 'dark_desktop_dm.png');
  });
  for (final brightness in [Brightness.light, Brightness.dark]) {
    testWidgets('Figura editorial: ${brightness.name} início operacional', (
      tester,
    ) async {
      tester.view.physicalSize = const Size(390, 844);
      tester.view.devicePixelRatio = 1;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);
      await tester.runAsync(prior.fonts);
      final key = GlobalKey();
      final calls = <String>[];
      await tester.pumpWidget(
        RepaintBoundary(
          key: key,
          child: MaterialApp(
            debugShowCheckedModeBanner: false,
            home: RemoteWorkflowScreen(
              api: fixture.apiFor(calls, existing: true),
              brightness: brightness,
            ),
          ),
        ),
      );
      await tester.pumpAndSettle();
      expect(find.text('Visão geral'), findsOneWidget);
      expect(find.text('Para revisar'), findsOneWidget);
      expect(calls, ['/state']);
      expect(tester.takeException(), isNull);
      await shot(tester, key, '${brightness.name}_inicio_tela.png');
    });
    for (final area in [
      'clients',
      'receivables',
      'business',
      'assistant',
      'catalog',
      'materials',
      'preferences',
    ]) {
      testWidgets('Figura editorial: ${brightness.name} $area', (tester) async {
        tester.view.physicalSize = const Size(390, 844);
        tester.view.devicePixelRatio = 1;
        addTearDown(tester.view.resetPhysicalSize);
        addTearDown(tester.view.resetDevicePixelRatio);
        await tester.runAsync(prior.fonts);
        final key = GlobalKey();
        final calls = <String>[];
        await tester.pumpWidget(
          RepaintBoundary(
            key: key,
            child: MaterialApp(
              debugShowCheckedModeBanner: false,
              home: RemoteWorkflowScreen(
                api: fixture.apiFor(calls, existing: true),
                brightness: brightness,
              ),
            ),
          ),
        );
        await tester.pumpAndSettle();
        await tester.tap(
          find.byKey(
            Key(
              area == 'assistant'
                  ? 'ask-ai'
                  : ['catalog', 'materials', 'preferences'].contains(area)
                  ? 'nav-business'
                  : 'nav-$area',
            ),
          ),
        );
        await tester.pumpAndSettle();
        if (['catalog', 'materials', 'preferences'].contains(area)) {
          await tester.tap(find.byKey(Key('more-$area')));
          await tester.pumpAndSettle();
        }
        expect(calls, ['/state']);
        expect(tester.takeException(), isNull);
        await shot(tester, key, '${brightness.name}_${area}_tela.png');
      });
    }
    for (final confirmed in [false, true]) {
      testWidgets(
        'Figura editorial: ${brightness.name} ${confirmed ? 'confirmada' : 'em revisão'}',
        (tester) async {
          tester.view.physicalSize = const Size(390, 844);
          tester.view.devicePixelRatio = 1;
          addTearDown(tester.view.resetPhysicalSize);
          addTearDown(tester.view.resetDevicePixelRatio);
          await tester.runAsync(prior.fonts);
          final key = GlobalKey();
          final calls = <String>[];
          await tester.pumpWidget(
            RepaintBoundary(
              key: key,
              child: MaterialApp(
                debugShowCheckedModeBanner: false,
                home: RemoteWorkflowScreen(
                  api: fixture.apiFor(calls),
                  brightness: brightness,
                ),
              ),
            ),
          );
          await tester.pumpAndSettle();
          await fixture.prepare(tester);
          if (confirmed) {
            await tester.ensureVisible(
              find.byKey(const Key('confirm-booking')),
            );
            await tester.tap(find.byKey(const Key('confirm-booking')));
            await tester.pumpAndSettle();
            expect(calls, ['/state', '/plan', '/confirm', '/state']);
          } else {
            expect(calls, ['/state', '/plan']);
          }
          if (!confirmed) {
            await Scrollable.ensureVisible(
              tester.element(find.byKey(const Key('proposal-review'))),
              alignment: 0,
            );
          }
          await tester.pumpAndSettle();
          expect(tester.takeException(), isNull);
          await shot(
            tester,
            key,
            '${brightness.name}_${confirmed ? 'acompanhamento' : 'revisao'}_tela.png',
          );
        },
      );
    }
  }
}
