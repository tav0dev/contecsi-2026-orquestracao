import 'dart:convert';
import 'package:http/http.dart' as http;

/// Usa JWT da sessão Supabase; nenhuma chave de IA ou pagamento vai ao Flutter.
class WorkflowApi {
  final http.Client _client;
  final Uri base;
  final String Function()? tokenProvider;
  String _token = '';
  static const supabaseUrl = 'https://wzychmshebmznjfducug.supabase.co';
  WorkflowApi({http.Client? client, String? baseUrl, this.tokenProvider})
      : _client = client ?? http.Client(),
        base = Uri.parse(baseUrl ?? const String.fromEnvironment('BICO_API_URL', defaultValue: 'http://127.0.0.1:8766')) {
    if (base.scheme != 'https' && !(base.scheme == 'http' &&
        ['127.0.0.1', 'localhost', '10.0.2.2'].contains(base.host))) {
      throw ArgumentError('Backend exige HTTPS ou endereço local de desenvolvimento');
    }
  }
  bool get authenticated => (tokenProvider?.call() ?? _token).isNotEmpty;
  void close() => _client.close();
  Future<Map<String, dynamic>> _send(String method, Uri uri,
      Map<String, String> headers, Map<String, dynamic>? body) async {
    final request = http.Request(method, uri)..followRedirects = false;
    request.headers.addAll({'Content-Type': 'application/json', ...headers});
    if (body != null) request.body = jsonEncode(body);
    final response = await http.Response.fromStream(
      await _client.send(request).timeout(const Duration(seconds: 60)));
    Map<String, dynamic> value;
    try { value = jsonDecode(response.body) as Map<String, dynamic>; }
    catch (_) { throw StateError('Resposta inválida do serviço (${response.statusCode}).'); }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw StateError('Serviço respondeu ${response.statusCode}: ${value['error'] ?? 'operação recusada'}');
    }
    return value;
  }
  Future<void> login(String email, String password) async {
    const key = String.fromEnvironment('BICO_SUPABASE_ANON_KEY');
    if (key.isEmpty) throw StateError('Configure a chave pública Supabase ou abra pelo app autenticado.');
    final result = await _send('POST', Uri.parse('$supabaseUrl/auth/v1/token?grant_type=password'),
      {'apikey': key}, {'email': email, 'password': password});
    if (result['access_token'] is! String) throw StateError('Sessão inválida.');
    _token = result['access_token'];
  }
  Future<Map<String, dynamic>> call(String path, [Map<String, dynamic>? body]) {
    final token = tokenProvider?.call() ?? _token;
    if (token.isEmpty) throw StateError('Entre na sua conta Supabase antes de continuar.');
    return _send(body == null ? 'GET' : 'POST', base.resolve(path),
      {'Authorization': 'Bearer $token'}, body);
  }
}
