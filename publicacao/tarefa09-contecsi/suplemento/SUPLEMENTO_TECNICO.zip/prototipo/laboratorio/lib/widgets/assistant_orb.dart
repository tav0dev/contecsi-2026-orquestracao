import 'package:flutter/material.dart';

/// Personagem vetorial da interface; não representa voz ou autonomia habilitadas.
class AssistantOrb extends StatelessWidget {
  final double size;
  const AssistantOrb({super.key, this.size = 52});

  @override
  Widget build(BuildContext context) => ExcludeSemantics(
    child: Container(
      width: size,
      height: size,
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        border: Border.fromBorderSide(
          BorderSide(color: Color(0xFFE0E7FF), width: 2),
        ),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF818CF8), Color(0xFF4338CA)],
        ),
      ),
      child: Center(
        child: Container(
          width: size * .66,
          height: size * .42,
          decoration: BoxDecoration(
            color: const Color(0xFF172554),
            border: Border.all(
              color: const Color(0xFFE0E7FF),
              width: size * .025,
            ),
            borderRadius: BorderRadius.circular(size * .19),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              for (var i = 0; i < 2; i++)
                Container(
                  width: size * .09,
                  height: size * .14,
                  margin: EdgeInsets.symmetric(horizontal: size * .065),
                  decoration: BoxDecoration(
                    color: const Color(0xFFCCFBF1),
                    borderRadius: BorderRadius.circular(size * .06),
                  ),
                ),
            ],
          ),
        ),
      ),
    ),
  );
}
