import 'dart:ui' as ui;
import 'package:flutter/material.dart';

/// Símbolo provisório sem nome: conexão entre pedido, decisão e execução.
class ProcessMark extends StatelessWidget {
  const ProcessMark({super.key, this.size = 32});
  final double size;
  @override
  Widget build(BuildContext context) => SizedBox.square(
    dimension: size,
    child: CustomPaint(painter: _MarkPainter()),
  );
}

class _MarkPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final scale = size.width / 40;
    canvas.save();
    canvas.scale(scale);
    final line = Paint()
      ..color = const Color(0xFF15803D)
      ..strokeWidth = 4
      ..strokeCap = StrokeCap.round;
    canvas.drawLine(const Offset(20, 10), const Offset(32, 29), line);
    const origin = Offset(9, 29);
    for (final target in [const Offset(20, 10), const Offset(32, 29)]) {
      final connection = Paint()
        ..strokeWidth = 4
        ..strokeCap = StrokeCap.round
        ..shader = ui.Gradient.linear(origin, target, const [
          Color(0xFF4338CA),
          Color(0xFF15803D),
        ]);
      canvas.drawLine(origin, target, connection);
    }
    for (final point in [const Offset(32, 29), const Offset(20, 10)]) {
      canvas.drawCircle(point, 6, Paint()..color = const Color(0xFF16A34A));
    }
    canvas.drawCircle(
      const Offset(9, 29),
      6,
      Paint()..color = const Color(0xFF4338CA),
    );
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
