import 'package:flutter/material.dart';
import 'concepts/service_journey_concept.dart';

void main() => runApp(const ConceptGallery());

class ConceptGallery extends StatefulWidget {
  const ConceptGallery({super.key});
  @override
  State<ConceptGallery> createState() => _ConceptGalleryState();
}

class _ConceptGalleryState extends State<ConceptGallery> {
  JourneyConcept _page = JourneyConcept.offer;
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    home: ServiceJourneyConcept(
      page: _page,
      onNavigate: (page) => setState(() => _page = page),
    ),
  );
}
