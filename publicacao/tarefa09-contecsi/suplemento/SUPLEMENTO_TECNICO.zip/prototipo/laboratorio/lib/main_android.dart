import 'package:flutter/material.dart';
import 'screens/remote_workflow_screen.dart';
import 'theme/workflow_theme.dart';

/// Entrada nativa de laboratório, reutilizando a mesma tela integrada da web.
void main() => runApp(MaterialApp(
      title: 'Orquestração de processos',
      theme: WorkflowTheme.light,
      darkTheme: WorkflowTheme.dark,
      themeMode: ThemeMode.dark,
      home: const RemoteWorkflowScreen(),
    ));
