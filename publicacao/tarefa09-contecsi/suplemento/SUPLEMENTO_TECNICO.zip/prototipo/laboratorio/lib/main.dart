import 'dart:convert';
import 'package:flutter/material.dart';
import 'services/process_orchestrator.dart';
import 'services/service_workflow.dart';
import 'screens/remote_workflow_screen.dart';

/// Laboratório com demonstração local e rota integrada autenticada separada.
void main() => runApp(const ExperimentApp());

class ExperimentApp extends StatefulWidget {
  const ExperimentApp({super.key});
  @override
  State<ExperimentApp> createState() => _ExperimentAppState();
}

class _ExperimentAppState extends State<ExperimentApp> {
  final _engine=ProcessOrchestrator(tenantId:'negocio-demo',
    clientOwners:{'cliente-demo':'negocio-demo'}, serviceOwners:{'servico-demo':'negocio-demo'});
  late final _workflow=ServiceWorkflow(agenda:_engine,onHand:{'kit':3},
    recipes:{'servico-demo':{'kit':1}},pricesCents:{'servico-demo':5000});
  late final TextEditingController _input;
  String _feedback='Carregue uma proposta para revisar.';
  AppointmentProposal? _proposal;
  @override
  void initState() {
    super.initState();
    _input=TextEditingController(text:const JsonEncoder.withIndent('  ').convert({
      'request_id':'solicitacao-1','tenant_id':'negocio-demo','client_id':'cliente-demo',
      'service_id':'servico-demo','start':DateTime.now().toUtc().add(const Duration(days:1)).toIso8601String(),
      'duration_minutes':60}));
  }
  @override
  void dispose() {_input.dispose();super.dispose();}
  void _review() {
    setState(() {
      _proposal=null;
      try {
        final p=AppointmentProposal.fromJson(jsonDecode(_input.text) as Map<String,dynamic>);
        final status=_workflow.submit(p,approved:false,now:DateTime.now().toUtc());
        if(status=='awaiting_confirmation') _proposal=p;
        _feedback=status=='awaiting_confirmation'
          ? 'Proposta válida. Revise o horário e confirme para registrar.' : 'Revisão: $status';
      } catch(_) {_feedback='Proposta inválida. Confira os campos e o fuso horário.';}
    });
  }
  @override
  Widget build(BuildContext context) => MaterialApp(
    title:'Bico — laboratório',theme:ThemeData(colorSchemeSeed:Colors.green),
    routes:{'/integracao':(_)=>const RemoteWorkflowScreen()},
    home:Scaffold(appBar:AppBar(title:const Text('Bico — laboratório de processos'),actions:[
      Builder(builder:(ctx)=>TextButton.icon(icon:const Icon(Icons.cloud_outlined),
        label:const Text('Abrir integração'),onPressed:()=>Navigator.pushNamed(ctx,'/integracao'))),
    ]),
      body:ListView(padding:const EdgeInsets.all(24),children:[
        const Text('Dados sintéticos · propostas de demonstração · sem chamada a IA',
          style:TextStyle(fontWeight:FontWeight.bold)),
        const SizedBox(height:16),
        const Text('Fluxo: proposta → revisão → confirmação → reserva de material → '
          'conta a receber → rascunho de comunicação. '
          'Os registros duram apenas durante esta sessão.'),
        const SizedBox(height:16),
        TextField(controller:_input,minLines:8,maxLines:12,onChanged:(_)=>setState(()=>_proposal=null),
          decoration:const InputDecoration(labelText:'Proposta estruturada',border:OutlineInputBorder())),
        const SizedBox(height:16),
        FilledButton(onPressed:_review,child:const Text('Revisar proposta')),
        Text(_feedback,key:const Key('feedback')),
        if(_proposal!=null) ...[
          Text(_engine.confirmationDraft(_proposal!)),
          const Text('Este serviço reserva 1 kit e registra R\$ 50,00 a receber. '
            'A cobrança externa e o envio de mensagens ainda não estão conectados.'),
          FilledButton(onPressed:()=>setState(() {
            _feedback=_workflow.submit(_proposal!,approved:true,now:DateTime.now().toUtc());
            _proposal=null;
          }),child:const Text('Confirmar agendamento')),
        ],
        const SizedBox(height:24),
        Text('Agendamentos registrados: ${_engine.appointments.length}'),
        Text('Kits disponíveis: ${_workflow.available('kit')}'),
        Text('A receber (local): R\$ ${(_workflow.receivableCents/100).toStringAsFixed(2)}'),
        Text('Rascunhos locais: ${_workflow.draftCount}'),
        ..._engine.appointments.map((p)=>Card(child:Padding(
          padding:const EdgeInsets.all(12),
          child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
          Text(p.clientId),
          Text('${_engine.confirmationDraft(p)} · ${_workflow.state(p.requestId)}'),
          if(_workflow.state(p.requestId)=='reserved') Wrap(children:[
            TextButton(onPressed:()=>setState(() {
              _feedback=_workflow.complete(p.requestId,approved:true);
            }),child:const Text('Concluir serviço')),
            TextButton(onPressed:()=>setState(() {
              _feedback=_workflow.cancel(p.requestId,approved:true,now:DateTime.now().toUtc());
            }),child:const Text('Cancelar serviço')),
          ]),
        ])))),
      ])));
}
