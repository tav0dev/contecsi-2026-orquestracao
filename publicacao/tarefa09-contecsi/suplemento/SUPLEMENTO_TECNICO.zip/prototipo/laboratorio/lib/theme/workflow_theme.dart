import 'package:flutter/material.dart';

import 'tokens.dart';

/// Tema do fluxo integrado, sem inicializar autenticação ou provedores de dados.
class WorkflowTheme {
  static ThemeData get light => forBrightness(Brightness.light);
  static ThemeData get dark => forBrightness(Brightness.dark);
  static ThemeData forBrightness(Brightness brightness) {
    final tokens = brightness == Brightness.dark
        ? BicoTokens.dark
        : BicoTokens.light;
    final action = brightness == Brightness.dark
        ? tokens.green
        : tokens.greenDark;
    final scheme = ColorScheme.fromSeed(
      seedColor: tokens.green,
      brightness: brightness,
      primary: action,
      onPrimary: brightness == Brightness.dark ? tokens.bg : Colors.white,
      secondary: tokens.purple,
      surface: tokens.bg,
      onSurface: tokens.text,
      error: tokens.red,
    );
    final border = OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: BorderSide(color: tokens.border),
    );
    return ThemeData(
      useMaterial3: true,
      fontFamily: 'Roboto',
      brightness: brightness,
      colorScheme: scheme,
      scaffoldBackgroundColor: tokens.bgSoft,
      textTheme: const TextTheme(
        bodyMedium: TextStyle(fontSize: 16, height: 1.35),
        bodyLarge: TextStyle(fontSize: 16, height: 1.35),
      ),
      dividerColor: tokens.border,
      appBarTheme: AppBarTheme(
        backgroundColor: tokens.bg,
        foregroundColor: tokens.text,
        surfaceTintColor: Colors.transparent,
        titleTextStyle: TextStyle(
          fontFamily: 'Roboto',
          color: tokens.text,
          fontSize: 20,
          fontWeight: FontWeight.w700,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: tokens.bgSoft,
        border: border,
        enabledBorder: border,
        focusedBorder: border.copyWith(
          borderSide: BorderSide(color: action, width: 2),
        ),
        contentPadding: const EdgeInsets.all(16),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(0, 48),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          textStyle: const TextStyle(
            fontFamily: 'Roboto',
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(0, 44),
          side: BorderSide(color: tokens.border),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
      ),
    );
  }
}
