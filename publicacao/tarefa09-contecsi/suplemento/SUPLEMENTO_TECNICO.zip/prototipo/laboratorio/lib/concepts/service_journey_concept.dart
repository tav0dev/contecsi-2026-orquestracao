import 'package:flutter/material.dart';
import '../theme/tokens.dart';
import '../theme/workflow_theme.dart';
import '../widgets/assistant_orb.dart';

/// Estudos de interface da visão do produto. Sem autenticação, chamadas externas
/// ou operações de negócio. Não integra o fluxo experimental avaliado.
enum JourneyConcept {
  offer,
  connections,
  quote,
  promotion,
  followUp,
  discovery,
}

class ServiceJourneyConcept extends StatelessWidget {
  final JourneyConcept page;
  final ValueChanged<JourneyConcept>? onNavigate;
  const ServiceJourneyConcept({super.key, required this.page, this.onNavigate});
  BicoTokens get c => BicoTokens.dark;
  static const titles = [
    'Sua oferta',
    'Conexões',
    'Serviço por orçamento',
    'Divulgação',
    'Pós-venda',
    'Encontrar um serviço',
  ];

  Widget _card(String title, List<Widget> children, {String? description}) =>
      Container(
        margin: const EdgeInsets.only(bottom: 14),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: c.bg,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: c.border),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w700,
                color: c.text,
              ),
            ),
            if (description != null) ...[
              const SizedBox(height: 6),
              Text(
                description,
                style: TextStyle(fontSize: 12, height: 1.4, color: c.textMuted),
              ),
            ],
            const SizedBox(height: 14),
            ...children,
          ],
        ),
      );
  Widget _line(IconData icon, String title, String detail) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(icon, color: c.purple, size: 21),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: c.text,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                detail,
                style: TextStyle(fontSize: 12, height: 1.4, color: c.textMuted),
              ),
            ],
          ),
        ),
      ],
    ),
  );
  Widget _tag(String text) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    decoration: BoxDecoration(
      color: c.purpleSoft,
      borderRadius: BorderRadius.circular(20),
    ),
    child: Text(
      text,
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w600,
        color: c.purple,
      ),
    ),
  );
  Widget _assistant(String message) => Container(
    padding: const EdgeInsets.all(14),
    margin: const EdgeInsets.only(bottom: 14),
    decoration: BoxDecoration(
      color: c.purpleSoft,
      borderRadius: BorderRadius.circular(16),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const AssistantOrb(size: 30),
        const SizedBox(width: 10),
        Expanded(
          child: Text(
            message,
            style: TextStyle(fontSize: 13, height: 1.4, color: c.text),
          ),
        ),
      ],
    ),
  );
  Widget _field(String label, String value) => Padding(
    padding: const EdgeInsets.only(bottom: 12),
    child: InputDecorator(
      decoration: InputDecoration(labelText: label, isDense: true),
      child: Text(value, style: const TextStyle(fontSize: 14)),
    ),
  );
  Widget _step(
    String number,
    String title,
    String detail, {
    bool current = false,
  }) => _line(
    current ? Icons.radio_button_checked : Icons.radio_button_unchecked,
    '$number · $title',
    detail,
  );

  List<Widget> _content() => switch (page) {
    JourneyConcept.offer => [
      _assistant(
        'Vamos aproveitar o que você já oferece. Cada serviço pode ter preço definido ou precisar de orçamento.',
      ),
      _card('Organize seu serviço', [
        _field('Nome do serviço', 'Instalação de suporte de TV'),
        _field('Forma de contratação', 'Por orçamento'),
        _field('O que verificar antes', 'Parede, tamanho da TV e endereço'),
        _line(
          Icons.timer_outlined,
          'Duração e materiais',
          'Estimados após conferir as condições do local.',
        ),
        _tag('Rascunho da oferta'),
      ], description: 'Dados existentes podem ser aproveitados no início.'),
      _card('Próxima decisão', [
        Text(
          'Você revisa escopo, preço e condições antes de oferecer o serviço ao cliente.',
          style: TextStyle(fontSize: 13, height: 1.45, color: c.textMuted),
        ),
      ]),
    ],
    JourneyConcept.connections => [
      _assistant(
        'Conectar os aplicativos pode trazer contexto para as propostas. Você escolhe o acesso de cada conexão.',
      ),
      _card('Comunicação', [
        _line(
          Icons.chat_bubble_outline,
          'WhatsApp e Instagram',
          'Relacionar solicitações ao contato e ao serviço.',
        ),
        _tag('Integrações propostas'),
      ]),
      _card('Agenda e informações', [
        _line(
          Icons.calendar_month_outlined,
          'Google Agenda',
          'Consultar compromissos e acompanhar alterações.',
        ),
        _line(
          Icons.table_chart_outlined,
          'Planilhas e documentos',
          'Aproveitar catálogo e registros existentes.',
        ),
        _tag('Escopo de acesso a definir'),
      ]),
      _card('Recebimentos', [
        _line(
          Icons.account_balance_wallet_outlined,
          'Pix · AbacatePay',
          'Relacionar eventos de pagamento aos valores a receber.',
        ),
        _tag('Pagamento ainda não integrado'),
      ]),
    ],
    JourneyConcept.quote => [
      _card('Instalação de suporte de TV', [
        _line(
          Icons.person_outline,
          'Ana Silva',
          'Solicitação demonstrativa · por orçamento',
        ),
        _tag('Aguardando decisão do prestador'),
      ]),
      _card('Da solicitação à execução', [
        _step(
          '1',
          'Entender a necessidade',
          'Fotos e características da parede recebidas.',
        ),
        _step(
          '2',
          'Preparar orçamento',
          'Conferir escopo, materiais, preço e prazo.',
          current: true,
        ),
        _step(
          '3',
          'Combinar a execução',
          'Definir a data após o aceite do cliente.',
        ),
      ]),
      _assistant(
        'Há informações para preparar um rascunho. O orçamento só será enviado depois da sua revisão.',
      ),
      _card('Decisão humana', [
        Text(
          'Você negocia com o cliente e autoriza o envio. A proposta de ação da IA é diferente do orçamento comercial.',
          style: TextStyle(fontSize: 13, height: 1.4, color: c.textMuted),
        ),
      ]),
    ],
    JourneyConcept.promotion => [
      _assistant(
        'A divulgação deve considerar o que você oferece e sua capacidade. Vamos revisar uma mensagem antes de publicar?',
      ),
      _card('Divulgação ligada à operação', [
        _line(
          Icons.design_services_outlined,
          'Oferta',
          'Instalação de suporte de TV por orçamento.',
        ),
        _line(
          Icons.event_available_outlined,
          'Disponibilidade',
          'Consultar os horários antes de anunciar vagas.',
        ),
        _tag('Sugestão para revisão'),
      ]),
      _card('Rascunho de mensagem', [
        Text(
          'Precisa instalar sua TV com cuidado? Envie fotos do local para avaliarmos o serviço e prepararmos um orçamento.',
          style: TextStyle(fontSize: 14, height: 1.5, color: c.text),
        ),
        const SizedBox(height: 14),
        _tag('Publicação não habilitada'),
      ], description: 'Exemplo sintético de conteúdo a ser aprovado.'),
      _line(
        Icons.person_outline,
        'Você escolhe o canal e o conteúdo',
        'Nenhuma mensagem é publicada por esta tela.',
      ),
    ],
    JourneyConcept.followUp => [
      _card('Depois da entrega', [
        _line(
          Icons.task_alt,
          'Serviço concluído',
          'Instalação de suporte de TV · Ana Silva',
        ),
        _tag('Cenário de evolução'),
      ]),
      _card('Acompanhar o relacionamento', [
        _step(
          '1',
          'Conferir pendências',
          'Verificar recebimento, dúvidas e ajustes.',
        ),
        _step(
          '2',
          'Pedir um retorno',
          'Preparar mensagem e aguardar sua autorização.',
          current: true,
        ),
        _step(
          '3',
          'Manter o vínculo',
          'Registrar interesse em novo serviço ou indicação.',
        ),
      ]),
      _assistant(
        'Posso sugerir uma mensagem para saber se ficou tudo certo. Você revisa o texto e decide quando enviar.',
      ),
      _card('Retorno para o negócio', [
        Text(
          'O histórico pode orientar novos serviços e a revisão da oferta, respeitando a autorização para contato.',
          style: TextStyle(fontSize: 13, height: 1.4, color: c.textMuted),
        ),
      ]),
    ],
    JourneyConcept.discovery => [
      _card('O que você precisa?', [
        _field('Serviço', 'Instalação de suporte de TV'),
        _field('Região', 'Itapetininga'),
        _tag('Visão do consumidor'),
      ]),
      _card('Prestador demonstrativo', [
        _line(
          Icons.design_services_outlined,
          'Instalações residenciais',
          'Escopo e valor definidos após orçamento.',
        ),
        _line(
          Icons.chat_bubble_outline,
          'Explique sua necessidade',
          'Envie informações do local para combinar o serviço.',
        ),
      ], description: 'Exemplo sintético de apresentação da oferta.'),
      _card('Antes de contratar', [
        _step(
          '1',
          'Solicitar um orçamento',
          'Informar o que precisa e as condições do local.',
        ),
        _step(
          '2',
          'Conferir a proposta',
          'Revisar escopo, valor e prazo com o prestador.',
        ),
        _step('3', 'Combinar a execução', 'Confirmar as condições e a data.'),
      ]),
    ],
  };

  @override
  Widget build(BuildContext context) => Theme(
    data: WorkflowTheme.dark,
    child: Scaffold(
      appBar: AppBar(
        title: Text(
          titles[page.index],
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
        ),
        actions: [
          if (onNavigate != null)
            PopupMenuButton<JourneyConcept>(
              tooltip: 'Ver estudos de interface',
              onSelected: onNavigate,
              itemBuilder: (_) => JourneyConcept.values
                  .map(
                    (p) =>
                        PopupMenuItem(value: p, child: Text(titles[p.index])),
                  )
                  .toList(),
            ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 24),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 560),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Container(
                  key: const Key('concept-status'),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 10,
                  ),
                  margin: const EdgeInsets.only(bottom: 18),
                  decoration: BoxDecoration(
                    color: c.orangeSoft,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: c.orange),
                  ),
                  child: Text(
                    'ESTUDO CONCEITUAL · FUNÇÃO PROPOSTA',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: c.orange,
                    ),
                  ),
                ),
                ..._content(),
              ],
            ),
          ),
        ),
      ),
    ),
  );
}
