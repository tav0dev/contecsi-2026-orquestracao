import 'dart:convert';

import 'package:flutter/material.dart';

import '../services/workflow_api.dart';
import '../theme/workflow_theme.dart';
import '../theme/tokens.dart';
import '../widgets/process_mark.dart';
import '../widgets/assistant_orb.dart';

enum _WorkflowSection { home, agenda, clients, receivables, business }

enum _MoreSection { menu, catalog, materials, preferences }

class RemoteWorkflowScreen extends StatefulWidget {
  final WorkflowApi? api;
  final Brightness? brightness;
  const RemoteWorkflowScreen({super.key, this.api, this.brightness});
  @override
  State<RemoteWorkflowScreen> createState() => _RemoteWorkflowState();
}

class _RemoteWorkflowState extends State<RemoteWorkflowScreen> {
  late final WorkflowApi _api = widget.api ?? WorkflowApi();
  final _email = TextEditingController(), _password = TextEditingController();
  final _request = TextEditingController(),
      _structured = TextEditingController();
  final _scroll = ScrollController();
  final _assistantScroll = ScrollController();
  _WorkflowSection _section = _WorkflowSection.home;
  _MoreSection _moreSection = _MoreSection.menu;
  final _reviewAnchor = GlobalKey(),
      _agendaAnchor = GlobalKey(),
      _noticeAnchor = GlobalKey();
  Map<String, dynamic>? _state, _proposal, _diagnostics;
  int? _reviewAmount;
  String? _message, _detail, _highlightedId;
  bool _busy = false, _confirming = false, _isError = false;
  bool _assistantOpen = false;
  bool _assistantHintDismissed = false;
  final List<Map<String, String>> _chatMessages = [];
  DateTime _calendarMonth = DateTime(DateTime.now().year, DateTime.now().month);
  DateTime? _agendaDay;
  String _agendaStatus = 'all', _agendaService = 'all';
  bool _agendaAscending = true;
  bool _calendarMoved = false;
  Brightness get _brightness =>
      widget.brightness ?? Theme.of(context).brightness;
  BicoTokens get _colors =>
      _brightness == Brightness.dark ? BicoTokens.dark : BicoTokens.light;
  Color get _actionColor =>
      _brightness == Brightness.dark ? _colors.green : _colors.greenDark;

  @override
  void initState() {
    super.initState();
    if (_api.authenticated) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _run(_refresh);
      });
    }
  }

  List<Map<String, dynamic>> _items(String field) =>
      ((_state?[field] as List?) ?? [])
          .whereType<Map>()
          .map((v) => Map<String, dynamic>.from(v))
          .toList();

  Map<String, dynamic> _lookup(String field, String key, dynamic value) =>
      _items(field).firstWhere((v) => v[key] == value, orElse: () => {});

  String _client(dynamic id) =>
      _lookup('clients', 'id', id)['label']?.toString() ?? 'Cliente';
  String _service(dynamic id) =>
      _lookup('services', 'id', id)['label']?.toString() ?? 'Serviço';
  int? _amount(Map<String, dynamic> value) =>
      _integer(
        _lookup(
          'receivables',
          'request_id',
          value['request_id'],
        )['amount_cents'],
      ) ??
      _integer(_lookup('services', 'id', value['service_id'])['price_cents']);

  void _notice(String message, {String? detail, bool error = false}) {
    if (mounted)
      setState(() {
        _message = message;
        _detail = detail;
        _isError = error;
      });
    _reveal(message == 'Atendimento agendado' ? _agendaAnchor : _noticeAnchor);
  }

  Future<void> _run(Future<void> Function() work) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await work();
    } catch (error) {
      _notice(
        'Não foi possível concluir',
        detail: _friendlyError(error),
        error: true,
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _refresh() async {
    final state = await _api.call('/state');
    if (mounted)
      setState(() {
        _state = state;
        if (!_calendarMoved) {
          final dates =
              _items('orders')
                  .map((o) => _localDate(o['starts_at']))
                  .whereType<DateTime>()
                  .toList()
                ..sort();
          if (dates.isNotEmpty)
            _calendarMonth = DateTime(dates.first.year, dates.first.month);
        }
      });
  }

  void _clearProposal() {
    setState(() {
      _proposal = null;
      _reviewAmount = null;
    });
  }

  void _reveal(GlobalKey key) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final target = key.currentContext;
      if (mounted && target != null) {
        Scrollable.ensureVisible(
          target,
          duration: const Duration(milliseconds: 250),
          alignment: .12,
        );
      }
    });
  }

  String _statusMessage(dynamic status) {
    switch (status) {
      case 'conflict':
        return 'Esse horário já está ocupado. Escolha outro horário.';
      case 'insufficient_stock':
        return 'Não há material suficiente para esse atendimento.';
      case 'idempotency_mismatch':
        return 'A proposta mudou. Prepare uma nova antes de confirmar.';
      case 'cancelled':
        return 'Esse atendimento já foi cancelado. Prepare uma nova proposta.';
      case 'invalid_transition':
        return 'Esse atendimento já foi finalizado e não pode ser alterado.';
      case 'reconciliation_required':
        return 'Esse valor precisa ser conferido antes do cancelamento.';
      case 'not_found':
        return 'Atendimento não encontrado. Atualize a agenda.';
      default:
        return 'Atualize os dados e tente novamente.';
    }
  }

  void _acceptReview(
    Map<String, dynamic> proposal,
    Map<String, dynamic> review,
  ) {
    if (review['status'] == 'awaiting_confirmation') {
      setState(() {
        _assistantOpen = true;
        _proposal = proposal;
        _reviewAmount = _integer(review['amount_cents']);
        _message = null;
        _detail = null;
      });
      _reveal(_reviewAnchor);
    } else {
      _notice(
        'Ajuste seu pedido',
        detail: _statusMessage(review['status']),
        error: true,
      );
    }
  }

  Future<void> _plan() async {
    if (_request.text.trim().isEmpty) return;
    final request = _request.text.trim();
    _clearProposal();
    setState(() {
      _chatMessages.add({'role': 'user', 'text': request});
      _request.clear();
      _message = null;
      _detail = null;
    });
    final result = await _api.call('/plan', {'request': request});
    if (!mounted) return;
    setState(() => _diagnostics = result);
    final plan = Map<String, dynamic>.from(result['plan'] as Map);
    if (plan['status'] == 'proposed' &&
        result['proposal'] is Map &&
        result['review'] is Map) {
      setState(
        () => _chatMessages.add({
          'role': 'assistant',
          'text':
              plan['draft']?.toString() ??
              'Preparei a proposta. Confira os detalhes antes de confirmar.',
        }),
      );
      _acceptReview(
        Map<String, dynamic>.from(result['proposal']),
        Map<String, dynamic>.from(result['review']),
      );
    } else {
      _notice(
        plan['status'] == 'needs_clarification'
            ? 'Preciso de mais uma informação'
            : 'Não consegui preparar esse pedido',
        detail:
            plan['draft']?.toString() ??
            'Informe cliente, serviço, dia e horário.',
        error: plan['status'] != 'needs_clarification',
      );
    }
  }

  Future<void> _confirmBooking() async {
    final proposal = _proposal;
    if (proposal == null) return;
    // A aprovação é o clique humano no cartão revisado. Gerar nunca confirma.
    final result = await _api.call('/confirm', {
      'proposal': proposal,
      'approved': true,
    });
    if (!mounted) return;
    if (result['status'] == 'committed' || result['status'] == 'duplicate') {
      setState(() {
        _section = _WorkflowSection.agenda;
        _assistantOpen = false;
        _highlightedId = proposal['request_id']?.toString();
        _agendaDay = null;
        _agendaStatus = 'all';
        _agendaService = 'all';
        final when = _localDate(proposal['start']);
        if (when != null) _calendarMonth = DateTime(when.year, when.month);
        _proposal = null;
        _reviewAmount = null;
        _request.clear();
        _chatMessages.add({
          'role': 'assistant',
          'text': 'Agendamento confirmado. Você pode acompanhá-lo na Agenda.',
        });
      });
      _notice(
        'Atendimento agendado',
        detail:
            _client(proposal['client_id']) +
            ' · ' +
            _when(proposal['start']) +
            '. Você já pode acompanhá-lo na agenda.',
      );
      // A gravação já foi reconhecida; erro de atualização não deve sugerir reenvio.
      try {
        await _refresh();
      } catch (_) {
        _notice(
          'Atendimento agendado',
          detail:
              'A confirmação foi recebida. Use Atualizar para carregar a agenda; não é preciso confirmar de novo.',
        );
      }
      _reveal(_agendaAnchor);
    } else {
      _clearProposal();
      _notice(
        'Não foi possível agendar',
        detail: _statusMessage(result['status']),
        error: true,
      );
      await _refresh();
    }
  }

  Future<bool> _approve(String title, String description, String button) async {
    setState(() => _confirming = true);
    try {
      return await showDialog<bool>(
            context: context,
            builder: (ctx) => AlertDialog(
              title: Text(title),
              content: Text(description),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(ctx, false),
                  child: const Text('Voltar'),
                ),
                FilledButton(
                  onPressed: () => Navigator.pop(ctx, true),
                  child: Text(button),
                ),
              ],
            ),
          ) ??
          false;
    } finally {
      if (mounted) setState(() => _confirming = false);
    }
  }

  Future<void> _transition(Map<String, dynamic> order, String action) async {
    final complete = action == 'complete';
    if (!await _approve(
      complete ? 'Concluir atendimento?' : 'Cancelar atendimento?',
      _client(order['client_id']) +
          ' · ' +
          _when(order['starts_at']) +
          '\n\n' +
          (complete
              ? 'Os materiais reservados serão registrados como utilizados. O valor continua a receber.'
              : 'Os materiais serão liberados e o valor deste atendimento deixará de constar a receber.'),
      complete ? 'Concluir atendimento' : 'Cancelar atendimento',
    ))
      return;
    final result = await _api.call('/transition', {
      'request_id': order['request_id'],
      'action': action,
      'approved': true,
    });
    if (!mounted) return;
    if (result['status'] == (complete ? 'completed' : 'cancelled') ||
        result['status'] == 'duplicate') {
      _notice(
        complete ? 'Atendimento concluído' : 'Atendimento cancelado',
        detail: complete
            ? 'Os materiais foram registrados como utilizados.'
            : 'A reserva de materiais foi liberada.',
      );
      try {
        await _refresh();
      } catch (_) {
        _notice(
          complete ? 'Atendimento concluído' : 'Atendimento cancelado',
          detail: 'Use Atualizar para carregar o estado mais recente.',
        );
      }
    } else {
      _notice(
        'Não foi possível alterar o atendimento',
        detail: _statusMessage(result['status']),
        error: true,
      );
    }
  }

  void _example() {
    final clients = _items('clients'), services = _items('services');
    if (clients.isEmpty || services.isEmpty) return;
    final day = DateTime.now()
        .toUtc()
        .subtract(const Duration(hours: 3))
        .add(const Duration(days: 1));
    _request.text =
        'Agende ' +
        clients.first['label'].toString() +
        ' no serviço ' +
        services.first['label'].toString() +
        ' para ' +
        _day(day) +
        ' às 14h, horário de Brasília.';
    _clearProposal();
  }

  @override
  void dispose() {
    for (final controller in [_email, _password, _request, _structured]) {
      controller.dispose();
    }
    _scroll.dispose();
    _assistantScroll.dispose();
    _api.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope<Object?>(
      canPop:
          !_assistantOpen &&
          !(_section == _WorkflowSection.business &&
              _moreSection != _MoreSection.menu),
      onPopInvokedWithResult: (didPop, result) {
        if (didPop) return;
        if (_assistantOpen)
          _closeAssistant();
        else if (_section == _WorkflowSection.business)
          _openMoreSection(_MoreSection.menu);
      },
      child: Theme(
        data: WorkflowTheme.forBrightness(_brightness),
        child: Scaffold(
          appBar: AppBar(
            leading: const Padding(
              padding: EdgeInsets.all(12),
              child: ProcessMark(),
            ),
            titleSpacing: 0,
            title: Text(
              _state?['name']?.toString() ?? 'Meu negócio',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
            ),
            backgroundColor: _colors.bg,
            actions: [
              if (_api.authenticated)
                IconButton(
                  tooltip: 'Atualizar dados',
                  onPressed: _busy ? null : () => _run(_refresh),
                  icon: const Icon(Icons.refresh),
                ),
              if (_state != null)
                PopupMenuButton<String>(
                  tooltip: 'Mais opções',
                  enabled: !_busy,
                  onSelected: (_) => _tools(),
                  itemBuilder: (_) => [
                    const PopupMenuItem(
                      value: 'tools',
                      child: Text('Ferramentas de teste'),
                    ),
                  ],
                ),
              const SizedBox(width: 12),
            ],
          ),
          bottomNavigationBar: _api.authenticated ? _navigation() : null,
          floatingActionButton: _api.authenticated && !_assistantOpen
              ? _assistantLauncher()
              : null,
          body: LayoutBuilder(
            builder: (context, constraints) => Stack(
              fit: StackFit.expand,
              children: [
                SelectionArea(
                  child: SingleChildScrollView(
                    controller: _scroll,
                    padding: EdgeInsets.fromLTRB(
                      20,
                      20,
                      20,
                      _assistantHintDismissed ? 90 : 170,
                    ),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 1080),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            if (!_assistantOpen &&
                                _message != null &&
                                _message != 'Atendimento agendado')
                              Padding(
                                key: _noticeAnchor,
                                padding: const EdgeInsets.only(bottom: 16),
                                child: _noticeCard(),
                              ),
                            if (!_api.authenticated)
                              _login()
                            else ...[
                              Wrap(
                                alignment: WrapAlignment.spaceBetween,
                                crossAxisAlignment: WrapCrossAlignment.center,
                                spacing: 16,
                                runSpacing: 8,
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        switch (_section) {
                                          _WorkflowSection.home =>
                                            'Visão geral',
                                          _WorkflowSection.agenda => 'Agenda',
                                          _WorkflowSection.clients =>
                                            'Contatos',
                                          _WorkflowSection.receivables =>
                                            'Carteira',
                                          _WorkflowSection.business =>
                                            _moreTitle,
                                        },
                                        style: Theme.of(context)
                                            .textTheme
                                            .headlineSmall
                                            ?.copyWith(
                                              fontWeight: FontWeight.bold,
                                              color: _colors.text,
                                            ),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        _state?['name']?.toString() ??
                                            'Carregando seu negócio…',
                                        style: TextStyle(
                                          color: _colors.textMuted,
                                        ),
                                      ),
                                    ],
                                  ),
                                  _Pill(
                                    'Ambiente de teste',
                                    color: _colors.purple,
                                  ),
                                ],
                              ),
                              const SizedBox(height: 20),
                              if (_state != null &&
                                  _state?['needs_setup'] != true &&
                                  (_section == _WorkflowSection.home))
                                _overview(),
                              if (_busy && !_confirming) ...[
                                const LinearProgressIndicator(),
                                const SizedBox(height: 12),
                              ],
                              if (_state == null && !_busy)
                                _Panel(
                                  title: 'Vamos carregar sua agenda',
                                  child: FilledButton(
                                    onPressed: () => _run(_refresh),
                                    child: const Text('Carregar agenda'),
                                  ),
                                ),
                              if (_state?['needs_setup'] == true) _setup(),
                              if (_state?['tenant_id'] != null) ...[
                                const SizedBox(height: 20),
                                switch (_section) {
                                  _WorkflowSection.home => _home(),
                                  _WorkflowSection.agenda => Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.stretch,
                                    children: [
                                      _agenda(),
                                      const SizedBox(height: 16),
                                      _materials(),
                                    ],
                                  ),
                                  _WorkflowSection.clients => _clients(),
                                  _WorkflowSection.receivables => _wallet(),
                                  _WorkflowSection.business => _more(),
                                },
                              ],
                            ],
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 24),
                              child: Text(
                                'Dados sintéticos para teste. Os valores ficam anotados aqui; pagamentos e mensagens externas estão desativados.',
                                style: TextStyle(
                                  fontSize: 12,
                                  color: _colors.textMuted,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                if (_assistantOpen)
                  Positioned(
                    right: 12,
                    bottom: 12,
                    width: constraints.maxWidth > 384
                        ? 360
                        : (constraints.maxWidth - 24).clamp(0.0, 360.0),
                    height: constraints.maxHeight > 464
                        ? 440
                        : (constraints.maxHeight - 24).clamp(0.0, 440.0),
                    child: _assistantPopup(),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _assistantLauncher() => Column(
    mainAxisSize: MainAxisSize.min,
    crossAxisAlignment: CrossAxisAlignment.end,
    children: [
      if (!_assistantHintDismissed) ...[
        Container(
          key: const Key('assistant-invitation'),
          width: 248,
          decoration: BoxDecoration(
            color: _colors.bg,
            border: Border.all(color: _colors.purple.withValues(alpha: .55)),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            children: [
              Expanded(
                child: TextButton(
                  onPressed: _state?['tenant_id'] != null
                      ? _openAssistant
                      : null,
                  child: Text(
                    'Oi! Posso te ajudar?\nFale comigo.',
                    style: TextStyle(fontSize: 13, color: _colors.text),
                  ),
                ),
              ),
              IconButton(
                key: const Key('dismiss-assistant-hint'),
                tooltip: 'Dispensar convite',
                onPressed: () => setState(() => _assistantHintDismissed = true),
                icon: Icon(Icons.close, size: 17, color: _colors.textMuted),
              ),
            ],
          ),
        ),
        const SizedBox(height: 10),
      ],
      FloatingActionButton(
        key: const Key('ask-ai'),
        tooltip: 'Conversar com o assistente',
        onPressed: _state?['tenant_id'] != null ? _openAssistant : null,
        backgroundColor: Colors.transparent,
        elevation: 0,
        focusElevation: 0,
        hoverElevation: 0,
        highlightElevation: 0,
        disabledElevation: 0,
        clipBehavior: Clip.antiAlias,
        shape: const CircleBorder(),
        child: const AssistantOrb(size: 56),
      ),
    ],
  );

  Widget _navigation() => Container(
    key: const Key('workflow-navigation'),
    decoration: BoxDecoration(
      color: _colors.bg,
      border: Border(top: BorderSide(color: _colors.border)),
    ),
    padding: const EdgeInsets.fromLTRB(8, 8, 8, 10),
    child: SafeArea(
      top: false,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Row(
            children: [
              for (final section in _WorkflowSection.values)
                Expanded(
                  child: TextButton(
                    key: Key('nav-${section.name}'),
                    style: TextButton.styleFrom(
                      backgroundColor: _section == section
                          ? _colors.greenSoft
                          : _colors.bg,
                      foregroundColor: _section == section
                          ? _actionColor
                          : _colors.textMuted,
                      minimumSize: const Size(0, 56),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                    ),
                    onPressed: () => _navigate(section),
                    child: Semantics(
                      selected: _section == section,
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(switch (section) {
                            _WorkflowSection.home => Icons.home_outlined,
                            _WorkflowSection.agenda =>
                              Icons.calendar_today_outlined,
                            _WorkflowSection.clients => Icons.people_outline,
                            _WorkflowSection.receivables =>
                              Icons.account_balance_wallet_outlined,
                            _WorkflowSection.business => Icons.menu,
                          }, size: 22),
                          const SizedBox(height: 4),
                          Text(switch (section) {
                            _WorkflowSection.home => 'Início',
                            _WorkflowSection.agenda => 'Agenda',
                            _WorkflowSection.clients => 'Contatos',
                            _WorkflowSection.receivables => 'Carteira',
                            _WorkflowSection.business => 'Mais',
                          }, style: const TextStyle(fontSize: 12)),
                        ],
                      ),
                    ),
                  ),
                ),
            ],
          ),
        ],
      ),
    ),
  );

  void _navigate(_WorkflowSection section) {
    if (_section == section && !_assistantOpen) {
      if (section == _WorkflowSection.business &&
          _moreSection != _MoreSection.menu) {
        _openMoreSection(_MoreSection.menu);
      }
      return;
    }
    FocusScope.of(context).unfocus();
    setState(() {
      _section = section;
      _assistantOpen = false;
      _assistantHintDismissed = true;
      if (section == _WorkflowSection.business)
        _moreSection = _MoreSection.menu;
    });
    if (_scroll.hasClients) _scroll.jumpTo(0);
  }

  String get _moreTitle => switch (_moreSection) {
    _MoreSection.menu => 'Mais',
    _MoreSection.catalog => 'Catálogo',
    _MoreSection.materials => 'Materiais',
    _MoreSection.preferences => 'Preferências',
  };

  void _openMoreSection(_MoreSection section) {
    FocusScope.of(context).unfocus();
    setState(() => _moreSection = section);
    if (_scroll.hasClients) _scroll.jumpTo(0);
  }

  void _openAssistant() {
    FocusScope.of(context).unfocus();
    setState(() {
      _assistantOpen = true;
      _assistantHintDismissed = true;
    });
    if (_assistantScroll.hasClients) _assistantScroll.jumpTo(0);
  }

  void _closeAssistant() {
    FocusScope.of(context).unfocus();
    setState(() => _assistantOpen = false);
  }

  Widget _chatBubble(String text, {bool user = false}) => Align(
    alignment: user ? Alignment.centerRight : Alignment.centerLeft,
    child: Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      constraints: const BoxConstraints(maxWidth: 290),
      decoration: BoxDecoration(
        color: user ? _colors.purpleSoft : _colors.bgSoft,
        borderRadius: BorderRadius.only(
          topLeft: const Radius.circular(14),
          topRight: const Radius.circular(14),
          bottomLeft: Radius.circular(user ? 14 : 4),
          bottomRight: Radius.circular(user ? 4 : 14),
        ),
      ),
      child: Text(
        text,
        style: TextStyle(fontSize: 13, color: _colors.text, height: 1.35),
      ),
    ),
  );

  Widget _assistantPopup() => Material(
    key: const Key('assistant-popup'),
    color: _colors.bg,
    elevation: 0,
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(18),
      side: BorderSide(color: _colors.purple.withValues(alpha: .55)),
    ),
    clipBehavior: Clip.antiAlias,
    child: Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 4, 4),
          child: Row(
            children: [
              const AssistantOrb(size: 30),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Seu assistente',
                  style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700),
                ),
              ),
              IconButton(
                key: const Key('close-assistant'),
                tooltip: 'Fechar conversa',
                onPressed: _closeAssistant,
                icon: const Icon(Icons.close, size: 20),
              ),
            ],
          ),
        ),
        Divider(height: 1, color: _colors.border),
        Expanded(
          child: SingleChildScrollView(
            key: const Key('assistant-scroll'),
            controller: _assistantScroll,
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (_chatMessages.isEmpty) ...[
                  _chatBubble(
                    'Oi! Posso preparar um agendamento. Diga o cliente, o serviço, o dia e o horário. Você confere antes de confirmar.',
                  ),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: TextButton(
                      onPressed: _busy ? null : _example,
                      child: const Text(
                        'Usar um exemplo',
                        style: TextStyle(fontSize: 12),
                      ),
                    ),
                  ),
                ],
                for (final message in _chatMessages)
                  _chatBubble(
                    message['text']!,
                    user: message['role'] == 'user',
                  ),
                if (_message != null) ...[
                  _noticeCard(),
                  const SizedBox(height: 10),
                ],
                if (_busy) ...[
                  const LinearProgressIndicator(),
                  const SizedBox(height: 10),
                ],
                if (_proposal != null) _review(),
              ],
            ),
          ),
        ),
        Divider(height: 1, color: _colors.border),
        Padding(
          key: const Key('chat-composer'),
          padding: const EdgeInsets.all(10),
          child: _planner(),
        ),
      ],
    ),
  );

  Widget _home() {
    final upcoming =
        _items('orders').where((o) => o['state'] == 'reserved').toList()..sort(
          (a, b) =>
              a['starts_at'].toString().compareTo(b['starts_at'].toString()),
        );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _Panel(
          title: 'Para revisar',
          subtitle: _proposal == null
              ? 'Nenhuma proposta aguardando sua decisão.'
              : 'Há 1 proposta aguardando sua decisão.',
          child: _proposal == null
              ? const Text(
                  'Converse com o assistente para preparar uma proposta.',
                )
              : OutlinedButton.icon(
                  key: const Key('resume-review'),
                  onPressed: _openAssistant,
                  icon: const Icon(Icons.fact_check_outlined),
                  label: const Text('Revisar proposta'),
                ),
        ),
        const SizedBox(height: 16),
        _Panel(
          title: 'Próximos atendimentos',
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              if (upcoming.isEmpty)
                const Text('Nenhum atendimento agendado por enquanto.'),
              for (final order in upcoming.take(3))
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(_client(order['client_id'])),
                  subtitle: Text(
                    '${_when(order['starts_at'])}\n${_service(order['service_id'])}',
                  ),
                  isThreeLine: true,
                ),
              TextButton(
                onPressed: () => _navigate(_WorkflowSection.agenda),
                child: const Text('Ver atendimentos'),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _clients() => _Panel(
    title: 'Contatos cadastrados',
    subtitle: 'Pessoas e histórico de serviços em um só lugar.',
    child: _items('clients').isEmpty
        ? const Text('Nenhum contato cadastrado.')
        : Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              for (final client in _items('clients'))
                ExpansionTile(
                  key: ValueKey('client-${client['id']}'),
                  tilePadding: EdgeInsets.zero,
                  leading: const Icon(Icons.person_outline),
                  title: Text(client['label']?.toString() ?? 'Cliente'),
                  subtitle: Text(
                    _items('orders').any((o) => o['client_id'] == client['id'])
                        ? '${_items('orders').where((o) => o['client_id'] == client['id']).length} serviço(s) no histórico'
                        : 'Sem serviços no histórico',
                  ),
                  children: [
                    if (!_items(
                      'orders',
                    ).any((o) => o['client_id'] == client['id']))
                      const Padding(
                        padding: EdgeInsets.all(12),
                        child: Text('Ainda sem atendimentos.'),
                      ),
                    for (final order in _items(
                      'orders',
                    ).where((o) => o['client_id'] == client['id']))
                      ListTile(
                        contentPadding: EdgeInsets.zero,
                        title: Text(_service(order['service_id'])),
                        subtitle: Text(_when(order['starts_at'])),
                        trailing: Text(_orderStatus(order['state'])),
                      ),
                  ],
                ),
            ],
          ),
  );

  Widget _catalog() => _Panel(
    title: 'Catálogo de serviços',
    subtitle: 'Duração e valores usados na preparação das propostas.',
    child: _items('services').isEmpty
        ? const Text('Nenhum serviço cadastrado.')
        : Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              for (final service in _items('services'))
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text(service['label']?.toString() ?? 'Serviço'),
                  subtitle: Text('${service['duration_minutes']} minutos'),
                  trailing: Text(_money(_integer(service['price_cents']))),
                ),
            ],
          ),
  );

  Widget _menuEntry({
    required Key key,
    required IconData icon,
    required String title,
    required String subtitle,
    required _MoreSection destination,
    bool preference = false,
  }) => ListTile(
    key: key,
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    leading: Container(
      width: 42,
      height: 42,
      decoration: BoxDecoration(
        color: preference ? _colors.purpleSoft : _colors.greenSoft,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(
        icon,
        size: 22,
        color: preference ? _colors.purple : _actionColor,
      ),
    ),
    title: Text(
      title,
      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
    ),
    subtitle: Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Text(
        subtitle,
        style: TextStyle(fontSize: 12, color: _colors.textMuted),
      ),
    ),
    trailing: Icon(Icons.chevron_right, size: 21, color: _colors.textMuted),
    onTap: () => _openMoreSection(destination),
  );

  Widget _menuGroup(String title, List<Widget> entries) => Column(
    crossAxisAlignment: CrossAxisAlignment.stretch,
    children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(4, 0, 4, 10),
        child: Text(
          title,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: _colors.textMuted,
          ),
        ),
      ),
      Material(
        color: _colors.bg,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: _colors.border),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          children: [
            for (var i = 0; i < entries.length; i++) ...[
              if (i > 0)
                Divider(
                  height: 1,
                  indent: 74,
                  endIndent: 16,
                  color: _colors.border,
                ),
              entries[i],
            ],
          ],
        ),
      ),
    ],
  );

  Widget _preferences() => _Panel(
    title: 'Horários e região',
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        ListTile(
          contentPadding: EdgeInsets.zero,
          leading: Icon(Icons.schedule_outlined, color: _colors.purple),
          title: const Text('Horário de Brasília'),
          subtitle: const Text('UTC−3'),
        ),
        const SizedBox(height: 10),
        Text(
          'Os horários da agenda e das propostas seguem esta referência.',
          style: TextStyle(color: _colors.textMuted, height: 1.4),
        ),
      ],
    ),
  );

  Widget _more() => Align(
    alignment: Alignment.topLeft,
    child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 680),
      child: _moreSection == _MoreSection.menu
          ? Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _menuGroup('Seu negócio', [
                  _menuEntry(
                    key: const Key('more-catalog'),
                    icon: Icons.design_services_outlined,
                    title: 'Catálogo de serviços',
                    subtitle:
                        '${_items('services').length} ${_items('services').length == 1 ? 'serviço cadastrado' : 'serviços cadastrados'}',
                    destination: _MoreSection.catalog,
                  ),
                  _menuEntry(
                    key: const Key('more-materials'),
                    icon: Icons.inventory_2_outlined,
                    title: 'Materiais',
                    subtitle: 'Disponibilidade e reservas',
                    destination: _MoreSection.materials,
                  ),
                ]),
                const SizedBox(height: 24),
                _menuGroup('Preferências', [
                  _menuEntry(
                    key: const Key('more-preferences'),
                    icon: Icons.schedule_outlined,
                    title: 'Horários e região',
                    subtitle: 'Brasília · UTC−3',
                    destination: _MoreSection.preferences,
                    preference: true,
                  ),
                ]),
              ],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    key: const Key('more-back'),
                    onPressed: () => _openMoreSection(_MoreSection.menu),
                    icon: const Icon(Icons.arrow_back, size: 20),
                    label: const Text('Voltar para Mais'),
                  ),
                ),
                const SizedBox(height: 12),
                switch (_moreSection) {
                  _MoreSection.catalog => _catalog(),
                  _MoreSection.materials => _materials(),
                  _MoreSection.preferences => _preferences(),
                  _MoreSection.menu => const SizedBox.shrink(),
                },
              ],
            ),
    ),
  );

  Widget _login() => Center(
    child: ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 440),
      child: _Panel(
        title: 'Acesse seu negócio',
        subtitle: 'Acesse sua agenda e acompanhe os atendimentos.',
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            TextField(
              controller: _email,
              enabled: !_busy,
              keyboardType: TextInputType.emailAddress,
              autofillHints: const [AutofillHints.email],
              decoration: const InputDecoration(labelText: 'E-mail'),
            ),
            const SizedBox(height: 14),
            TextField(
              controller: _password,
              enabled: !_busy,
              obscureText: true,
              onSubmitted: (_) {
                if (!_busy) _run(_signIn);
              },
              decoration: const InputDecoration(labelText: 'Senha'),
            ),
            const SizedBox(height: 20),
            FilledButton(
              onPressed: _busy ? null : () => _run(_signIn),
              child: Text(_busy ? 'Entrando…' : 'Entrar'),
            ),
            const SizedBox(height: 12),
            Text(
              'Use a conta cadastrada na plataforma.',
              style: TextStyle(fontSize: 12, color: _colors.textMuted),
            ),
          ],
        ),
      ),
    ),
  );

  Future<void> _signIn() async {
    if (_email.text.trim().isEmpty || _password.text.isEmpty) {
      _notice('Preencha seu e-mail e sua senha', error: true);
      return;
    }
    try {
      await _api.login(_email.text.trim(), _password.text);
    } finally {
      if (mounted) _password.clear();
    }
    if (mounted)
      setState(() {
        _message = null;
        _detail = null;
      });
    await _refresh();
  }

  Widget _overview() {
    final upcoming = _items(
      'orders',
    ).where((o) => o['state'] == 'reserved').length;
    final stock = _items('stock');
    final pending = _items('receivables')
        .where((r) => r['state'] == 'pending')
        .fold<int>(0, (sum, r) => sum + (_integer(r['amount_cents']) ?? 0));
    final material = stock.length == 1
        ? (stock.first['available']?.toString() ?? '0')
        : stock.length.toString();
    return LayoutBuilder(
      builder: (context, constraints) {
        final narrow = constraints.maxWidth < 650;
        final width = narrow
            ? (constraints.maxWidth - 12) / 2
            : (constraints.maxWidth - 24) / 3;
        return Wrap(
          spacing: 12,
          runSpacing: 12,
          children: [
            _Metric(
              'Agendados',
              upcoming.toString(),
              Icons.calendar_month_outlined,
              width: width,
            ),
            _Metric(
              stock.length == 1 ? 'Kits disponíveis' : 'Tipos de material',
              material,
              Icons.inventory_2_outlined,
              width: width,
            ),
            Semantics(
              button: true,
              label: 'Abrir carteira',
              child: InkWell(
                key: const Key('open-wallet-summary'),
                borderRadius: BorderRadius.circular(18),
                onTap: () => _navigate(_WorkflowSection.receivables),
                child: _Metric(
                  'A receber',
                  _money(pending),
                  Icons.account_balance_wallet_outlined,
                  width: narrow ? constraints.maxWidth : width,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _setup() => _Panel(
    title: 'Prepare seu ambiente de teste',
    subtitle:
        'Crie um cliente, um serviço e três kits para experimentar o fluxo.',
    child: FilledButton(
      onPressed: _busy
          ? null
          : () => _run(() async {
              if (!await _approve(
                'Criar dados de teste?',
                'Será criado um catálogo sintético para sua conta.',
                'Criar dados',
              ))
                return;
              await _api.call('/setup', {'approved': true});
              await _refresh();
            }),
      child: const Text('Criar dados de teste'),
    ),
  );

  bool get _canPlan =>
      !_busy &&
      _state?['capabilities']?['ai'] == true &&
      _request.text.trim().isNotEmpty;

  Widget _planner() => Row(
    crossAxisAlignment: CrossAxisAlignment.end,
    children: [
      Expanded(
        child: TextField(
          key: const Key('request-field'),
          controller: _request,
          enabled: !_busy,
          minLines: 1,
          maxLines: 3,
          textInputAction: TextInputAction.send,
          style: const TextStyle(fontSize: 14),
          onChanged: (_) => _clearProposal(),
          onSubmitted: (_) {
            if (_canPlan) _run(_plan);
          },
          decoration: const InputDecoration(
            hintText: 'Escreva sua mensagem…',
            isDense: true,
            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          ),
        ),
      ),
      const SizedBox(width: 8),
      IconButton.filled(
        key: const Key('prepare-button'),
        tooltip: _busy ? 'Preparando proposta' : 'Enviar pedido',
        onPressed: _canPlan ? () => _run(_plan) : null,
        icon: const Icon(Icons.arrow_upward, size: 21),
        constraints: const BoxConstraints(minWidth: 44, minHeight: 44),
      ),
    ],
  );

  Widget _review() {
    final proposal = _proposal!;
    return Container(
      key: _reviewAnchor,
      child: Container(
        key: const Key('proposal-review'),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: _colors.bgSoft,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: _colors.green),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Confira antes de agendar',
              style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 10),
            Text(
              _client(proposal['client_id']),
              style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 4),
            Text(
              _service(proposal['service_id']),
              style: const TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 4),
            Text(
              _when(proposal['start']),
              style: const TextStyle(fontSize: 13),
            ),
            const SizedBox(height: 6),
            Wrap(
              alignment: WrapAlignment.spaceBetween,
              spacing: 12,
              children: [
                Text(
                  '${proposal['duration_minutes']} minutos',
                  style: const TextStyle(fontSize: 13),
                ),
                Text(
                  _money(_reviewAmount ?? _amount(proposal)),
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'Confirmar reserva o horário, separa os materiais e anota o valor a receber.',
              style: TextStyle(
                fontSize: 12,
                color: _colors.textMuted,
                height: 1.3,
              ),
            ),
            const SizedBox(height: 10),
            FilledButton.icon(
              key: const Key('confirm-booking'),
              onPressed: _busy ? null : () => _run(_confirmBooking),
              icon: const Icon(Icons.check, size: 17),
              style: FilledButton.styleFrom(
                minimumSize: const Size(0, 40),
                textStyle: const TextStyle(
                  fontFamily: 'Roboto',
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
              label: Text(_busy ? 'Agendando…' : 'Confirmar agendamento'),
            ),
            TextButton(
              onPressed: _busy
                  ? null
                  : () {
                      final userMessages = _chatMessages.where(
                        (m) => m['role'] == 'user',
                      );
                      if (userMessages.isNotEmpty)
                        _request.text = userMessages.last['text']!;
                      _clearProposal();
                    },
              child: const Text(
                'Ajustar pedido',
                style: TextStyle(fontSize: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }

  DateTime? _localDate(dynamic value) {
    final parsed = DateTime.tryParse(value?.toString() ?? '');
    if (parsed == null) return null;
    final local = parsed.toUtc().subtract(const Duration(hours: 3));
    return DateTime(local.year, local.month, local.day);
  }

  bool _sameDay(DateTime? a, DateTime? b) =>
      a != null &&
      b != null &&
      a.year == b.year &&
      a.month == b.month &&
      a.day == b.day;

  Widget _calendar() {
    const months = [
      'Janeiro',
      'Fevereiro',
      'Março',
      'Abril',
      'Maio',
      'Junho',
      'Julho',
      'Agosto',
      'Setembro',
      'Outubro',
      'Novembro',
      'Dezembro',
    ];
    final days = DateTime(_calendarMonth.year, _calendarMonth.month + 1, 0).day;
    final leading = (_calendarMonth.weekday - 1) % 7;
    final count = ((leading + days + 6) ~/ 7) * 7;
    final orderDates = _items(
      'orders',
    ).map((o) => _localDate(o['starts_at'])).whereType<DateTime>();
    return Column(
      children: [
        Row(
          children: [
            IconButton(
              key: const Key('calendar-previous'),
              tooltip: 'Mês anterior',
              onPressed: () => setState(() {
                _calendarMoved = true;
                _agendaDay = null;
                _calendarMonth = DateTime(
                  _calendarMonth.year,
                  _calendarMonth.month - 1,
                );
              }),
              icon: const Icon(Icons.chevron_left),
            ),
            Expanded(
              child: Text(
                '${months[_calendarMonth.month - 1]} ${_calendarMonth.year}',
                textAlign: TextAlign.center,
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
            IconButton(
              key: const Key('calendar-next'),
              tooltip: 'Próximo mês',
              onPressed: () => setState(() {
                _calendarMoved = true;
                _agendaDay = null;
                _calendarMonth = DateTime(
                  _calendarMonth.year,
                  _calendarMonth.month + 1,
                );
              }),
              icon: const Icon(Icons.chevron_right),
            ),
          ],
        ),
        Row(
          children: [
            for (final label in ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'])
              Expanded(
                child: Center(
                  child: Text(
                    label,
                    style: TextStyle(fontSize: 11, color: _colors.textMuted),
                  ),
                ),
              ),
          ],
        ),
        const SizedBox(height: 4),
        GridView.count(
          key: const Key('agenda-calendar'),
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: 7,
          childAspectRatio: 1.25,
          children: [
            for (var i = 0; i < count; i++)
              if (i < leading || i >= leading + days)
                const SizedBox.shrink()
              else
                Builder(
                  builder: (context) {
                    final day = DateTime(
                      _calendarMonth.year,
                      _calendarMonth.month,
                      i - leading + 1,
                    );
                    final selected = _sameDay(day, _agendaDay);
                    final hasOrders = orderDates.any(
                      (date) => _sameDay(day, date),
                    );
                    return Semantics(
                      selected: selected,
                      label: '${_day(day)}${hasOrders ? ', com serviços' : ''}',
                      child: InkWell(
                        key: ValueKey(
                          'calendar-day-${day.year}-${day.month}-${day.day}',
                        ),
                        borderRadius: BorderRadius.circular(10),
                        onTap: () =>
                            setState(() => _agendaDay = selected ? null : day),
                        child: Container(
                          decoration: BoxDecoration(
                            color: selected ? _colors.purpleSoft : null,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(
                                '${day.day}',
                                style: TextStyle(
                                  fontSize: 13,
                                  color: selected
                                      ? _colors.purple
                                      : _colors.text,
                                  fontWeight: selected
                                      ? FontWeight.w700
                                      : FontWeight.w400,
                                ),
                              ),
                              SizedBox(
                                height: 6,
                                child: hasOrders
                                    ? Center(
                                        child: Container(
                                          width: 4,
                                          height: 4,
                                          decoration: BoxDecoration(
                                            color: _colors.green,
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                      )
                                    : null,
                              ),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                ),
          ],
        ),
      ],
    );
  }

  Widget _agenda() {
    final orders =
        _items('orders')
            .where(
              (o) =>
                  (_agendaDay == null
                      ? (_localDate(o['starts_at'])?.year ==
                                _calendarMonth.year &&
                            _localDate(o['starts_at'])?.month ==
                                _calendarMonth.month)
                      : _sameDay(_localDate(o['starts_at']), _agendaDay)) &&
                  (_agendaStatus == 'all' || o['state'] == _agendaStatus) &&
                  (_agendaService == 'all' ||
                      o['service_id'] == _agendaService),
            )
            .toList()
          ..sort(
            (a, b) => _agendaAscending
                ? a['starts_at'].toString().compareTo(b['starts_at'].toString())
                : b['starts_at'].toString().compareTo(
                    a['starts_at'].toString(),
                  ),
          );
    return Container(
      key: _agendaAnchor,
      child: _Panel(
        title: 'Sua agenda',
        subtitle: 'Organize os serviços e acompanhe o que vem a seguir.',
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_message == 'Atendimento agendado') ...[
              _noticeCard(),
              const SizedBox(height: 12),
            ],
            _calendar(),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    key: ValueKey('agenda-status-$_agendaStatus'),
                    initialValue: _agendaStatus,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Situação',
                      isDense: true,
                    ),
                    items: const [
                      DropdownMenuItem(value: 'all', child: Text('Todas')),
                      DropdownMenuItem(
                        value: 'reserved',
                        child: Text('Agendados'),
                      ),
                      DropdownMenuItem(
                        value: 'completed',
                        child: Text('Concluídos'),
                      ),
                      DropdownMenuItem(
                        value: 'cancelled',
                        child: Text('Cancelados'),
                      ),
                    ],
                    onChanged: (value) =>
                        setState(() => _agendaStatus = value ?? 'all'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    key: ValueKey('agenda-service-$_agendaService'),
                    initialValue: _agendaService,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'Serviço',
                      isDense: true,
                    ),
                    items: [
                      const DropdownMenuItem(
                        value: 'all',
                        child: Text('Todos'),
                      ),
                      for (final service in _items('services'))
                        DropdownMenuItem(
                          value: service['id'].toString(),
                          child: Text(
                            service['label'].toString(),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                    ],
                    onChanged: (value) =>
                        setState(() => _agendaService = value ?? 'all'),
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Expanded(
                  child: Text(
                    _agendaDay == null
                        ? '${orders.length} serviço(s) · neste mês'
                        : '${orders.length} serviço(s) · ${_day(_agendaDay!)}',
                    style: TextStyle(fontSize: 12, color: _colors.textMuted),
                  ),
                ),
                if (_agendaDay != null ||
                    _agendaStatus != 'all' ||
                    _agendaService != 'all')
                  TextButton(
                    key: const Key('clear-agenda-filters'),
                    onPressed: () => setState(() {
                      _agendaDay = null;
                      _agendaStatus = 'all';
                      _agendaService = 'all';
                    }),
                    child: const Text('Limpar'),
                  ),
                IconButton(
                  key: const Key('agenda-sort'),
                  tooltip: _agendaAscending
                      ? 'Mais recentes primeiro'
                      : 'Mais antigos primeiro',
                  onPressed: () =>
                      setState(() => _agendaAscending = !_agendaAscending),
                  icon: Icon(
                    _agendaAscending
                        ? Icons.arrow_downward
                        : Icons.arrow_upward,
                    size: 20,
                  ),
                ),
              ],
            ),
            if (orders.isEmpty)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 12),
                child: Text('Nenhum serviço neste filtro.'),
              ),
            for (final order in orders) _orderCard(order),
          ],
        ),
      ),
    );
  }

  Widget _orderCard(Map<String, dynamic> order) {
    final active = order['state'] == 'reserved';
    final highlighted = order['request_id'] == _highlightedId;
    return Container(
      key: ValueKey('order-${order['request_id']}'),
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: highlighted ? _colors.greenSoft : _colors.bgSoft,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: highlighted ? _colors.green : _colors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Wrap(
            spacing: 8,
            runSpacing: 6,
            crossAxisAlignment: WrapCrossAlignment.center,
            children: [
              Text(
                _client(order['client_id']),
                style: const TextStyle(fontWeight: FontWeight.bold),
              ),
              _Pill(
                _orderStatus(order['state']),
                color: active ? _actionColor : _colors.textMuted,
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            _when(order['starts_at']),
            style: const TextStyle(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 4),
          Text(_service(order['service_id'])),
          Text(
            _money(_amount(order)),
            style: TextStyle(color: _colors.textMuted),
          ),
          if (active) ...[
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: [
                FilledButton.tonal(
                  onPressed: _busy
                      ? null
                      : () => _run(() => _transition(order, 'complete')),
                  child: const Text('Concluir'),
                ),
                TextButton(
                  onPressed: _busy
                      ? null
                      : () => _run(() => _transition(order, 'cancel')),
                  child: const Text('Cancelar'),
                ),
              ],
            ),
          ],
        ],
      ),
    );
  }

  Widget _materials() => _Panel(
    title: 'Materiais',
    child: _items('stock').isEmpty
        ? const Text('Nenhum material cadastrado.')
        : Column(
            children: [
              for (final item in _items('stock'))
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 5),
                  child: _Detail(
                    item['sku'] == 'kit'
                        ? 'Kits de atendimento'
                        : item['sku'].toString(),
                    item['available'].toString() +
                        (_integer(item['available']) == 1
                            ? ' disponível · '
                            : ' disponíveis · ') +
                        item['reserved'].toString() +
                        (_integer(item['reserved']) == 1
                            ? ' reservado'
                            : ' reservados'),
                  ),
                ),
            ],
          ),
  );

  Widget _wallet() {
    final pending = _items(
      'receivables',
    ).where((r) => r['state'] == 'pending').toList();
    final total = pending.fold<int>(
      0,
      (sum, r) => sum + (_integer(r['amount_cents']) ?? 0),
    );
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _Panel(
          title: 'Total a receber',
          subtitle:
              '${pending.length} ${pending.length == 1 ? 'valor pendente' : 'valores pendentes'}',
          child: Text(
            _money(total),
            style: TextStyle(
              fontSize: 32,
              fontWeight: FontWeight.w700,
              color: _actionColor,
            ),
          ),
        ),
        const SizedBox(height: 16),
        _receivables(),
      ],
    );
  }

  Widget _receivables() {
    final pending = _items(
      'receivables',
    ).where((r) => r['state'] == 'pending').toList();
    return _Panel(
      title: 'Valores a receber',
      subtitle: 'Valores anotados dos seus atendimentos.',
      child: pending.isEmpty
          ? const Text('Nenhum valor a receber.')
          : Column(
              children: [
                for (final bill in pending)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 6),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _client(
                                  _lookup(
                                    'orders',
                                    'request_id',
                                    bill['request_id'],
                                  )['client_id'],
                                ),
                                style: const TextStyle(
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                              Text(
                                _when(
                                  _lookup(
                                    'orders',
                                    'request_id',
                                    bill['request_id'],
                                  )['starts_at'],
                                ),
                                style: TextStyle(
                                  fontSize: 12,
                                  color: _colors.textMuted,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(_money(_integer(bill['amount_cents']))),
                      ],
                    ),
                  ),
              ],
            ),
    );
  }

  Widget _noticeCard() => Container(
    key: const Key('remote-feedback'),
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: _isError ? _colors.redSoft : _colors.greenSoft,
      borderRadius: BorderRadius.circular(12),
    ),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(
          _isError ? Icons.info_outline : Icons.check_circle_outline,
          color: _isError ? _colors.red : _actionColor,
          size: 22,
        ),
        const SizedBox(width: 10),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                _message ?? '',
                style: const TextStyle(fontWeight: FontWeight.w600),
              ),
              if (_detail != null &&
                  !(_message == 'Atendimento agendado' &&
                      _items('orders').any(
                        (order) => order['request_id'] == _highlightedId,
                      ))) ...[
                const SizedBox(height: 4),
                Text(_detail!),
              ],
            ],
          ),
        ),
      ],
    ),
  );

  Future<void> _tools() async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (sheet) => Padding(
        padding: EdgeInsets.fromLTRB(
          24,
          8,
          24,
          MediaQuery.of(sheet).viewInsets.bottom + 24,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                'Ferramentas de teste',
                style: Theme.of(sheet).textTheme.titleLarge,
              ),
              const SizedBox(height: 8),
              const Text(
                'Opções técnicas do experimento. O fluxo normal usa o pedido e o cartão de revisão.',
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _structured,
                minLines: 4,
                maxLines: 8,
                decoration: const InputDecoration(
                  labelText: 'Proposta estruturada (JSON)',
                ),
              ),
              const SizedBox(height: 12),
              FilledButton(
                onPressed: _busy
                    ? null
                    : () {
                        final text = _structured.text;
                        Navigator.pop(sheet);
                        _run(() async {
                          _clearProposal();
                          final proposal = Map<String, dynamic>.from(
                            jsonDecode(text) as Map,
                          );
                          final result = await _api.call('/review', {
                            'proposal': proposal,
                          });
                          if (mounted) _acceptReview(proposal, result);
                        });
                      },
                child: const Text('Revisar proposta de teste'),
              ),
              if (_diagnostics != null)
                ExpansionTile(
                  title: const Text('Detalhes da última geração'),
                  children: [
                    SelectableText(
                      const JsonEncoder.withIndent('  ').convert(_diagnostics),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }
}

int? _integer(dynamic value) =>
    value is num ? value.toInt() : int.tryParse(value?.toString() ?? '');
String _money(int? cents) {
  if (cents == null) return 'Valor a confirmar';
  final pieces = (cents / 100).toStringAsFixed(2).split('.');
  final whole = pieces[0].replaceAllMapped(
    RegExp(r'(\d)(?=(\d{3})+(?!\d))'),
    (m) => m[1]! + '.',
  );
  return r'R$ ' + whole + ',' + pieces[1];
}

String _day(DateTime date) =>
    date.day.toString().padLeft(2, '0') +
    '/' +
    date.month.toString().padLeft(2, '0') +
    '/' +
    date.year.toString();
String _when(dynamic value) {
  final parsed = DateTime.tryParse(value?.toString() ?? '');
  if (parsed == null) return 'Horário a confirmar';
  final date = parsed.toUtc().subtract(const Duration(hours: 3));
  return _day(date) +
      ' às ' +
      date.hour.toString().padLeft(2, '0') +
      ':' +
      date.minute.toString().padLeft(2, '0');
}

String _orderStatus(dynamic status) {
  switch (status) {
    case 'reserved':
      return 'Agendado';
    case 'completed':
      return 'Concluído';
    case 'cancelled':
      return 'Cancelado';
    default:
      return 'Em acompanhamento';
  }
}

String _friendlyError(Object error) {
  final text = error.toString();
  if (text.contains('401') || text.contains('session_expired')) {
    return 'Sua sessão expirou ou foi recusada. Entre novamente para continuar.';
  }
  if (text.contains('invalid_credentials') || text.contains('400')) {
    return 'Confira o e-mail e a senha. Se estava preparando um pedido, revise os dados informados.';
  }
  if (text.contains('budget_limit') || text.contains('429')) {
    return 'O limite de uso deste teste foi atingido. Aguarde ou confira o orçamento antes de tentar novamente.';
  }
  if (text.contains('ai_not_configured'))
    return 'A IA ainda não está configurada neste ambiente.';
  return 'Não conseguimos acessar o serviço agora. Verifique a conexão e use Atualizar para tentar novamente.';
}

BicoTokens _palette(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark
    ? BicoTokens.dark
    : BicoTokens.light;

class _Panel extends StatelessWidget {
  final String title;
  final String? subtitle;
  final Widget child;
  const _Panel({required this.title, this.subtitle, required this.child});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: _palette(context).bg,
      borderRadius: BorderRadius.circular(14),
      border: Border.all(color: _palette(context).border),
      boxShadow: const [
        BoxShadow(
          color: Color(0x05000000),
          blurRadius: 12,
          offset: Offset(0, 4),
        ),
      ],
    ),
    child: Material(
      type: MaterialType.transparency,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            title,
            style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
          ),
          if (subtitle != null) ...[
            const SizedBox(height: 6),
            Text(
              subtitle!,
              style: TextStyle(
                color: _palette(context).textMuted,
                fontSize: 13,
              ),
            ),
          ],
          const SizedBox(height: 12),
          child,
        ],
      ),
    ),
  );
}

class _Metric extends StatelessWidget {
  final String title, value;
  final IconData icon;
  final double width;
  const _Metric(this.title, this.value, this.icon, {required this.width});
  @override
  Widget build(BuildContext context) => Container(
    width: width,
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      color: _palette(context).bg,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: _palette(context).border),
    ),
    child: Row(
      children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 12,
                  color: _palette(context).textMuted,
                ),
              ),
              const SizedBox(height: 3),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

class _Pill extends StatelessWidget {
  final String text;
  final Color color;
  const _Pill(this.text, {required this.color});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
    decoration: BoxDecoration(
      color: color.withValues(alpha: .09),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Text(
      text,
      style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.w600),
    ),
  );
}

class _Detail extends StatelessWidget {
  final String label, value;
  const _Detail(this.label, this.value);
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 5),
    child: Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(
          flex: 2,
          child: Text(
            label,
            style: TextStyle(color: _palette(context).textMuted, fontSize: 13),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          flex: 3,
          child: Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.w500),
          ),
        ),
      ],
    ),
  );
}
