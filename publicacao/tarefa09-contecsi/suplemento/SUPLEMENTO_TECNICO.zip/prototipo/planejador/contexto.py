"""Seleção lexical do catálogo autenticado, sem acesso a resultados esperados."""
from copy import deepcopy
import re
import unicodedata

CONTEXT_SELECTOR_VERSION = 'lexical-overlap-ties-v1'
STOP = {'de', 'da', 'do', 'das', 'dos', 'a', 'o', 'e', 'em', 'para'}


def _tokens(value):
    normalized = ''.join(c for c in unicodedata.normalize('NFKD', value.casefold())
                         if not unicodedata.combining(c))
    return set(re.findall(r'[a-z0-9]+', normalized)) - STOP


def select_context(context, request):
    """Conserva todos os máximos empatados; sem correspondência, conserva a categoria."""
    result = deepcopy(context)
    query = _tokens(request)
    for kind in ('clients', 'services'):
        entries = context[kind]
        scores = [len(_tokens(item['name']) & query) for item in entries]
        maximum = max(scores, default=0)
        if maximum:
            result[kind] = [deepcopy(item) for item, score in zip(entries, scores)
                            if score == maximum]
    return result
