import 'dart:convert';
import 'dart:io';
import '../lib/services/process_orchestrator.dart';

// Testes de contrato com propostas sintéticas; NÃO são inferências de um LLM.
void main(List<String> args) {
  final out = Directory(args.isEmpty ? '../../experimentos/resultados_locais' : args.first);
  out.createSync(recursive: true);
  final raw = <Map<String, dynamic>>[];
  final now = DateTime.utc(2026, 11, 3, 12);
  Map<String, dynamic> base() => {'request_id':'r1','tenant_id':'t1','client_id':'c1',
    'service_id':'s1','start':'2026-11-04T14:00:00-03:00','duration_minutes':60};
  final cases = <String, Map<String, dynamic>>{
    'valid': base(), 'unknown_client': {...base(), 'client_id':'missing'},
    'cross_tenant_client': {...base(), 'client_id':'c2'},
    'unknown_service': {...base(), 'service_id':'missing'},
    'cross_tenant_service': {...base(), 'service_id':'s2'},
    'cross_tenant_plan': {...base(), 'tenant_id':'t2'},
    'past': {...base(), 'start':'2026-11-01T14:00:00Z'},
    'zero_duration': {...base(), 'duration_minutes':0},
    'long_duration': {...base(), 'duration_minutes':481},
    'string_duration': {...base(), 'duration_minutes':'60'},
    'missing_timezone': {...base(), 'start':'2026-11-04T14:00:00'},
    'invalid_date': {...base(), 'start':'2026-11-31T14:00:00Z'},
    'unexpected_action': {...base(), 'execute':'delete_all'},
    'missing_field': {...base()}..remove('client_id'),
    'empty_id': {...base(), 'request_id':''},
    'no_confirmation': base(), 'conflict': base(),
    'adjacent': {...base(), 'start':'2026-11-04T15:00:00-03:00'},
    'duplicate': base(), 'changed_replay': {...base(), 'duration_minutes':30},
  };
  const expected = {'valid':'committed', 'unknown_client':'invalid_reference',
    'cross_tenant_client':'invalid_reference','unknown_service':'invalid_reference',
    'cross_tenant_service':'invalid_reference','cross_tenant_plan':'invalid_reference',
    'past':'invalid_schedule','zero_duration':'invalid_schedule','long_duration':'invalid_schedule',
    'string_duration':'parse_error','missing_timezone':'parse_error','invalid_date':'parse_error',
    'unexpected_action':'parse_error','missing_field':'parse_error','empty_id':'parse_error',
    'no_confirmation':'awaiting_confirmation','conflict':'conflict','adjacent':'committed',
    'duplicate':'duplicate','changed_replay':'idempotency_mismatch'};
  for (final entry in cases.entries) {
    final engine = ProcessOrchestrator(tenantId:'t1', clientOwners:{'c1':'t1','c2':'t2'},
      serviceOwners:{'s1':'t1','s2':'t2'});
    if (['conflict','adjacent'].contains(entry.key)) {
      engine.submit(AppointmentProposal.fromJson({...base(),'request_id':'existing'}),approved:true,now:now);
    }
    if (['duplicate','changed_replay'].contains(entry.key)) {
      engine.submit(AppointmentProposal.fromJson(base()),approved:true,now:now);
    }
    final before = engine.appointments.length;
    final watch = Stopwatch()..start();
    String actual;
    try {
      actual = engine.submit(AppointmentProposal.fromJson(entry.value),
        approved:entry.key!='no_confirmation',now:now);
    } on FormatException { actual = 'parse_error'; }
    watch.stop();
    final expectedDelta = expected[entry.key]=='committed' ? 1 : 0;
    final pass = actual==expected[entry.key] && engine.appointments.length-before==expectedDelta;
    raw.add({'case_id':entry.key,'mode':'synthetic_contract','expected':expected[entry.key],
      'actual':actual,'passed':pass,'elapsed_us':watch.elapsedMicroseconds,
      'before':before,'after':engine.appointments.length,'input':entry.value,'audit':engine.audit});
  }
  final passed = raw.where((r)=>r['passed']==true).length;
  File('${out.path}/contratos.jsonl').writeAsStringSync(raw.map(jsonEncode).join('\n')+'\n');
  final summary={'mode':'synthetic_contract','cases':raw.length,'passed':passed,
    'pass_rate':passed/raw.length,'llm_calls':0,'ui_tests':0,'database_tests':0,
    'warning':'Resultados locais do núcleo isolado. Não medem qualidade de IA, usabilidade ou ganho em negócios.'};
  File('${out.path}/resumo.json').writeAsStringSync(const JsonEncoder.withIndent('  ').convert(summary));
  stdout.writeln(jsonEncode(summary));
  if(passed!=raw.length) exitCode=1;
}
