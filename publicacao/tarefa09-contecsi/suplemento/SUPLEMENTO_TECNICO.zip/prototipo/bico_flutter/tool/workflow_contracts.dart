import 'dart:convert';
import 'dart:io';
import '../lib/services/process_orchestrator.dart';
import '../lib/services/service_workflow.dart';

final now = DateTime.utc(2026, 11, 3);
AppointmentProposal proposal({String id = 'r1', String tenant = 'demo', int hour = 10}) =>
  AppointmentProposal(requestId: id, tenantId: tenant, clientId: 'c1', serviceId: 's1',
    start: DateTime.utc(2026, 11, 10, hour), durationMinutes: 60);
ServiceWorkflow workflow({int stock = 3}) => ServiceWorkflow(
  agenda: ProcessOrchestrator(tenantId: 'demo', clientOwners: {'c1': 'demo'}, serviceOwners: {'s1': 'demo'}),
  onHand: {'kit': stock}, recipes: {'s1': {'kit': 1}}, pricesCents: {'s1': 5000});
void check(bool ok) { if (!ok) throw StateError('Contrato violado'); }
void main() {
  final cases = <String, void Function()>{
    'revisao_sem_efeitos': () {
      final w=workflow();check(w.submit(proposal(),approved:false,now:now)=='awaiting_confirmation');
      check(w.available('kit')==3 && w.receivableCents==0 && w.draftCount==0 && w.agenda.appointments.isEmpty);
    },
    'confirmacao_coordena_quatro_modulos': () {
      final w=workflow();check(w.submit(proposal(),approved:true,now:now)=='committed');
      check(w.available('kit')==2 && w.receivableCents==5000 && w.draftCount==1 && w.agenda.appointments.length==1);
    },
    'replay_nao_duplica_reserva_ou_titulo': () {
      final w=workflow();w.submit(proposal(),approved:true,now:now);
      check(w.submit(proposal(),approved:true,now:now)=='duplicate');
      check(w.available('kit')==2 && w.receivableCents==5000 && w.draftCount==1);
    },
    'replay_com_dados_alterados': () {
      final w=workflow();w.submit(proposal(),approved:true,now:now);
      check(w.submit(proposal(hour:12),approved:true,now:now)=='idempotency_mismatch');
      check(w.available('kit')==2 && w.agenda.appointments.single.start.hour==10);
    },
    'estoque_insuficiente_nao_grava_agenda': () {
      final w=workflow(stock:0);check(w.submit(proposal(),approved:true,now:now)=='insufficient_stock');
      check(w.agenda.appointments.isEmpty && w.receivableCents==0 && w.draftCount==0);
    },
    'tenant_alheio_sem_efeitos': () {
      final w=workflow();check(w.submit(proposal(tenant:'outro'),approved:true,now:now)=='invalid_reference');
      check(w.available('kit')==3 && w.receivableCents==0);
    },
    'conflito_nao_reserva_material': () {
      final w=workflow();w.submit(proposal(),approved:true,now:now);
      check(w.submit(proposal(id:'r2'),approved:true,now:now)=='conflict');
      check(w.available('kit')==2 && w.receivableCents==5000);
    },
    'cancelamento_requer_confirmacao': () {
      final w=workflow();w.submit(proposal(),approved:true,now:now);
      check(w.cancel('r1',approved:false,now:now)=='awaiting_confirmation');
      check(w.available('kit')==2 && w.receivableCents==5000);
    },
    'cancelamento_libera_reserva_e_anula_titulo': () {
      final w=workflow();w.submit(proposal(),approved:true,now:now);
      check(w.cancel('r1',approved:true,now:now)=='cancelled');
      check(w.available('kit')==3 && w.receivableCents==0 && w.draftCount==0 && w.agenda.appointments.isEmpty);
      check(w.cancel('r1',approved:true,now:now)=='duplicate' && w.available('kit')==3);
    },
    'cancelamento_nao_ressuscita_por_replay': () {
      final w=workflow();w.submit(proposal(),approved:true,now:now);w.cancel('r1',approved:true,now:now);
      check(w.submit(proposal(),approved:true,now:now)=='cancelled' && w.available('kit')==3);
      check(w.submit(proposal(id:'r2'),approved:true,now:now)=='committed');
    },
    'conclusao_consumo_unico': () {
      final w=workflow();w.submit(proposal(),approved:true,now:now);
      check(w.complete('r1',approved:true)=='completed');
      check(w.complete('r1',approved:true)=='duplicate');
      check(w.available('kit')==2 && w.receivableCents==5000);
      check(w.cancel('r1',approved:true,now:now)=='invalid_transition');
    },
    'conclusao_requer_confirmacao': () {
      final w=workflow();w.submit(proposal(),approved:true,now:now);
      check(w.complete('r1',approved:false)=='awaiting_confirmation' && w.state('r1')=='reserved');
    },
    'cancelado_nao_pode_ser_concluido': () {
      final w=workflow();w.submit(proposal(),approved:true,now:now);w.cancel('r1',approved:true,now:now);
      check(w.complete('r1',approved:true)=='invalid_transition' && w.available('kit')==3);
    },
    'comandos_para_id_inexistente': () {
      final w=workflow();check(w.complete('ausente',approved:true)=='not_found');
      check(w.cancel('ausente',approved:true,now:now)=='not_found');
    },
  };
  var failed=0;
  for(final e in cases.entries) {
    try {e.value();stdout.writeln(jsonEncode({'case':e.key,'passed':true}));}
    catch(error) {failed++;stdout.writeln(jsonEncode({'case':e.key,'passed':false,'error':error.toString()}));}
  }
  stdout.writeln(jsonEncode({'summary':true,'total':cases.length,'passed':cases.length-failed,'failed':failed,
    'scope':'Dart, dados sintéticos, memória, sem rede ou IA'}));
  exitCode=failed==0?0:1;
}
