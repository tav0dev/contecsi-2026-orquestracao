-- PREPARADO, AINDA NÃO EXECUTADO. Rodar em Supabase LOCAL descartável após migrations.
-- Todos os fixtures e operações são revertidos; não rodar na base compartilhada.
BEGIN;
INSERT INTO auth.users(id) VALUES('b1c00000-0000-4000-8000-000000000001'),('b1c00000-0000-4000-8000-000000000002');
SET LOCAL ROLE authenticated;
SELECT set_config('request.jwt.claim.sub','b1c00000-0000-4000-8000-000000000001',true);
SELECT set_config('request.jwt.claims','{"sub":"b1c00000-0000-4000-8000-000000000001","role":"authenticated"}',true);
DO $test$
DECLARE initial jsonb; other jsonb; tid uuid; proposal jsonb; result jsonb; starts timestamptz:=now()+interval '2 days';
BEGIN
  initial:=public.bico_exp_setup();tid:=(initial->>'tenant_id')::uuid;
  IF public.bico_exp_setup()->>'tenant_id'<>tid::text THEN RAISE EXCEPTION 'setup not idempotent'; END IF;
  proposal:=jsonb_build_object('request_id','sql-r1','tenant_id',tid,'client_id','cliente-demo',
    'service_id','servico-demo','start',to_char(starts AT TIME ZONE 'UTC','YYYY-MM-DD"T"HH24:MI:SS"Z"'),'duration_minutes',60);
  result:=public.bico_exp_submit(proposal,false);
  IF result->>'status'<>'awaiting_confirmation' THEN RAISE EXCEPTION 'review rejected'; END IF;
  IF jsonb_array_length(public.bico_exp_state(tid)->'orders')<>0 THEN RAISE EXCEPTION 'review inserted order'; END IF;
  result:=public.bico_exp_submit(proposal,true);
  IF result->>'status'<>'committed' THEN RAISE EXCEPTION 'commit rejected'; END IF;
  IF (public.bico_exp_state(tid)->'stock'->0->>'available')::int<>2 THEN RAISE EXCEPTION 'stock not reserved'; END IF;
  IF (public.bico_exp_state(tid)->'receivables'->0->>'amount_cents')::int<>5000 THEN RAISE EXCEPTION 'wrong receivable'; END IF;
  IF public.bico_exp_submit(proposal,true)->>'status'<>'duplicate' THEN RAISE EXCEPTION 'replay duplicated'; END IF;
  IF public.bico_exp_submit(proposal||'{"duration_minutes":30}'::jsonb,true)->>'status'<>'idempotency_mismatch'
    THEN RAISE EXCEPTION 'changed replay accepted'; END IF;
  IF public.bico_exp_submit(proposal||'{"request_id":"conflict"}'::jsonb,true)->>'status'<>'conflict'
    THEN RAISE EXCEPTION 'schedule conflict accepted'; END IF;
  IF public.bico_exp_transition(tid,'sql-r1','cancel',true)->>'status'<>'cancelled' THEN RAISE EXCEPTION 'cancel rejected'; END IF;
  IF (public.bico_exp_state(tid)->'stock'->0->>'available')::int<>3 THEN RAISE EXCEPTION 'stock not released'; END IF;
  IF public.bico_exp_state(tid)->'receivables'->0->>'state'<>'void' THEN RAISE EXCEPTION 'bill not void'; END IF;
  IF public.bico_exp_submit(proposal,true)->>'status'<>'cancelled' THEN RAISE EXCEPTION 'replay resurrected order'; END IF;
  proposal:=proposal||'{"request_id":"sql-r2"}'::jsonb;
  PERFORM public.bico_exp_submit(proposal,true);
  IF public.bico_exp_transition(tid,'sql-r2','complete',true)->>'status'<>'completed' THEN RAISE EXCEPTION 'completion rejected'; END IF;
  IF public.bico_exp_transition(tid,'sql-r2','complete',true)->>'status'<>'duplicate' THEN RAISE EXCEPTION 'completion duplicated'; END IF;
  IF (public.bico_exp_state(tid)->'stock'->0->>'on_hand')::int<>2 THEN RAISE EXCEPTION 'incorrect consumption'; END IF;
  IF public.bico_exp_transition(tid,'sql-r2','cancel',true)->>'status'<>'invalid_transition' THEN RAISE EXCEPTION 'completed order cancelled'; END IF;
  -- Segundo usuário não lê nem altera dados do primeiro.
  PERFORM set_config('request.jwt.claim.sub','b1c00000-0000-4000-8000-000000000002',true);
  PERFORM set_config('request.jwt.claims','{"sub":"b1c00000-0000-4000-8000-000000000002","role":"authenticated"}',true);
  other:=public.bico_exp_setup();
  IF other->>'tenant_id'=tid::text THEN RAISE EXCEPTION 'shared tenant'; END IF;
  IF EXISTS(SELECT 1 FROM bico_exp.orders WHERE tenant_id=tid) THEN RAISE EXCEPTION 'RLS leak'; END IF;
  BEGIN
    PERFORM public.bico_exp_submit(proposal,true);
    RAISE EXCEPTION 'expected invalid_tenant';
  EXCEPTION WHEN raise_exception THEN
    IF SQLERRM<>'invalid_tenant' THEN RAISE; END IF;
  END;
  RAISE NOTICE 'workflow assertions completed; transaction will roll back';
END;
$test$;
ROLLBACK;
