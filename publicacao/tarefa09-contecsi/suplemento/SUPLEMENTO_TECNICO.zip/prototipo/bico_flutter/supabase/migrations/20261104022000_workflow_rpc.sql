-- NÃO APLICADA. Requer a fundação bico_exp; validar em PostgreSQL antes do deploy.
-- Apenas RPCs explícitas no schema público. bico_exp permanece não exposto.
BEGIN;

CREATE FUNCTION public.bico_exp_state(p_tenant uuid DEFAULT NULL) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE t bico_exp.tenants;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'unauthorized'; END IF;
  SELECT * INTO t FROM bico_exp.tenants WHERE owner_id=auth.uid()
    AND (p_tenant IS NULL OR id=p_tenant) ORDER BY created_at,id LIMIT 1;
  IF NOT FOUND THEN
    IF p_tenant IS NOT NULL THEN RAISE EXCEPTION 'invalid_tenant'; END IF;
    RETURN jsonb_build_object('needs_setup',true);
  END IF;
  RETURN jsonb_build_object('tenant_id',t.id,'owner_id',t.owner_id,'name',t.name,
    'clients',COALESCE((SELECT jsonb_agg(to_jsonb(c)) FROM bico_exp.clients c WHERE c.tenant_id=t.id),'[]'::jsonb),
    'services',COALESCE((SELECT jsonb_agg(to_jsonb(s)) FROM bico_exp.services s WHERE s.tenant_id=t.id),'[]'::jsonb),
    'stock',COALESCE((SELECT jsonb_agg(to_jsonb(s)||jsonb_build_object('available',s.on_hand-s.reserved))
      FROM bico_exp.stock s WHERE s.tenant_id=t.id),'[]'::jsonb),
    'orders',COALESCE((SELECT jsonb_agg(to_jsonb(o) ORDER BY o.starts_at) FROM bico_exp.orders o WHERE o.tenant_id=t.id),'[]'::jsonb),
    'receivables',COALESCE((SELECT jsonb_agg(to_jsonb(r)) FROM bico_exp.receivables r WHERE r.tenant_id=t.id),'[]'::jsonb));
END;
$fn$;

CREATE FUNCTION public.bico_exp_setup() RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE tid uuid;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'unauthorized'; END IF;
  PERFORM pg_advisory_xact_lock(hashtextextended(auth.uid()::text,0));
  SELECT id INTO tid FROM bico_exp.tenants WHERE owner_id=auth.uid() ORDER BY created_at,id LIMIT 1;
  IF FOUND THEN RETURN public.bico_exp_state(tid); END IF;
  INSERT INTO bico_exp.tenants(owner_id,name) VALUES(auth.uid(),'Bico — negócio sintético') RETURNING id INTO tid;
  INSERT INTO bico_exp.clients VALUES(tid,'cliente-demo','Cliente sintético');
  INSERT INTO bico_exp.services VALUES(tid,'servico-demo','Atendimento demonstrativo',5000,60);
  INSERT INTO bico_exp.stock VALUES(tid,'kit',3,0);
  INSERT INTO bico_exp.recipes VALUES(tid,'servico-demo','kit',1);
  INSERT INTO bico_exp.audit(tenant_id,event) VALUES(tid,'synthetic_setup');
  RETURN public.bico_exp_state(tid);
END;
$fn$;

CREATE FUNCTION public.bico_exp_submit(p_proposal jsonb,p_approved boolean DEFAULT false) RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE tid uuid; rid text; cid text; sid text; begins timestamptz; minutes integer;
  prior bico_exp.orders; service bico_exp.services; item record; status text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'unauthorized'; END IF;
  IF jsonb_typeof(p_proposal) IS DISTINCT FROM 'object' THEN RAISE EXCEPTION 'invalid_proposal'; END IF;
  IF NOT (p_proposal ?& ARRAY['request_id','tenant_id','client_id','service_id','start','duration_minutes'])
    OR (SELECT count(*) FROM jsonb_object_keys(p_proposal))<>6 THEN RAISE EXCEPTION 'invalid_fields'; END IF;
  IF jsonb_typeof(p_proposal->'request_id') IS DISTINCT FROM 'string'
    OR jsonb_typeof(p_proposal->'tenant_id') IS DISTINCT FROM 'string'
    OR jsonb_typeof(p_proposal->'client_id') IS DISTINCT FROM 'string'
    OR jsonb_typeof(p_proposal->'service_id') IS DISTINCT FROM 'string'
    OR jsonb_typeof(p_proposal->'start') IS DISTINCT FROM 'string'
    OR jsonb_typeof(p_proposal->'duration_minutes') IS DISTINCT FROM 'number'
    OR (p_proposal->>'duration_minutes') !~ '^[0-9]{1,3}$'
    OR (p_proposal->>'start') !~ '(Z|[+-][0-9]{2}:[0-9]{2})$'
    THEN RAISE EXCEPTION 'invalid_types_or_timezone'; END IF;
  tid:=(p_proposal->>'tenant_id')::uuid; rid:=p_proposal->>'request_id';
  cid:=p_proposal->>'client_id'; sid:=p_proposal->>'service_id';
  begins:=(p_proposal->>'start')::timestamptz; minutes:=(p_proposal->>'duration_minutes')::integer;
  IF length(trim(rid)) NOT BETWEEN 1 AND 128 THEN RAISE EXCEPTION 'invalid_request_id'; END IF;
  -- Serializa todas as mutações do negócio; evita disputa de horário e estoque.
  PERFORM 1 FROM bico_exp.tenants WHERE id=tid AND owner_id=auth.uid() FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'invalid_tenant'; END IF;
  SELECT * INTO prior FROM bico_exp.orders WHERE tenant_id=tid AND request_id=rid;
  IF FOUND THEN
    status:=CASE WHEN prior.proposal<>p_proposal THEN 'idempotency_mismatch'
      WHEN prior.state='cancelled' THEN 'cancelled' ELSE 'duplicate' END;
    RETURN jsonb_build_object('status',status,'request_id',rid);
  END IF;
  IF NOT EXISTS(SELECT 1 FROM bico_exp.clients WHERE tenant_id=tid AND id=cid)
    THEN RAISE EXCEPTION 'invalid_client'; END IF;
  SELECT * INTO service FROM bico_exp.services WHERE tenant_id=tid AND id=sid;
  IF NOT FOUND THEN RAISE EXCEPTION 'invalid_service'; END IF;
  IF NOT isfinite(begins) OR begins<=now() OR minutes<>service.duration_minutes
    THEN RAISE EXCEPTION 'invalid_schedule'; END IF;
  IF EXISTS(SELECT 1 FROM bico_exp.orders o WHERE o.tenant_id=tid AND o.state<>'cancelled'
    AND begins<o.starts_at+make_interval(mins=>o.duration_minutes)
    AND begins+make_interval(mins=>minutes)>o.starts_at)
    THEN RETURN jsonb_build_object('status','conflict'); END IF;
  IF EXISTS(SELECT 1 FROM bico_exp.recipes r JOIN bico_exp.stock s
    ON s.tenant_id=r.tenant_id AND s.sku=r.sku
    WHERE r.tenant_id=tid AND r.service_id=sid AND s.on_hand-s.reserved<r.quantity)
    THEN RETURN jsonb_build_object('status','insufficient_stock'); END IF;
  IF p_approved IS DISTINCT FROM true THEN
    RETURN jsonb_build_object('status','awaiting_confirmation','amount_cents',service.price_cents);
  END IF;
  INSERT INTO bico_exp.orders(tenant_id,request_id,client_id,service_id,starts_at,duration_minutes,proposal,state,approved_by)
    VALUES(tid,rid,cid,sid,begins,minutes,p_proposal,'reserved',auth.uid());
  FOR item IN SELECT * FROM bico_exp.recipes WHERE tenant_id=tid AND service_id=sid LOOP
    UPDATE bico_exp.stock SET reserved=reserved+item.quantity WHERE tenant_id=tid AND sku=item.sku;
    INSERT INTO bico_exp.reservations VALUES(tid,rid,item.sku,item.quantity,'reserved');
  END LOOP;
  INSERT INTO bico_exp.receivables(tenant_id,request_id,amount_cents) VALUES(tid,rid,service.price_cents);
  INSERT INTO bico_exp.audit(tenant_id,request_id,event,details)
    VALUES(tid,rid,'committed',jsonb_build_object('approved_by',auth.uid()));
  RETURN jsonb_build_object('status','committed','request_id',rid,'amount_cents',service.price_cents,
    'draft','Confira seu atendimento em '||begins::text||'. Rascunho, sem envio externo.');
END;
$fn$;

CREATE FUNCTION public.bico_exp_transition(p_tenant uuid,p_request_id text,p_action text,p_approved boolean DEFAULT false)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER SET search_path = '' AS $fn$
DECLARE current_order bico_exp.orders; item record; target text;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'unauthorized'; END IF;
  PERFORM 1 FROM bico_exp.tenants WHERE id=p_tenant AND owner_id=auth.uid() FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'invalid_tenant'; END IF;
  IF p_action IS NULL OR p_action NOT IN ('complete','cancel') THEN RAISE EXCEPTION 'invalid_action'; END IF;
  SELECT * INTO current_order FROM bico_exp.orders WHERE tenant_id=p_tenant AND request_id=p_request_id;
  IF NOT FOUND THEN RETURN jsonb_build_object('status','not_found'); END IF;
  target:=CASE WHEN p_action='complete' THEN 'completed' ELSE 'cancelled' END;
  IF current_order.state=target THEN RETURN jsonb_build_object('status','duplicate'); END IF;
  IF current_order.state<>'reserved' THEN RETURN jsonb_build_object('status','invalid_transition'); END IF;
  IF p_approved IS DISTINCT FROM true THEN RETURN jsonb_build_object('status','awaiting_confirmation'); END IF;
  IF p_action='cancel' AND (EXISTS(SELECT 1 FROM bico_exp.receivables r
      WHERE r.tenant_id=p_tenant AND r.request_id=p_request_id AND (r.state<>'pending' OR r.provider_charge_id IS NOT NULL))
    OR EXISTS(SELECT 1 FROM bico_exp.outbox o WHERE o.tenant_id=p_tenant AND o.request_id=p_request_id
      AND o.state IN ('succeeded','reconciliation_required')))
    THEN RETURN jsonb_build_object('status','reconciliation_required'); END IF;
  FOR item IN SELECT * FROM bico_exp.reservations WHERE tenant_id=p_tenant
    AND request_id=p_request_id AND state='reserved' LOOP
    UPDATE bico_exp.stock SET reserved=reserved-item.quantity,
      on_hand=on_hand-CASE WHEN p_action='complete' THEN item.quantity ELSE 0 END
      WHERE tenant_id=p_tenant AND sku=item.sku;
  END LOOP;
  UPDATE bico_exp.reservations SET state=CASE WHEN p_action='complete' THEN 'consumed' ELSE 'released' END
    WHERE tenant_id=p_tenant AND request_id=p_request_id AND state='reserved';
  UPDATE bico_exp.orders SET state=target WHERE tenant_id=p_tenant AND request_id=p_request_id;
  IF p_action='cancel' THEN
    UPDATE bico_exp.receivables SET state='void' WHERE tenant_id=p_tenant AND request_id=p_request_id;
    UPDATE bico_exp.outbox SET state='cancelled' WHERE tenant_id=p_tenant AND request_id=p_request_id AND state='queued';
  END IF;
  INSERT INTO bico_exp.audit(tenant_id,request_id,event) VALUES(p_tenant,p_request_id,target);
  RETURN jsonb_build_object('status',target);
END;
$fn$;

REVOKE ALL ON FUNCTION public.bico_exp_state(uuid) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.bico_exp_setup() FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.bico_exp_submit(jsonb,boolean) FROM PUBLIC,anon;
REVOKE ALL ON FUNCTION public.bico_exp_transition(uuid,text,text,boolean) FROM PUBLIC,anon;
GRANT EXECUTE ON FUNCTION public.bico_exp_state(uuid),public.bico_exp_setup(),
  public.bico_exp_submit(jsonb,boolean),public.bico_exp_transition(uuid,text,text,boolean) TO authenticated;
COMMIT;
