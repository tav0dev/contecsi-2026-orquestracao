-- RASCUNHO NÃO APLICADO. Projeto autorizado: wzychmshebmznjfducug.
-- Fundação isolada: não altera prestadores, clientes, servicos ou agendamentos.
-- Exige revisão da inspeção remota e ensaio PostgreSQL antes de aplicar.
-- Não implementa RPC transacional nem worker; Flutter ainda usa memória.
BEGIN;

-- Sem IF NOT EXISTS: uma colisão de namespace aborta a transação inteira.
CREATE SCHEMA bico_exp;
REVOKE ALL ON SCHEMA bico_exp FROM PUBLIC, anon;
GRANT USAGE ON SCHEMA bico_exp TO authenticated, service_role;

CREATE TABLE bico_exp.tenants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL REFERENCES auth.users(id),
  name text NOT NULL CHECK (length(trim(name)) > 0),
  synthetic_only boolean NOT NULL DEFAULT true CHECK (synthetic_only),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX tenants_owner_idx ON bico_exp.tenants(owner_id);

CREATE TABLE bico_exp.clients (
  tenant_id uuid NOT NULL REFERENCES bico_exp.tenants(id),
  id text NOT NULL,
  label text NOT NULL,
  PRIMARY KEY(tenant_id,id)
);
CREATE TABLE bico_exp.services (
  tenant_id uuid NOT NULL REFERENCES bico_exp.tenants(id),
  id text NOT NULL,
  label text NOT NULL,
  price_cents bigint NOT NULL CHECK(price_cents >= 100),
  duration_minutes integer NOT NULL CHECK(duration_minutes BETWEEN 1 AND 480),
  PRIMARY KEY(tenant_id,id)
);
CREATE TABLE bico_exp.stock (
  tenant_id uuid NOT NULL REFERENCES bico_exp.tenants(id),
  sku text NOT NULL,
  on_hand integer NOT NULL CHECK(on_hand >= 0),
  reserved integer NOT NULL DEFAULT 0 CHECK(reserved >= 0 AND reserved <= on_hand),
  PRIMARY KEY(tenant_id,sku)
);
CREATE TABLE bico_exp.recipes (
  tenant_id uuid NOT NULL,
  service_id text NOT NULL,
  sku text NOT NULL,
  quantity integer NOT NULL CHECK(quantity > 0),
  PRIMARY KEY(tenant_id,service_id,sku),
  FOREIGN KEY(tenant_id,service_id) REFERENCES bico_exp.services(tenant_id,id),
  FOREIGN KEY(tenant_id,sku) REFERENCES bico_exp.stock(tenant_id,sku)
);
CREATE TABLE bico_exp.orders (
  tenant_id uuid NOT NULL REFERENCES bico_exp.tenants(id),
  request_id text NOT NULL,
  client_id text NOT NULL,
  service_id text NOT NULL,
  starts_at timestamptz NOT NULL,
  duration_minutes integer NOT NULL CHECK(duration_minutes BETWEEN 1 AND 480),
  proposal jsonb NOT NULL CHECK(jsonb_typeof(proposal) = 'object'),
  state text NOT NULL CHECK(state IN ('reserved','completed','cancelled')),
  approved_by uuid NOT NULL REFERENCES auth.users(id),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(tenant_id,request_id),
  FOREIGN KEY(tenant_id,client_id) REFERENCES bico_exp.clients(tenant_id,id),
  FOREIGN KEY(tenant_id,service_id) REFERENCES bico_exp.services(tenant_id,id)
);
CREATE INDEX orders_schedule_idx ON bico_exp.orders(tenant_id,starts_at);
CREATE TABLE bico_exp.reservations (
  tenant_id uuid NOT NULL,
  request_id text NOT NULL,
  sku text NOT NULL,
  quantity integer NOT NULL CHECK(quantity > 0),
  state text NOT NULL CHECK(state IN ('reserved','consumed','released')),
  PRIMARY KEY(tenant_id,request_id,sku),
  FOREIGN KEY(tenant_id,request_id) REFERENCES bico_exp.orders(tenant_id,request_id),
  FOREIGN KEY(tenant_id,sku) REFERENCES bico_exp.stock(tenant_id,sku)
);
CREATE TABLE bico_exp.receivables (
  tenant_id uuid NOT NULL,
  request_id text NOT NULL,
  amount_cents bigint NOT NULL CHECK(amount_cents >= 100),
  currency text NOT NULL DEFAULT 'BRL' CHECK(currency = 'BRL'),
  state text NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','paid','void','refund_review')),
  provider_charge_id text UNIQUE,
  PRIMARY KEY(tenant_id,request_id),
  FOREIGN KEY(tenant_id,request_id) REFERENCES bico_exp.orders(tenant_id,request_id)
);
CREATE TABLE bico_exp.outbox (
  tenant_id uuid NOT NULL,
  request_id text NOT NULL,
  operation text NOT NULL CHECK(operation IN ('abacatepay.pix','zernio.draft')),
  payload jsonb NOT NULL CHECK(jsonb_typeof(payload) = 'object'),
  state text NOT NULL DEFAULT 'queued'
    CHECK(state IN ('queued','reconciliation_required','succeeded','cancelled')),
  result jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(tenant_id,request_id,operation),
  FOREIGN KEY(tenant_id,request_id) REFERENCES bico_exp.orders(tenant_id,request_id)
);
CREATE TABLE bico_exp.provider_accounts (
  tenant_id uuid NOT NULL REFERENCES bico_exp.tenants(id),
  provider text NOT NULL CHECK(provider IN ('abacatepay','zernio')),
  external_account_id text NOT NULL,
  channel text NOT NULL,
  PRIMARY KEY(provider,external_account_id),
  UNIQUE(tenant_id,provider,external_account_id)
  -- Tokens ficam em secrets do servidor, nunca nesta tabela ou no Flutter.
);
CREATE TABLE bico_exp.webhook_deliveries (
  provider text NOT NULL CHECK(provider IN ('abacatepay','zernio')),
  event_id text NOT NULL,
  tenant_id uuid NOT NULL,
  external_account_id text NOT NULL,
  payload jsonb NOT NULL,
  body_sha256 text NOT NULL,
  state text NOT NULL DEFAULT 'received' CHECK(state IN ('received','processed','rejected')),
  received_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(provider,event_id),
  FOREIGN KEY(tenant_id,provider,external_account_id)
    REFERENCES bico_exp.provider_accounts(tenant_id,provider,external_account_id)
);
CREATE INDEX webhook_tenant_idx ON bico_exp.webhook_deliveries(tenant_id);
CREATE TABLE bico_exp.audit (
  id bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  tenant_id uuid NOT NULL REFERENCES bico_exp.tenants(id),
  request_id text,
  event text NOT NULL,
  details jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_tenant_idx ON bico_exp.audit(tenant_id,created_at);

ALTER TABLE bico_exp.tenants ENABLE ROW LEVEL SECURITY;
CREATE POLICY owner_reads_tenant ON bico_exp.tenants FOR SELECT TO authenticated
  USING(owner_id = (SELECT auth.uid()));

DO $policies$
DECLARE table_name text;
BEGIN
  FOREACH table_name IN ARRAY ARRAY['clients','services','stock','recipes','orders',
    'reservations','receivables','outbox','provider_accounts','webhook_deliveries','audit']
  LOOP
    EXECUTE format('ALTER TABLE bico_exp.%I ENABLE ROW LEVEL SECURITY',table_name);
    EXECUTE format(
      'CREATE POLICY owner_reads_rows ON bico_exp.%I FOR SELECT TO authenticated
       USING (EXISTS (SELECT 1 FROM bico_exp.tenants t
       WHERE t.id = %I.tenant_id AND t.owner_id = (SELECT auth.uid())))',table_name,table_name);
  END LOOP;
END;
$policies$;

REVOKE ALL ON ALL TABLES IN SCHEMA bico_exp FROM PUBLIC,anon,authenticated;
REVOKE ALL ON ALL SEQUENCES IN SCHEMA bico_exp FROM PUBLIC,anon,authenticated;
GRANT SELECT ON ALL TABLES IN SCHEMA bico_exp TO authenticated;
GRANT ALL ON ALL TABLES IN SCHEMA bico_exp TO service_role;
GRANT USAGE,SELECT ON ALL SEQUENCES IN SCHEMA bico_exp TO service_role;
-- Não adicionar bico_exp aos schemas expostos à Data API nesta etapa.
-- Apenas o backend futuro poderá escrever, através de transações verificadas.
COMMIT;
