import 'process_orchestrator.dart';

/// Transação síncrona do laboratório. Sem I/O: estoque, títulos e rascunhos
/// são projeções em memória, nunca comprovantes de cobrança ou de envio.
class ServiceWorkflow {
  final ProcessOrchestrator agenda;
  final Map<String, int> _onHand, _reserved = {};
  final Map<String, Map<String, int>> recipes;
  final Map<String, int> pricesCents;
  final Map<String, AppointmentProposal> _orders = {};
  final Map<String, String> _states = {};
  final Map<String, int> _receivables = {};
  final Map<String, String> _drafts = {};

  ServiceWorkflow({required this.agenda, required Map<String, int> onHand,
    required Map<String, Map<String, int>> recipes,
    required Map<String, int> pricesCents})
    : _onHand = Map.of(onHand),
      recipes = Map.unmodifiable(recipes.map((k, v) => MapEntry(k, Map<String, int>.unmodifiable(v)))),
      pricesCents = Map.unmodifiable(pricesCents) {
    if (_onHand.values.any((q) => q < 0) ||
        recipes.values.any((r) => r.entries.any((e) => e.value <= 0 || !_onHand.containsKey(e.key))) ||
        pricesCents.values.any((p) => p < 100)) {
      throw ArgumentError('Catálogo inválido');
    }
  }

  int available(String sku) => (_onHand[sku] ?? 0) - (_reserved[sku] ?? 0);
  int get receivableCents => _receivables.values.fold(0, (sum, n) => sum + n);
  int get draftCount => _drafts.length;
  String? state(String id) => _states[id];

  String submit(AppointmentProposal proposal, {required bool approved, required DateTime now}) {
    // Validar tenant e replay antes de consultar o catálogo ou reservar material.
    final review = agenda.submit(proposal, approved: false, now: now);
    if (review != 'awaiting_confirmation') return review;
    final recipe = recipes[proposal.serviceId];
    if (recipe == null || !pricesCents.containsKey(proposal.serviceId)) return 'invalid_catalog';
    if (recipe.entries.any((e) => available(e.key) < e.value)) return 'insufficient_stock';
    if (!approved) return review;
    final status = agenda.submit(proposal, approved: true, now: now);
    if (status != 'committed') return status;
    for (final entry in recipe.entries) {
      _reserved[entry.key] = (_reserved[entry.key] ?? 0) + entry.value;
    }
    _orders[proposal.requestId] = proposal;
    _states[proposal.requestId] = 'reserved';
    _receivables[proposal.requestId] = pricesCents[proposal.serviceId]!;
    _drafts[proposal.requestId] = agenda.confirmationDraft(proposal);
    return status;
  }

  String cancel(String id, {required bool approved, required DateTime now}) {
    if (!_orders.containsKey(id)) return 'not_found';
    if (_states[id] == 'cancelled') return 'duplicate';
    if (_states[id] != 'reserved') return 'invalid_transition';
    final status = agenda.cancel(id, approved: approved, now: now);
    if (status != 'cancelled') return status;
    for (final e in recipes[_orders[id]!.serviceId]!.entries) {
      _reserved[e.key] = _reserved[e.key]! - e.value;
    }
    _receivables.remove(id);
    _drafts.remove(id);
    _states[id] = 'cancelled';
    return status;
  }

  String complete(String id, {required bool approved}) {
    if (!_orders.containsKey(id)) return 'not_found';
    if (_states[id] == 'completed') return 'duplicate';
    if (_states[id] != 'reserved') return 'invalid_transition';
    if (!approved) return 'awaiting_confirmation';
    for (final e in recipes[_orders[id]!.serviceId]!.entries) {
      _reserved[e.key] = _reserved[e.key]! - e.value;
      _onHand[e.key] = _onHand[e.key]! - e.value;
    }
    _states[id] = 'completed';
    return 'completed';
  }
}
