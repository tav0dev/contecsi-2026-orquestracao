/// Núcleo experimental: a IA propõe; regras de domínio validam; a pessoa confirma.
/// Sem dependência de Flutter, banco ou provedor de IA. Não envia mensagens.
class AppointmentProposal {
  final String requestId, tenantId, clientId, serviceId;
  final DateTime start;
  final int durationMinutes;
  const AppointmentProposal({required this.requestId, required this.tenantId,
    required this.clientId, required this.serviceId, required this.start,
    required this.durationMinutes});

  factory AppointmentProposal.fromJson(Map<String, dynamic> value) {
    const keys = {'request_id', 'tenant_id', 'client_id', 'service_id',
      'start', 'duration_minutes'};
    if (value.keys.toSet().difference(keys).isNotEmpty ||
        keys.difference(value.keys.toSet()).isNotEmpty) {
      throw const FormatException('Campos inesperados ou ausentes');
    }
    for (final key in keys.difference({'duration_minutes'})) {
      if (value[key] is! String || (value[key] as String).trim().isEmpty) {
        throw FormatException('Campo inválido: $key');
      }
    }
    if (value['duration_minutes'] is! int) {
      throw const FormatException('Duração deve ser inteira');
    }
    final rawStart = value['start'] as String;
    if (!RegExp(r'(Z|[+-]\d{2}:\d{2})$').hasMatch(rawStart)) {
      throw const FormatException('Fuso horário obrigatório');
    }
    final parsed = DateTime.parse(rawStart);
    // DateTime.parse normaliza datas como 2026-11-31; rejeitar overflow.
    final datePart = rawStart.substring(0, 10);
    final day = DateTime.tryParse('${datePart}T00:00:00Z');
    if (day == null || day.toIso8601String().substring(0, 10) != datePart) {
      throw const FormatException('Data inválida');
    }
    return AppointmentProposal(requestId: value['request_id'], tenantId: value['tenant_id'],
      clientId: value['client_id'], serviceId: value['service_id'], start: parsed.toUtc(),
      durationMinutes: value['duration_minutes']);
  }

  Map<String, dynamic> toJson() => {'request_id': requestId, 'tenant_id': tenantId,
    'client_id': clientId, 'service_id': serviceId, 'start': start.toUtc().toIso8601String(),
    'duration_minutes': durationMinutes};
  DateTime get end => start.add(Duration(minutes: durationMinutes));
}

class ProcessOrchestrator {
  final String tenantId;
  final Map<String, String> clientOwners, serviceOwners;
  final Map<String, AppointmentProposal> _appointments = {};
  final Set<String> _cancelled = {};
  final List<Map<String, dynamic>> _audit = [];
  ProcessOrchestrator({required this.tenantId, required this.clientOwners,
    required this.serviceOwners});
  List<AppointmentProposal> get appointments => List.unmodifiable(
    _appointments.values.where((p) => !_cancelled.contains(p.requestId)));
  List<Map<String, dynamic>> get audit => List.unmodifiable(_audit.map(Map<String, dynamic>.unmodifiable));

  String submit(AppointmentProposal proposal, {required bool approved, required DateTime now}) {
    String status;
    final prior = _appointments[proposal.requestId];
    if (proposal.tenantId != tenantId || clientOwners[proposal.clientId] != tenantId ||
        serviceOwners[proposal.serviceId] != tenantId) {
      status = 'invalid_reference';
    } else if (prior != null) {
      status = _cancelled.contains(proposal.requestId) ? 'cancelled' : prior.toJson().toString() == proposal.toJson().toString()
        ? 'duplicate' : 'idempotency_mismatch';
    } else if (proposal.requestId.trim().isEmpty || proposal.durationMinutes < 1 ||
        proposal.durationMinutes > 480 || !proposal.start.isAfter(now)) {
      status = 'invalid_schedule';
    } else if (appointments.any((a) =>
        proposal.start.isBefore(a.end) && proposal.end.isAfter(a.start))) {
      status = 'conflict';
    } else if (!approved) {
      status = 'awaiting_confirmation';
    } else {
      _appointments[proposal.requestId] = proposal;
      status = 'committed';
    }
    _audit.add(Map.unmodifiable({'request_id': proposal.requestId, 'status': status,
      'timestamp': now.toUtc().toIso8601String(), 'approved': approved}));
    return status;
  }

  String cancel(String requestId, {required bool approved, required DateTime now}) {
    final status = !_appointments.containsKey(requestId) ? 'not_found'
      : _cancelled.contains(requestId) ? 'duplicate'
      : !approved ? 'awaiting_confirmation' : 'cancelled';
    if (status == 'cancelled') _cancelled.add(requestId);
    _audit.add(Map.unmodifiable({'request_id': requestId, 'status': status,
      'timestamp': now.toUtc().toIso8601String(), 'approved': approved}));
    return status;
  }

  String confirmationDraft(AppointmentProposal p) =>
    'Confira seu atendimento em ${p.start.toUtc().toIso8601String()} '
    '(UTC), duração de ${p.durationMinutes} minutos. Confirme os dados com o prestador.';
}
