"""Configura IA no terminal com entrada oculta. Não chama provedores nem exibe a chave."""
import getpass
from decimal import Decimal
import json
import os
from pathlib import Path


def main():
    target=Path(__file__).with_name('.config.local.json')
    if target.exists():raise SystemExit('Configuração já existe. Edite o arquivo local; não será sobrescrito.')
    cap=input('Orçamento acumulado estimado para este backend, USD [0.10]: ').strip() or '0.10'
    amount=Decimal(cap)
    if not amount.is_finite() or amount<=0:raise SystemExit('Orçamento inválido')
    key=getpass.getpass('Chave OpenAI (entrada oculta): ').strip()
    model=input('ID do modelo/snapshot compatível com Structured Outputs: ').strip()
    incoming=input('Tarifa de entrada USD por milhão de tokens: ').strip()
    outgoing=input('Tarifa de saída USD por milhão de tokens: ').strip()
    if not key or not model:raise SystemExit('Chave/modelo obrigatórios')
    for rate in (incoming,outgoing):
        value=Decimal(rate)
        if not value.is_finite() or value<=0:raise SystemExit('Tarifa inválida')
    config={'OPENAI_API_KEY':key,'BICO_OPENAI_MODEL':model,
        'BICO_INPUT_USD_PER_MILLION':incoming,'BICO_OUTPUT_USD_PER_MILLION':outgoing,
        'BICO_BUDGET_USD':str(amount)}
    fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as stream:json.dump(config,stream,indent=2)
    print('Configuração privada criada. Nenhuma chamada à API executada.')


if __name__=='__main__':main()
