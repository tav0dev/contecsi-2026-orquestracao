import tempfile
import unittest
from pathlib import Path
from prototipo.plataforma.server import Application, OpenAIPlanner, RequestError, SupabaseRPC, SUPABASE_URL
from prototipo.planejador.server import Budget

TENANT='e08de129-e13b-44ac-8053-5266f7b39ca0'
STATE={'tenant_id':TENANT,'clients':[{'id':'c1','label':'Cliente sintético'}],
    'services':[{'id':'s1','label':'Serviço','duration_minutes':60}]}
PROPOSAL={'request_id':'r1','tenant_id':TENANT,'client_id':'c1','service_id':'s1',
    'start':'2030-11-10T14:00:00-03:00','duration_minutes':60}


class RPC:
    def __init__(self):self.calls=[];self.state=STATE
    def call(self,token,function,params):
        self.calls.append((token,function,params))
        if function=='state':return self.state
        if function=='submit':return {'status':'committed' if params['p_approved'] else 'awaiting_confirmation'}
        return {'status':'ok'}


class Planner:
    def __init__(self,status='proposed'):self.calls=[];self.status=status
    def plan(self,payload):
        self.calls.append(payload)
        if self.status!='proposed':return {'status':self.status,'draft':'Informe o horário'},{}
        return {'status':'proposed',**{k:PROPOSAL[k] for k in ('client_id','service_id','start','duration_minutes')},'draft':'Confira'}, {'model':'test-double'}


class ApplicationTests(unittest.TestCase):
    def setUp(self):self.rpc=RPC();self.planner=Planner();self.app=Application(self.rpc,self.planner)
    def test_plan_uses_database_context_and_does_not_commit(self):
        result=self.app.handle('POST','/plan','user-jwt',{'request':'Agende o cliente amanhã às 14h'})
        self.assertEqual([c[1] for c in self.rpc.calls],['state','submit'])
        self.assertFalse(self.rpc.calls[-1][2]['p_approved'])
        self.assertEqual(result['proposal']['tenant_id'],TENANT)
        self.assertEqual(self.planner.calls[0]['context']['clients'][0]['id'],'c1')
        self.assertNotIn('owner_id',self.planner.calls[0]['context'])
    def test_client_cannot_inject_catalog_or_tenant_into_plan(self):
        with self.assertRaises(RequestError):self.app.handle('POST','/plan','jwt',{'request':'x','context':{'tenant':'other'}})
        self.assertEqual(self.planner.calls,[])
    def test_no_session_no_model_or_database_calls(self):
        with self.assertRaises(RequestError) as err:self.app.handle('POST','/plan','',{'request':'x'})
        self.assertEqual(err.exception.status,401);self.assertEqual(self.rpc.calls,[]);self.assertEqual(self.planner.calls,[])
    def test_invalid_database_session_prevents_ai_spend(self):
        def denied(*args):raise RequestError(401,'denied')
        self.rpc.call=denied
        with self.assertRaises(RequestError):self.app.handle('POST','/plan','invalid',{'request':'x'})
        self.assertEqual(self.planner.calls,[])
    def test_confirm_requires_literal_true(self):
        for value in (False,1,'true',None):
            with self.subTest(value=value),self.assertRaises(RequestError):
                self.app.handle('POST','/confirm','jwt',{'proposal':PROPOSAL,'approved':value})
        self.assertEqual(self.rpc.calls,[])
    def test_confirm_dispatches_to_transaction_rpc(self):
        self.assertEqual(self.app.handle('POST','/confirm','jwt',{'proposal':PROPOSAL,'approved':True})['status'],'committed')
        self.assertEqual(self.rpc.calls[-1],('jwt','submit',{'p_proposal':PROPOSAL,'p_approved':True}))
    def test_clarification_does_not_call_submit(self):
        self.app.planner=Planner('needs_clarification')
        result=self.app.handle('POST','/plan','jwt',{'request':'Agende'})
        self.assertNotIn('proposal',result);self.assertEqual([c[1] for c in self.rpc.calls],['state'])
    def test_transition_resolves_tenant_from_authenticated_state(self):
        self.app.handle('POST','/transition','jwt',{'request_id':'r1','action':'cancel','approved':True})
        self.assertEqual(self.rpc.calls[-1][2]['p_tenant'],TENANT)
    def test_setup_is_explicit(self):
        with self.assertRaises(RequestError):self.app.handle('POST','/setup','jwt',{})
        with self.assertRaises(RequestError):self.app.handle('POST','/setup','jwt',{'approved':1})
        self.app.handle('POST','/setup','jwt',{'approved':True})
        self.assertEqual(self.rpc.calls[-1][1],'setup')
    def test_external_providers_disabled(self):
        for path in ('/integrations/pix','/integrations/social-draft'):
            with self.assertRaises(RequestError) as err:self.app.handle('POST',path,'jwt',{})
            self.assertEqual(err.exception.status,404)
        self.assertEqual(self.rpc.calls,[])
    def test_unconfigured_ai_does_not_fallback_to_synthetic(self):
        self.app.planner=None
        with self.assertRaises(RequestError) as err:self.app.handle('POST','/plan','jwt',{'request':'x'})
        self.assertEqual(err.exception.code,'ai_not_configured')
    def test_rpc_uses_bico_project_and_user_jwt(self):
        captured=[]
        rpc=SupabaseRPC('public-test',lambda *a:captured.append(a) or STATE)
        rpc.call('user-jwt','state',{})
        self.assertEqual(captured[0][1],SUPABASE_URL+'/rest/v1/rpc/bico_exp_state')
        self.assertEqual(captured[0][2]['Authorization'],'Bearer user-jwt')
        self.assertEqual(captured[0][2]['apikey'],'public-test')
    def test_budget_exhausted_prevents_http(self):
        with tempfile.TemporaryDirectory() as d:
            planner=OpenAIPlanner('synthetic','test-model',100,100,Budget(Path(d)/'budget',.0001),
                lambda *a:self.fail('Não deve chamar OpenAI'))
            with self.assertRaises(RequestError) as err:planner.plan({'context':{},'request':'x'})
            self.assertEqual(err.exception.code,'budget_limit')
    def test_inference_timeout_is_classified_without_retry_or_submit(self):
        attempts=[]
        def timeout(*args):
            attempts.append(args[1]);raise TimeoutError()
        with tempfile.TemporaryDirectory() as d:
            budget=Budget(Path(d)/'budget',.10)
            self.app.planner=OpenAIPlanner('synthetic','test-model',.1,.5,budget,timeout)
            with self.assertRaises(RequestError) as error:
                self.app.handle('POST','/plan','jwt',{'request':'Agende'})
            self.assertEqual((error.exception.status,error.exception.code),(504,'inference_timeout'))
            self.assertEqual(len(attempts),1)
            self.assertEqual([c[1] for c in self.rpc.calls],['state'])
            self.assertGreater(float(budget.path.read_text()),0)
    def test_plan_reports_stage_timings(self):
        result=self.app.handle('POST','/plan','jwt',{'request':'Agende'})
        timing=result['metadata']['timings_ms']
        self.assertEqual(set(timing),{'context','inference','review','server_total'})
        self.assertTrue(all(value>=0 for value in timing.values()))
        self.assertAlmostEqual(sum(timing[k] for k in ('context','inference','review')),
                               timing['server_total'],delta=.003)
    def test_database_timeout_prevents_inference(self):
        def timeout(*args):raise TimeoutError()
        self.app.rpc=SupabaseRPC('synthetic',timeout)
        with self.assertRaises(RequestError) as error:
            self.app.handle('POST','/plan','jwt',{'request':'Agende'})
        self.assertEqual((error.exception.status,error.exception.code),(504,'database_unavailable_or_timeout'))
        self.assertEqual(self.planner.calls,[])


if __name__=='__main__':unittest.main(verbosity=2)
