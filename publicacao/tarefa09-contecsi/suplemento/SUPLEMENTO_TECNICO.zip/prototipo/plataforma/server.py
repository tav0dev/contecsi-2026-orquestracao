"""Backend integrado do experimento. Executar da raiz: python3 -m prototipo.plataforma.server.

Supabase é obrigatório. IA é habilitada apenas com chave/modelo/tarifas configurados.
AbacatePay e Zernio permanecem desabilitados neste recorte e não são chamados.
"""
from datetime import datetime, timezone
from decimal import Decimal
from functools import partial
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import argparse
import os
from pathlib import Path
import urllib.error
import uuid
import time

from prototipo.integracoes.providers import http_json
from prototipo.planejador.server import Budget, PROMPT_VERSION, decode_plan, request_body

SUPABASE_URL='https://wzychmshebmznjfducug.supabase.co'


class RequestError(Exception):
    def __init__(self, status, code): self.status,self.code=status,code


class SupabaseRPC:
    def __init__(self, public_key, transport=None):
        if not public_key:raise ValueError('SUPABASE_ANON_KEY ausente')
        self.key=public_key
        self.transport=transport if transport is not None else partial(http_json,timeout=10)

    def call(self, token, function, params):
        if function not in {'state','setup','submit','transition'}:raise ValueError('RPC não permitida')
        if not isinstance(token,str) or not token.strip():raise RequestError(401,'unauthorized')
        try:
            return self.transport('POST',SUPABASE_URL+'/rest/v1/rpc/bico_exp_'+function,
                {'apikey':self.key,'Authorization':'Bearer '+token,'Content-Type':'application/json'},params)
        except urllib.error.HTTPError as error:
            if error.code in (401,403):raise RequestError(401,'session_expired_or_denied') from None
            # Não refletir logs SQL ou conteúdo privado ao cliente.
            raise RequestError(409,'database_rejected_or_migration_missing') from None
        except (TimeoutError, urllib.error.URLError):
            raise RequestError(504,'database_unavailable_or_timeout') from None


class OpenAIPlanner:
    def __init__(self, key, model, input_rate, output_rate, budget, transport=None):
        self.key,self.model,self.budget=key,model,budget
        self.transport=transport if transport is not None else partial(http_json,timeout=35)
        self.input_rate,self.output_rate=Decimal(str(input_rate)),Decimal(str(output_rate))
        if not key or not model or any(not n.is_finite() or n<=0 for n in (self.input_rate,self.output_rate)):
            raise ValueError('Configuração de IA inválida')

    def plan(self, payload):
        body=request_body(self.model,payload)
        reserve=(Decimal(len(json.dumps(body).encode())+1024)*self.input_rate+
                 Decimal(512)*self.output_rate)/Decimal(1000000)
        try:self.budget.reserve(reserve)
        except RuntimeError:raise RequestError(429,'budget_limit') from None
        try:
            response=self.transport('POST','https://api.openai.com/v1/responses',
                {'Authorization':'Bearer '+self.key,'Content-Type':'application/json'},body)
        except TimeoutError:
            raise RequestError(504,'inference_timeout') from None
        except urllib.error.URLError as error:
            code='inference_timeout' if isinstance(error.reason,TimeoutError) else 'inference_unavailable'
            raise RequestError(504 if code=='inference_timeout' else 502,code) from None
        plan=decode_plan(response)
        return plan,{'model':response.get('model',self.model),'prompt_version':PROMPT_VERSION,
                     'usage':response.get('usage',{}),'reserved_usd':str(reserve)}


class Application:
    """Mesma aplicação usada pelo HTTP e pelos testes em processo, sem duplicar regras."""
    def __init__(self, rpc, planner=None, now=None):
        self.rpc,self.planner=rpc,planner
        self.now=now or (lambda:datetime.now(timezone.utc))

    def handle(self, method, path, token, body):
        if not token:raise RequestError(401,'unauthorized')
        if not isinstance(body,dict):raise RequestError(400,'invalid_body')
        if method=='GET' and path=='/state':
            result=self.rpc.call(token,'state',{})
            return {**result,'capabilities':{'ai':self.planner is not None,'payments':False,'social':False}}
        if method=='POST' and path=='/setup':
            if set(body)!={'approved'} or body.get('approved') is not True:raise RequestError(400,'explicit_approval_required')
            return self.rpc.call(token,'setup',{})
        if method=='POST' and path in ('/review','/confirm'):
            expected={'proposal'} if path=='/review' else {'proposal','approved'}
            if set(body)!=expected or not isinstance(body.get('proposal'),dict):raise RequestError(400,'invalid_body')
            if path=='/confirm' and body.get('approved') is not True:raise RequestError(400,'explicit_approval_required')
            return self.rpc.call(token,'submit',{'p_proposal':body['proposal'],'p_approved':path=='/confirm'})
        if method=='POST' and path=='/transition':
            if set(body)!={'request_id','action','approved'} or body.get('approved') is not True:
                raise RequestError(400,'explicit_approval_required')
            if body['action'] not in ('complete','cancel') or not isinstance(body['request_id'],str):
                raise RequestError(400,'invalid_transition')
            state=self.rpc.call(token,'state',{})
            if state.get('needs_setup'):raise RequestError(409,'setup_required')
            return self.rpc.call(token,'transition',{'p_tenant':state['tenant_id'],
                'p_request_id':body['request_id'],'p_action':body['action'],'p_approved':True})
        if method=='POST' and path=='/plan':
            if set(body)!={'request'} or not isinstance(body['request'],str) or not 1<=len(body['request'].strip())<=4000:
                raise RequestError(400,'invalid_request')
            # Valida sessão e obtém catálogos no banco ANTES de gastar com o modelo.
            started=time.perf_counter()
            state=self.rpc.call(token,'state',{})
            context_done=time.perf_counter()
            if state.get('needs_setup'):raise RequestError(409,'setup_required')
            if self.planner is None:raise RequestError(503,'ai_not_configured')
            context={'now':self.now().isoformat(),'timezone':'America/Sao_Paulo',
                'clients':[{'id':c['id'],'name':c['label']} for c in state['clients']],
                'services':[{'id':s['id'],'name':s['label'],'duration_minutes':s['duration_minutes']} for s in state['services']]}
            plan,metadata=self.planner.plan({'context':context,'request':body['request']})
            inference_done=time.perf_counter()
            result={'plan':plan,'metadata':metadata}
            if plan['status']=='proposed':
                if set(plan)!={'status','client_id','service_id','start','duration_minutes','draft'}:
                    raise RequestError(502,'invalid_plan')
                proposal={'request_id':str(uuid.uuid4()),'tenant_id':state['tenant_id'],
                    **{k:plan[k] for k in ('client_id','service_id','start','duration_minutes')}}
                result['review']=self.rpc.call(token,'submit',{'p_proposal':proposal,'p_approved':False})
                result['proposal']=proposal
            finished=time.perf_counter()
            result['metadata']['timings_ms']={
                'context':round((context_done-started)*1000,3),
                'inference':round((inference_done-context_done)*1000,3),
                'review':round((finished-inference_done)*1000,3),
                'server_total':round((finished-started)*1000,3)}
            return result
        raise RequestError(404,'not_found')


def handler_for(app, allowed_origin):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args):pass
        def reply(self,status,data):
            wire=json.dumps(data,ensure_ascii=False).encode()
            self.send_response(status)
            if self.headers.get('Origin')==allowed_origin:
                self.send_header('Access-Control-Allow-Origin',allowed_origin)
                self.send_header('Vary','Origin')
            self.send_header('Content-Type','application/json; charset=utf-8')
            self.send_header('Content-Length',str(len(wire)))
            self.send_header('Cache-Control','no-store')
            timings=data.get('metadata',{}).get('timings_ms',{}) if isinstance(data,dict) else {}
            if timings:
                self.send_header('Server-Timing',', '.join(f'{key};dur={value}' for key,value in timings.items()))
            self.end_headers()
            try:self.wfile.write(wire)
            except (BrokenPipeError,ConnectionResetError):pass
        def do_OPTIONS(self):
            if self.headers.get('Origin')!=allowed_origin:return self.reply(403,{'error':'origin_denied'})
            self.send_response(204)
            self.send_header('Access-Control-Allow-Origin',allowed_origin)
            self.send_header('Access-Control-Allow-Headers','Authorization, Content-Type')
            self.send_header('Access-Control-Allow-Methods','GET, POST, OPTIONS')
            self.end_headers()
        def do_GET(self):self.dispatch()
        def do_POST(self):self.dispatch()
        def dispatch(self):
            origin=self.headers.get('Origin')
            if origin and origin!=allowed_origin:return self.reply(403,{'error':'origin_denied'})
            auth=self.headers.get('Authorization','')
            token=auth[7:] if auth.startswith('Bearer ') else ''
            try:
                size=int(self.headers.get('Content-Length','0'))
                if size<0 or size>16000:raise RequestError(400,'invalid_size')
                body=json.loads(self.rfile.read(size)) if size else {}
                self.reply(200,app.handle(self.command,self.path,token,body))
            except RequestError as error:self.reply(error.status,{'error':error.code})
            except (ValueError,TypeError,KeyError):self.reply(400,{'error':'invalid_request_or_contract'})
            except Exception:self.reply(502,{'error':'upstream_unavailable'})
    return Handler


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=Path(__file__).with_name('.config.local.json'))
    parser.add_argument('--port',type=int,default=8766)
    args=parser.parse_args()
    if args.config.exists():
        config=json.loads(args.config.read_text())
        allowed={'OPENAI_API_KEY','BICO_OPENAI_MODEL','BICO_INPUT_USD_PER_MILLION',
            'BICO_OUTPUT_USD_PER_MILLION','BICO_BUDGET_USD','SUPABASE_ANON_KEY','BICO_WEB_ORIGIN'}
        if not isinstance(config,dict) or set(config)-allowed:raise SystemExit('Configuração contém campos desconhecidos')
        for k,v in config.items():os.environ.setdefault(k,str(v))
    public=json.loads(Path(__file__).with_name('public_config.json').read_text())
    rpc=SupabaseRPC(os.environ.get('SUPABASE_ANON_KEY') or public['BICO_SUPABASE_ANON_KEY'])
    planner=None
    if os.environ.get('OPENAI_API_KEY'):
        required=['BICO_OPENAI_MODEL','BICO_INPUT_USD_PER_MILLION','BICO_OUTPUT_USD_PER_MILLION']
        missing=[k for k in required if not os.environ.get(k)]
        if missing:raise SystemExit('Configure: '+', '.join(missing))
        cap=Decimal(os.environ.get('BICO_BUDGET_USD','0.50'))
        if not cap.is_finite() or cap<=0:raise SystemExit('Orçamento inválido')
        planner=OpenAIPlanner(os.environ['OPENAI_API_KEY'],os.environ['BICO_OPENAI_MODEL'],
            os.environ[required[1]],os.environ[required[2]],
            Budget(Path(__file__).with_name('.budget-reserved'),cap))
    app=Application(rpc,planner)
    origin=os.environ.get('BICO_WEB_ORIGIN','http://localhost:7357')
    print(f'Backend experimental em http://127.0.0.1:{args.port}; Supabase Bico; pagamentos/redes desativados.',flush=True)
    HTTPServer(('127.0.0.1',args.port),handler_for(app,origin)).serve_forever()


if __name__=='__main__':main()
