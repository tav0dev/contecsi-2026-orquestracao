"""Prepara um projeto Android descartável para o laboratório Flutter.

Não modifica o app legado, não publica e recusa saída existente.
Após preparar, compilar lib/main_android.dart com --release --target-platform
android-arm64 e --dart-define-from-file apontando ao public_config.json.
"""
import argparse
from pathlib import Path
import shutil
import subprocess


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--flutter',default='flutter')
    parser.add_argument('--output',type=Path,required=True)
    args=parser.parse_args()
    if args.output.exists():parser.error('Preserve o projeto existente; escolha outra saída')
    source=Path(__file__).resolve().parents[1]/'laboratorio'
    subprocess.run([args.flutter,'create','--platforms=android','--org','br.edu.contecsi',
        '--project-name','bico_laboratorio','--no-pub',str(args.output.resolve())],check=True)
    for name in ('lib','test'):
        target=args.output/name
        if target.exists():shutil.rmtree(target)
        shutil.copytree(source/name,target)
    for name in ('pubspec.yaml','pubspec.lock'):shutil.copyfile(source/name,args.output/name)
    # O manifesto do laboratório substitui o do template; a configuração de
    # análise deve acompanhar suas dependências, sem presumir flutter_lints.
    analysis=source/'analysis_options.yaml'
    if analysis.exists():
        shutil.copyfile(analysis,args.output/'analysis_options.yaml')
    else:
        (args.output/'analysis_options.yaml').unlink(missing_ok=True)
    manifest=args.output/'android/app/src/main/AndroidManifest.xml'
    text=manifest.read_text().replace('<application',
        '<uses-permission android:name="android.permission.INTERNET"/>\n    '
        '<application android:usesCleartextTraffic="true"',1)
    text=text.replace('android:label="bico_laboratorio"','android:label="Orquestração — laboratório"')
    manifest.write_text(text)
    print('Projeto para teste local via adb reverse. Assinatura padrão de laboratório; sem publicação.')


if __name__=='__main__':main()
