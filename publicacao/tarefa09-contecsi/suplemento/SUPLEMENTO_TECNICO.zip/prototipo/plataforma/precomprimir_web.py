"""Pré-comprime artefatos públicos de um build, sem modificar os originais."""
import argparse
from pathlib import Path
import shutil
import subprocess


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory',type=Path)
    args=parser.parse_args()
    if not shutil.which('brotli'):parser.error('Instale a ferramenta brotli antes de preparar o build')
    root=args.directory.resolve(strict=True)
    files=[p for p in root.rglob('*') if p.is_file() and p.suffix in ('.js','.mjs','.wasm','.json','.html','.css')]
    before=after=0
    for path in files:
        subprocess.run(['brotli','--quality=9','--force','--keep',str(path)],check=True,capture_output=True)
        before+=path.stat().st_size;after+=path.with_name(path.name+'.br').stat().st_size
    print(f'{len(files)} arquivos: {before} bytes originais; {after} bytes Brotli.')


if __name__=='__main__':main()
