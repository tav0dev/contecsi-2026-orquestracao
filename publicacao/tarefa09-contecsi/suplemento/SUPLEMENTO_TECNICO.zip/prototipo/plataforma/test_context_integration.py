"""Contrato da seleção no fluxo principal; transportes simulados, sem chamadas pagas."""
from copy import deepcopy
from datetime import datetime
from http.server import HTTPServer
import json
import os
from pathlib import Path
import tempfile
from threading import Thread
import unittest

from experimentos.comparacao_contexto_20261108 import corpus
from prototipo.integracoes.providers import http_json
from prototipo.planejador.contexto import select_context
from prototipo.planejador.server import Budget, SCHEMA
from prototipo.plataforma.server import Application, OpenAIPlanner, RequestError, handler_for

ROOT = Path(__file__).resolve().parents[2]


def state_for(context, tenant='tenant-a'):
    return {'tenant_id': tenant,
            'clients': [{'id': c['id'], 'label': c['name']} for c in context['clients']],
            'services': [{'id': s['id'], 'label': s['name'],
                          'duration_minutes': s['duration_minutes']} for s in context['services']]}


class RPC:
    def __init__(self, context):
        self.states = {'jwt-a': state_for(context),
                       'jwt-b': {'tenant_id': 'tenant-b',
                                 'clients': [{'id': 'b-only', 'label': 'Beatriz Nunes'}],
                                 'services': [{'id': 'b-service', 'label': 'Serviço B', 'duration_minutes': 30}]}}
        self.calls = []

    def call(self, token, function, params):
        self.calls.append((token, function, deepcopy(params)))
        if token not in self.states:
            raise RequestError(401, 'denied')
        if function == 'state':
            return deepcopy(self.states[token])
        if function == 'submit':
            if params['p_approved']:
                return {'status': 'committed'}
            return {'status': 'awaiting_confirmation'}
        raise AssertionError(function)


class Planner:
    def __init__(self, answer):
        self.answer, self.calls = answer, []

    def plan(self, payload):
        self.calls.append(deepcopy(payload))
        return deepcopy(self.answer), {}


class ContextIntegrationTests(unittest.TestCase):
    def setUp(self):
        self.case = corpus()[0]
        self.rpc = RPC(self.case['context'])
        self.planner = Planner({**self.case['expected'], 'draft': 'Confira os efeitos.'})
        self.app = Application(self.rpc, self.planner,
                               now=lambda: datetime.fromisoformat(self.case['context']['now']))

    def test_default_flow_selects_before_planning_and_only_reviews(self):
        result = self.app.handle('POST', '/plan', 'jwt-a', {'request': self.case['request']})
        self.assertEqual(self.planner.calls[0]['context'], select_context(self.case['context'], self.case['request']))
        self.assertEqual(result['metadata']['context_selection']['available'], {'clients': 24, 'services': 6})
        self.assertEqual(result['metadata']['context_selection']['retained'], {'clients': 1, 'services': 1})
        self.assertEqual([f for _, f, _ in self.rpc.calls], ['state', 'submit'])
        self.assertIs(self.rpc.calls[-1][2]['p_approved'], False)
        self.assertEqual(result['review']['status'], 'awaiting_confirmation')

    def test_shared_names_remain_ambiguous(self):
        self.planner.answer = {'status': 'needs_clarification', 'draft': 'Qual Ana?'}
        result = self.app.handle('POST', '/plan', 'jwt-a', {'request': 'Agende limpeza residencial para Ana em 20/12/2030 às 14h.'})
        self.assertEqual({c['name'] for c in self.planner.calls[0]['context']['clients']}, {'Ana Silva', 'Ana Souza'})
        self.assertNotIn('proposal', result)
        self.assertEqual([f for _, f, _ in self.rpc.calls], ['state'])

    def test_no_match_retains_catalog_and_does_not_mutate_state(self):
        before = deepcopy(self.rpc.states)
        self.planner.answer = {'status': 'needs_clarification', 'draft': 'Informe os dados.'}
        self.app.handle('POST', '/plan', 'jwt-a', {'request': 'Preciso organizar um compromisso.'})
        self.assertEqual(self.planner.calls[0]['context'], self.case['context'])
        self.assertEqual(before, self.rpc.states)

    def test_valid_but_unselected_reference_is_refused_before_review(self):
        self.planner.answer['client_id'] = 'limpeza-c02'
        with self.assertRaises(RequestError) as error:
            self.app.handle('POST', '/plan', 'jwt-a', {'request': self.case['request']})
        self.assertEqual(error.exception.code, 'invalid_plan_reference')
        self.assertEqual([f for _, f, _ in self.rpc.calls], ['state'])

    def test_foreign_tenant_data_never_reaches_the_other_session(self):
        self.planner.answer = {'status': 'needs_clarification', 'draft': 'Informe os dados.'}
        self.app.handle('POST', '/plan', 'jwt-b', {'request': self.case['request']})
        sent = self.planner.calls[0]['context']
        self.assertEqual([c['id'] for c in sent['clients']], ['b-only'])
        self.assertEqual([s['id'] for s in sent['services']], ['b-service'])
        self.assertNotIn('tenant-a', json.dumps(sent))

    def test_duration_must_match_selected_service(self):
        self.planner.answer['duration_minutes'] = 30
        with self.assertRaises(RequestError) as error:
            self.app.handle('POST', '/plan', 'jwt-a', {'request': self.case['request']})
        self.assertEqual(error.exception.code, 'invalid_plan_duration')
        self.assertEqual([f for _, f, _ in self.rpc.calls], ['state'])

    def test_full_mode_is_explicit_and_client_cannot_select_strategy(self):
        self.app.context_strategy = 'full'
        self.app.handle('POST', '/plan', 'jwt-a', {'request': self.case['request']})
        self.assertEqual(self.planner.calls[0]['context'], self.case['context'])
        with self.assertRaises(RequestError):
            self.app.handle('POST', '/plan', 'jwt-a', {'request': self.case['request'], 'context_strategy': 'full'})

    def test_http_contract_still_requires_explicit_approval(self):
        server = HTTPServer(('127.0.0.1', 0), handler_for(self.app, 'http://localhost:7357'))
        thread = Thread(target=server.serve_forever, daemon=True); thread.start()
        base = f'http://127.0.0.1:{server.server_port}'
        headers = {'Authorization': 'Bearer jwt-a', 'Content-Type': 'application/json'}
        try:
            result = http_json('POST', base+'/plan', headers, {'request': self.case['request']})
            self.assertEqual(result['review']['status'], 'awaiting_confirmation')
            self.assertTrue(all(params.get('p_approved') is not True for _, f, params in self.rpc.calls if f == 'submit'))
            committed = http_json('POST', base+'/confirm', headers, {'proposal': result['proposal'], 'approved': True})
            self.assertEqual(committed['status'], 'committed')
            self.assertIs(self.rpc.calls[-1][2]['p_approved'], True)
        finally:
            server.shutdown(); thread.join(); server.server_close()

    def test_recorded_selected_responses_replay_through_integrated_flow(self):
        folder = Path(os.environ.get('BICO_STUDY_DIR', ROOT/'experimentos/resultados_locais/comparacao_contexto_20261108'))
        prepared = [json.loads(l) for l in (folder/'trials_prepared.jsonl').read_text().splitlines()]
        full = {(r['case_id'], r['repetition']): r['payload'] for r in prepared if r['condition'] == 'full'}
        selected = {(r['case_id'], r['repetition']): r['payload'] for r in prepared if r['condition'] == 'selected'}
        rows = [json.loads(l) for l in (folder/'trials.jsonl').read_text().splitlines()]
        rows = [r for r in rows if r['condition'] == 'selected']
        self.assertEqual(len(rows), 180)
        with tempfile.TemporaryDirectory() as directory:
            budget = Budget(Path(directory)/'replay-budget', 1)
            for row in rows:
                key = row['case_id'], row['repetition']
                with self.subTest(case=row['case_id'], repetition=row['repetition']):
                    expected_payload = selected[key]
                    actual = row['actual']

                    def transport(method, url, headers, body):
                        self.assertEqual(json.loads(body['input']), expected_payload)
                        self.assertEqual(url, 'https://api.openai.com/v1/responses')
                        plan = {name: None for name in SCHEMA['required']}; plan.update(actual)
                        return {'status': 'completed', 'model': 'gpt-6-luna',
                                'output': [{'content': [{'type': 'output_text', 'text': json.dumps(plan)}]}]}

                    rpc = RPC(full[key]['context'])
                    app = Application(rpc, OpenAIPlanner('replay-only', 'gpt-6-luna', '.1', '.5', budget, transport),
                                      now=lambda: datetime.fromisoformat(full[key]['context']['now']))
                    response = app.handle('POST', '/plan', 'jwt-a', {'request': full[key]['request']})
                    self.assertEqual(response['plan'], actual)
                    self.assertTrue(all(p.get('p_approved') is False for _, f, p in rpc.calls if f == 'submit'))


if __name__ == '__main__':
    unittest.main()
