"""Serve o build web local com compressão e validação de cache, sem publicar.

Executar: python3 -m prototipo.plataforma.serve_web --port 7358 --directory CAMINHO
Somente arquivos do build; não fornece API, credenciais ou listagem de diretórios.
"""
import argparse
from functools import partial
import gzip
import hashlib
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlsplit


class BuildHandler(SimpleHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    compressed = {}

    def log_message(self, *_):
        pass

    def send_head(self):
        root = Path(self.directory).resolve()
        requested = root / unquote(urlsplit(self.path).path).lstrip('/')
        target = requested.resolve()
        if not target.is_relative_to(root):
            self.send_error(403)
            return None
        if target.is_dir():
            target = (target / 'index.html').resolve()
        if not target.is_relative_to(root):
            self.send_error(403)
            return None
        if not target.is_file():
            self.send_error(404)
            return None
        stat = target.stat()
        cache_key = (str(target), stat.st_mtime_ns, stat.st_size)
        if cache_key not in self.compressed:
            raw = target.read_bytes()
            packed = gzip.compress(raw, compresslevel=6, mtime=0)
            self.compressed[cache_key] = (raw, packed, hashlib.sha256(raw).hexdigest())
        raw, packed, digest = self.compressed[cache_key]
        accepted = {}
        for part in self.headers.get('Accept-Encoding', '').split(','):
            name, *params = part.strip().split(';')
            try:quality = next((float(p.strip()[2:]) for p in params if p.strip().startswith('q=')),1)
            except ValueError:quality = 0
            accepted[name.strip()] = quality
        encoding = 'gzip' if accepted.get('gzip',0)>0 and len(packed)<len(raw) else None
        data = packed if encoding else raw
        brotli_path = target.with_name(target.name+'.br')
        if accepted.get('br',0)>0 and brotli_path.is_file() and brotli_path.stat().st_mtime_ns>=stat.st_mtime_ns:
            brotli = brotli_path.read_bytes()
            if len(brotli)<len(data):data,encoding = brotli,'br'
        etag = '"' + digest + ('-'+encoding if encoding else '') + '"'
        unchanged = self.headers.get('If-None-Match') == etag
        self.send_response(304 if unchanged else 200)
        self.send_header('Content-Type', self.guess_type(str(target)))
        self.send_header('Cache-Control', 'no-cache')
        self.send_header('ETag', etag)
        self.send_header('Vary', 'Accept-Encoding')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cross-Origin-Opener-Policy','same-origin')
        self.send_header('Cross-Origin-Embedder-Policy','require-corp')
        if encoding:
            self.send_header('Content-Encoding', encoding)
        if not unchanged:
            self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        if unchanged:
            return None
        from io import BytesIO
        return BytesIO(data)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--port', type=int, default=7358)
    args = parser.parse_args()
    root = args.directory.resolve(strict=True)
    if not (root / 'flutter_bootstrap.js').is_file():
        parser.error('Diretório precisa ser um build Flutter web')
    print(f'Build web em http://localhost:{args.port}/#/integracao', flush=True)
    ThreadingHTTPServer(('127.0.0.1', args.port), partial(BuildHandler, directory=str(root))).serve_forever()


if __name__ == '__main__':
    main()
