"""Salva a chave TypeSafe com entrada oculta; sem rede ou alteração de orçamento."""
import getpass
import json
import os
from pathlib import Path
import sys


def main():
    target=Path(__file__).with_name('.jev.local.json')
    if target.exists():
        raise SystemExit('Configuração local já existe; não será sobrescrita.')
    if not sys.stdin.isatty():
        raise SystemExit('Execute em um terminal interativo para ocultar a chave.')
    print('Configuração para comparação experimental; não altera o aplicativo ou o orçamento.')
    key=getpass.getpass('Chave TypeSafe/Jev (entrada oculta): ').strip()
    if not key or any(ch.isspace() for ch in key):
        raise SystemExit('Chave vazia ou com espaços; nenhum arquivo criado.')
    model=input('Modelo versionado [jev-1.14.0]: ').strip() or 'jev-1.14.0'
    if model not in ('jev-1.14.0','jev-1.13.0'):
        raise SystemExit('Escolha uma das versões conferidas: jev-1.14.0 ou jev-1.13.0.')
    config={'TYPESAFE_API_KEY':key,'JEV_MODEL':model,
        'JEV_INPUT_USD_PER_MILLION':'0.042',
        'pricing_verified_date':'2026-11-05',
        'pricing_source':'https://docs.typesafe.ai/models'}
    fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'w') as stream:
        json.dump(config,stream,indent=2);stream.write('\n')
    print('Configuração privada criada. Chave não exibida; nenhuma chamada ou cobrança iniciada.')


if __name__=='__main__':main()
