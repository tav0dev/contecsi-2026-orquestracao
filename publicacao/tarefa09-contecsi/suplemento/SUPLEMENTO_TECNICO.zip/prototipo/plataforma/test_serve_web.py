import gzip
from functools import partial
from http.client import HTTPConnection
from http.server import ThreadingHTTPServer
from pathlib import Path
import tempfile
from threading import Thread
import unittest

from prototipo.plataforma.serve_web import BuildHandler


class BuildServerTests(unittest.TestCase):
    def test_compression_cache_head_and_path_boundary(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder)/'web';root.mkdir()
            payload=b'const example="compressed";\n'*1000
            (root/'main.dart.js').write_bytes(payload)
            (Path(folder)/'private.txt').write_text('private')
            (root/'outside').symlink_to(Path(folder)/'private.txt')
            server=ThreadingHTTPServer(('127.0.0.1',0),partial(BuildHandler,directory=str(root)))
            Thread(target=server.serve_forever,daemon=True).start()
            client=HTTPConnection('127.0.0.1',server.server_port,timeout=5)
            try:
                client.request('GET','/main.dart.js',headers={'Accept-Encoding':'gzip'})
                response=client.getresponse();compressed=response.read()
                self.assertEqual(response.status,200)
                self.assertEqual(response.getheader('Content-Encoding'),'gzip')
                self.assertEqual(gzip.decompress(compressed),payload)
                self.assertLess(len(compressed),len(payload))
                etag=response.getheader('ETag')
                client.request('GET','/main.dart.js',headers={'Accept-Encoding':'gzip','If-None-Match':etag})
                response=client.getresponse();self.assertEqual(response.status,304);response.read()
                client.request('HEAD','/main.dart.js',headers={'Accept-Encoding':'gzip;q=0'})
                response=client.getresponse()
                self.assertEqual(response.getheader('Content-Length'),str(len(payload)))
                self.assertIsNone(response.getheader('Content-Encoding'));self.assertEqual(response.read(),b'')
                for path in ['/outside','/%2e%2e/private.txt','/']:
                    client.request('GET',path);response=client.getresponse()
                    self.assertIn(response.status,(403,404));response.read()
            finally:
                client.close();server.shutdown();server.server_close()


if __name__=='__main__':unittest.main()
